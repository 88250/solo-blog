title: Supporting For Software Engineering Environment - Introduction
date: '2009-09-12 06:18:00'
updated: '2009-09-12 06:18:00'
tags: [BeyondTrack, Software Engineering]
permalink: /articles/2009/09/11/1252678680000.html
---
<p>&nbsp;</p>
<div id="doc-contents">
<div id="google_header" class="google_header">
<p>&nbsp;Supporting For Software Engineering Environment </p>
</div>
<a id="Supporting_For_Software_Engine" name="Supporting_For_Software_Engine"></a>
 <br />
转载请保留作者信息：<br />
作者：88250<br />
Blog：<a href="http://blog.csdn.net/DL88250">http:/blog.csdn.net/DL88250</a>
<br />
MSN &amp; Gmail &amp; QQ：DL88250@gmail.com<a id="_Introduction_2809369786448081_5904451207978961" name="_Introduction_2809369786448081_5904451207978961"></a>
<h1 class="western"><strong>Int</strong>
<strong>roduction </strong>
</h1>
<div id="WritelyTableOfContents" class="writely-toc">
<ol class="writely-toc-none">
<li><a href="http://docs.google.com/View?id=ddrm6c35_1144dmss3rfn#_Introduction_2809369786448081_5904451207978961" target="_self">Introduction</a>
<ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://docs.google.com/View?id=ddrm6c35_1144dmss3rfn#Abstract_679770874514573_08448_6182166130700352" target="_self">Abstract</a>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1144dmss3rfn#Construction_2239156956981967_" target="_self">Construction</a>
<ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://docs.google.com/View?id=ddrm6c35_1144dmss3rfn#Project_Management_08475721043_28316797281839357" target="_self">Project Management</a>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1144dmss3rfn#Dependencies_Management_745100_8894625885792102" target="_self">Dependencies Management</a>
</li>
</ol>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1144dmss3rfn#SCM_7444394318476348_378411320_7575369904274004" target="_self">SCM</a>
<ol class="writely-toc-subheading writely-toc-none" style="margin-left: 0pt;">
<li><a href="http://docs.google.com/View?id=ddrm6c35_1144dmss3rfn#Helpful_Practices_909150915142_6292275440868994" target="_self">Helpful Practices</a>
</li>
</ol>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1144dmss3rfn#Continuous_Integration_6091226_14269537610537386" target="_self">Continuous Integration</a>
</li>
</ol>
</li>
</ol>
</div>
<br />
<br />
<h2 class="western"><a id="Abstract_679770874514573_08448_6182166130700352" name="Abstract_679770874514573_08448_6182166130700352"></a>
<strong>Abstract </strong>
</h2>
<p>Software Engineering Environment involves the processes, approaches
and tools of a software project life cycle with human-centric. This
article introduces the advantages of two open source and stable tools,
and reflects the basic, simple and critical factors that affects on the
development of a software project. </p>
<h2 class="western"><a id="Construction_2239156956981967_" name="Construction_2239156956981967_"></a>
Construction <br />
</h2>
<p align="left"><a href="http://maven.apache.org/">Maven2</a>
 is a
project management and comprehension tool based on Ant. Generally
speaking, by using maven2 (maven for short) takes the following
advantages:</p>
<p align="left">&nbsp;</p>
<ul>
<li>
<p align="left"><strong>IDE independent debugging, testing, building and deployment. </strong>
<br />
It
means developers can code using the best suitable development
environments. For example, Java programmer can use eclipse, JDeveloper,
or NetBeans to write codes, and HTML / CSS / Javascript programmers can
use other development tools for convenience. The project building is
only relies on maven's build configuration and independent of IDE. </p>
</li>
<li>
<p align="left"><strong>Makes the continuous integration easily. </strong>
<br />
A
maven project can configures the source repository and integration tool
easily. For example, when an artifact code completed, we can publish
the artifact into a integration tool (such as Hudson) to build and
finally put the artifact into test server or put it into maven
repository as other project dependency. </p>
</li>
<li>
<p align="left"><strong>Simplicity of extension for different type projects. </strong>
<br />
Maven
can customizes plugins for the specified project on demand. Some
specified projects need to append process in the specified construct
phase, such as when compiling source codes, may need to check the
quality of source codes by using some static or dynamic analysis tools;
after compilation, may need to append the project license on the source
files; and after the whole construction, project manager may want to
take a glance at a project report for getting how many tests fail /
succeed, how many source codes are below standard. </p>
</li>
</ul>
<h3 class="western"><a id="Project_Management_08475721043_28316797281839357" name="Project_Management_08475721043_28316797281839357"></a>
Project Management </h3>
<p align="left">Maven depicts projects using the object-oriented approach. A project has its own <em>pom.xml</em>
for representing the project's structure, sub-projects, referenced
projects (as dependencies) for instance. The relation between these
projects are equivalent to the object-oriented approach's basically.
So, it takes some advantages of object model, such as inheritance and
polymorphism.</p>
<p align="left">&nbsp;</p>
<p align="left">The project management of maven can not reach some
factors (plan, cost, risk, time, etc) of Project Management Theories.
In other words, maven's project management focus on the structure and
construction behaviors of a software project. </p>
<h3 class="western"><a id="Dependencies_Management_745100_8894625885792102" name="Dependencies_Management_745100_8894625885792102"></a>
Dependencies Management </h3>
<p align="left">In modern software development, the dependencies
management is very significant and very difficult. For example, our
current projects depend on some third-part libraries, and each
dependency has its own <em>version</em>
 and <em>runtime dependencies</em>
.
Maven can automatically downloads these libraries, resolves and
downloads their runtime dependencies respectively. It takes the
following advantages:</p>
<p align="left">&nbsp;</p>
<ul>
<li>
<p align="left"><strong>Make the automatic project building and integration simplest. </strong>
<br />
Obviously,
resolving the runtime dependencies are very dull and complicated.
Fortunately, the most dependencies currently in the world have maven
packages, then maven could decide the library 's dependency which is
made by the library's authors or packager. </p>
</li>
<li>
<p align="left"><strong>Make the <strong>control</strong>
 of dependencies change easy . </strong>
<br />
Frequently
the libraries project depends on need to be upgraded. The upgrade is
from an older version to a newer version. According to the above
advantage, the operation is very simple, just need to modify the
version number of the dependencies. </p>
</li>
<li>
<p align="left"><strong>Scoping for every dependency becomes more easier. </strong>
<br />
This
is a very typical case in test libraries. Commonly, we do not package a
junit.jar into production. So, scoping the dependencies will help for
project building and release. In practice, scoping dependencies can
keep the consistence of software architect. For example, we selected
eclipse as the project IDE and using JPA for persistence and Hibernate
as the JPA implementation. After the phase architect verification,
proved JPA is enough to use and never need to use its delegation. But
someone use Hibernate annotations to annotated entities and others use
JPA annotations to do that in deed. It breaks the consistence of
design, make the maintainers drop into mud. By using maven dependencies
management, it never be happen, just identifies the scope of
hibernate-annotation.jar to runtime. </p>
</li>
</ul>
<p align="left">&nbsp;</p>
<h2 class="western"><a id="SCM_7444394318476348_378411320_7575369904274004" name="SCM_7444394318476348_378411320_7575369904274004"></a>
SCM </h2>
Software
Configuration Management (SCM) is focus on the management of changes of
software. Commonly, we use source version control system to track the
changes. <br />
<br />
<h3><a id="Helpful_Practices_909150915142_6292275440868994" name="Helpful_Practices_909150915142_6292275440868994"></a>
Helpful Practices <br />
</h3>
<br />
<p>Basically, a software project source repository should has three folders: <em>trunk</em>
, <em>branch</em>
 and <em>tag</em>
.
Trunk tracks the sources of current project's version. Branch tracks
the sources of current project's branches, a fully-reimplementation
version, a upgrade version, etc, for instance. Tag save the released
sources of the project's several versions.</p>
<p>&nbsp;</p>
<p>The <em><span style="font-weight: normal;">source</span>
</em>
 <span style="font-weight: normal;">we
define that is source code commonly. Strictly speaking, a source
repository should not include any hard modified binary data, the reason
is that different binary data can not compare the differences easily,
it can only compare manually by human. But so many developers commit
the project's binary dependencies into source repository just for
convenience. The dependencies should be resolved out side source
repository. This point is very important to the automation for <em>further</em>
 development and maintenance, otherwise the binary dependencies is managed by another tools, maven for instance.&nbsp;</span>
</p>
<p>&nbsp;</p>
<p>Another problem in multiple humans development collaboratively is the <em>conflict</em>
.
To resolve conflicts, so many developers just to delete the conflicted
source file and commit his / her own version. This is not the problem
that whether the usage of the source version control client developers
got familiar or not, rather than the philosophy of why and how to
identify the configuration item. The configuration items are <em>core source</em>
 of software process management and improvement.</p>
<h2 class="western"><a id="Continuous_Integration_6091226_14269537610537386" name="Continuous_Integration_6091226_14269537610537386"></a>
Continuous Integration <br />
</h2>
<p><a href="https://hudson.dev.java.net/">Hudson</a>
 is an extensible
continuous integration engine like CruiseControl. But it more easily to
configure and extend. It can configures some build strategies, such as
build condition (sources commit, time step, etc). And a friendly
integration status reporting by using dashboard. </p>
<p>See the following continuous integration status come from JBoss.</p>
<p>&nbsp;</p>
<div id="y9j7" style="text-align: left;"><img style="width: 648px; height: 207px;" src="http://docs.google.com/File?id=ddrm6c35_1145dqvw665k_b" alt="" />
</div>
<br />
<p>The continuous integration has the following advantages:&nbsp;</p>
<p>&nbsp;</p>
<div>
<ul>
<li><strong>Exposes the problems of the project as soon as possible. <br />
</strong>
Each
integration has it own 'health' or / 'weather' which quantifies the
productivity of the team. Once encounters an integration fail, every
member in the team will receive a mail&nbsp; that notifies the member what,
when, where is it happen. Helps the team to fix the issue ASAP.&nbsp;
</li>
<li><strong>Combines team members together into a more efficient team. </strong>
<br />
Here
is a case: a programmers finished the development of a module, and then
commit the codes into source repository. The CI tool will get source
from source repository and get start a build.&nbsp; Once the build passed
tester will receive a mail from CI tool that tells the tester it is
time to test this build.</li>
</ul>
<p>&nbsp;</p>
<br />
<h2>Conclusion <br />
</h2>
This article introduced some philosophies of
software engineering with maven2 and hudson. Some of these practices
and principles are such simple, but it is efficient if combined them on
a organized way. To build a helpful software engineering supporting
environment is very sophisticated and constructive, and not only relies
on tools but also depends on human collaboration. I always trust that
is a team should to select and adapt the environment rather then do
nothing. <br />
<br />
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>TODO: Issue Tracking, Software Process Management</p>
<br />
</div>
<br />
<br />
</div>
<div id="google-view-footer">
<div id="maybecanedit" style="float: right;">
<a id="editpermissionlink" class="google-small-link" title="Edit this page" href="http://docs.google.com/Doc?tab=edit&amp;dr=true&amp;id=ddrm6c35_1144dmss3rfn" title="Edit this page" class="google-small-link">
Edit this page (if you have permission)</a>
<span style="color: #676767;">|</span>
<input id="report-abuse-button" onclick="reportAbuse();" type="button" value="Report abuse" />
</div>
<div style="float: left;">
<a class="google-small-link" title="Learn more about Google Docs" href="http://docs.google.com/" title="Learn more about Google Docs" class="google-small-link">
Google Docs -- Web word processing, presentations and spreadsheets.</a>
</div>
<p>&nbsp;</p>
</div>
<p>

</p>