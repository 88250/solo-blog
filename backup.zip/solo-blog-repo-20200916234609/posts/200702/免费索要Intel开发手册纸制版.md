title: 免费索要Intel开发手册纸制版
date: '2007-02-12 00:17:00'
updated: '2007-02-12 00:17:00'
tags: [Solo]
permalink: /articles/2007/02/11/1171181820000.html
---
<p>这是我第三次向Intel要书了。前两次要的是《IA-32 Intel&reg; Architecture Software Developer's Manuals》</p>
<p>实物图：<img height="300" width="400" alt="" src="http://p.blog.csdn.net/images/p_blog_csdn_net/dl88250/273209/o_20070211298.jpg" /></p>
<p>这次更新了，《Intel<span class="regtitle">&reg;</span> 64 and IA-32 Architectures Software Developer's Manuals》呵呵。。。。</p>
<p><img height="300" width="400" alt="" src="http://p.blog.csdn.net/images/p_blog_csdn_net/dl88250/273209/o_20070211297.jpg" /></p>
<p><img height="300" width="400" alt="" src="http://p.blog.csdn.net/images/p_blog_csdn_net/dl88250/273209/o_20070211299.jpg" /></p>
<p>来个合影：</p>
<p><img height="300" width="400" alt="" src="http://p.blog.csdn.net/images/p_blog_csdn_net/dl88250/273209/o_20070211300.jpg" /></p>
<p><font color="#ff0000">索要地址</font>：<a href="http://www.intel.com/products/processor/manuals/index.htm">http://www.intel.com/products/processor/manuals/index.htm</a></p>
<p>&nbsp;</p>