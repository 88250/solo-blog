title: Maven 插件访问项目类路径
date: '2011-07-15 04:55:59'
updated: '2011-07-15 04:55:59'
tags: [Java, Maven 3, Maven 2, Maven, Apache]
permalink: /articles/2011/07/14/1310648159209.html
---
<p>写 Maven 插件的时候可能需要用到项目的类路径，例如插件反射项目的类再做后续处理。</p>
<p>在插件中如何获取项目类路径呢？官方插件（maven-compiler-plugin）为我们做出了示例，点击<a href="http://svn.apache.org/viewvc/maven/plugins/tags/maven-compiler-plugin-2.3.2/src/main/java/org/apache/maven/plugin/CompilerMojo.java?revision=992608&amp;view=markup" target="_blank">这里</a>查看其源码。</p>
<p>顺藤摸瓜，有两个点需要注意：</p>
<ul>
<li>@requiresDependencyResolution <span style="color: #ff0000;">compile</span><br />意味着在此插件执行前会准备好项目<span style="color: #000000;"> compile </span>作用域依赖<span style="color: #000000;">&nbsp;</span>作为类路径，取值参见下表：<br /> 
<table border="1">
<tbody>
<tr class="a">
<td><br /></td>
<td>system</td>
<td>provided</td>
<td>compile</td>
<td>runtime</td>
<td>test</td>
</tr>
<tr class="b">
<td><tt>compile</tt></td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>-</td>
<td>-</td>
</tr>
<tr class="a">
<td><tt>runtime</tt></td>
<td>-</td>
<td>-</td>
<td>X</td>
<td>X</td>
<td>-</td>
</tr>
<tr class="b">
<td><tt>compile+runtime</tt> (since Maven 3.0)</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>-</td>
</tr>
<tr class="a">
<td><tt>test</tt></td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>X</td>
</tr>
</tbody>
</table>
</li>
<li>@parameter default-value="${project.compileClasspathElements}<br />意味着<a href="http://svn.apache.org/viewvc/maven/plugins/tags/maven-compiler-plugin-2.3.2/src/main/java/org/apache/maven/plugin/CompilerMojo.java?revision=992608&amp;view=markup" target="_blank">示例</a>类中的成员属性 classpathElements 将保存 @requiresDependencyResolution 指明的类路径</li>
</ul>
<p>具体细节请移步：</p>
<ul>
<li><a href="http://maven.apache.org/guides/mini/guide-maven-classloading.html" target="_blank">Guide to Maven Classloading</a></li>
<li><a href="http://maven.apache.org/developers/mojo-api-specification.html" target="_blank">Mojo API Specification</a></li>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>