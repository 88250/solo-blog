title: 新书上架：《Java SE 实践教程》
date: '2009-06-09 01:21:00'
updated: '2009-06-09 01:21:00'
tags: [J2SE/JavaSE, Life in Programming]
permalink: /articles/2009/06/08/1244452860000.html
---
<p>在 NetBeans 中文社区参与了此书的写作，今年终于上架了 :-)</p>
<div><a href="http://www.china-pub.com/195637&amp;ref=ps" target="_blank">http://www.china-pub.com/195637&amp;ref=ps</a>
</div>
<div><a href="http://www.douban.com/subject/3730170/" target="_blank">http://www.douban.com/subject/3730170/</a>
</div>
<div><br />
</div>