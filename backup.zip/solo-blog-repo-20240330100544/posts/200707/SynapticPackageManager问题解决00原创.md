title: Synaptic Package Manager问题解决[00原创]
date: '2007-07-30 05:51:00'
updated: '2007-07-30 05:51:00'
tags: [My Linux]
permalink: /articles/2007/07/29/1185717060000.html
---
前天用deb安装包安装个SecondLife，因为耗时太长，我在中途退出了。<br />没想到今天要安装软件的时候出现问题了－ －!<br /><span class="postbody"> Reading package lists... Done <br /> Building dependency tree        <br /> Reading state information... Done <br /> E: The package **** needs to be reinstalled, but I can't find an archive for it.</span>   <br /><br />我汗死了，重新下SecondLife的安装包reinstall，出这个：<br /><br /><img src="http://p.blog.csdn.net/images/p_blog_csdn_net/dl88250/273209/o_Synaptic%20Package%20Manager%20ERROR.png" alt="" /><br /><br />晕死。。。。<br /><br />Google了一早上，解决方法如下：<br />sudo dpkg --remove --force-remove-reinstreq secondlift-install