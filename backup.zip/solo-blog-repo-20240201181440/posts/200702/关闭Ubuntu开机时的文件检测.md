title: 关闭Ubuntu开机时的文件检测
date: '2007-02-15 03:20:00'
updated: '2007-02-15 03:20:00'
tags: [My Linux]
permalink: /articles/2007/02/14/1171452000000.html
---
<span class="postbody">每次系统启动的时候<strong style="color: rgb(255, 163, 79);">文件系统检查</strong>程序总会花费很长时间来检查Win下面的分区，用下面的方法就可以关闭啦~<br /><br /></span><span class="postbody">sudo gedit /etc/fstab <br /> 找到fat32分区那一行，將最后一个数字改成0。。。。</span>