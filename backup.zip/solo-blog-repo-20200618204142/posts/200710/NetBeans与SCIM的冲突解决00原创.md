title: NetBeans与SCIM的冲突解决[00原创]
date: '2007-10-31 09:52:00'
updated: '2007-10-31 09:52:00'
tags: [NetBeans, My Linux]
permalink: /articles/2007/10/30/1193766720000.html
---
环境：Ubuntu 7.10，NetBeans 6 Beta2 + JDK 6<br />问题：在NetBeans里不能输入中文<br />解决： gedit netbeans_HOME/bin/netbeans<br />修改脚本开头为：<br />#!/bin/sh<br />export GTK_IM_MODULE=xim<br />export AWT_TOOLKIT=MToolkit <br />记得重启NetBeans&nbsp;&nbsp; :-)