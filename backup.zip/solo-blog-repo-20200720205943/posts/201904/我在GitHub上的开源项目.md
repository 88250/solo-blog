title: 我在 GitHub 上的开源项目
date: '2019-04-19 20:39:27'
updated: '2019-04-19 20:39:27'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo](https://github.com/88250/solo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`16`](https://github.com/88250/solo/watchers "关注数")&nbsp;&nbsp;[⭐️`716`](https://github.com/88250/solo/stargazers "收藏数")&nbsp;&nbsp;[🖖`198`](https://github.com/88250/solo/network/members "分叉数")&nbsp;&nbsp;[🏠`https://solo.b3log.org`](https://solo.b3log.org "项目主页")</span>

🎸 B3log 分布式社区的 Java 博客端节点系统，欢迎加入下一代社区网络。B3log distributed community blog-end node system, welcome to join the next generation community network. 



---

### 2. [baidu-netdisk-downloaderx](https://github.com/88250/baidu-netdisk-downloaderx) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`21`](https://github.com/88250/baidu-netdisk-downloaderx/watchers "关注数")&nbsp;&nbsp;[⭐️`599`](https://github.com/88250/baidu-netdisk-downloaderx/stargazers "收藏数")&nbsp;&nbsp;[🖖`126`](https://github.com/88250/baidu-netdisk-downloaderx/network/members "分叉数")</span>

⚡️ 一款图形界面的百度网盘不限速下载器，支持 Windows、Linux 和 Mac。已于 2020 年 4 月 15 日正式停用，源码仅用于程序员交流学习，细节请查看：关于停用 BND 的说明 https://hacpai.com/article/1586956316578



---

### 3. [symphony](https://github.com/88250/symphony) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`16`](https://github.com/88250/symphony/watchers "关注数")&nbsp;&nbsp;[⭐️`595`](https://github.com/88250/symphony/stargazers "收藏数")&nbsp;&nbsp;[🖖`127`](https://github.com/88250/symphony/network/members "分叉数")&nbsp;&nbsp;[🏠`https://sym.b3log.org`](https://sym.b3log.org "项目主页")</span>

🎶 一款用 Java 实现的现代化社区（论坛/问答/BBS/社交网络/博客）系统平台。A modern community (forum/Q&A/BBS/SNS/blog) system platform implemented in Java. https://hacpai.com



---

### 4. [liandi](https://github.com/88250/liandi) <kbd title="主要编程语言">TypeScript</kbd> <span style="font-size: 12px;">[🤩`15`](https://github.com/88250/liandi/watchers "关注数")&nbsp;&nbsp;[⭐️`426`](https://github.com/88250/liandi/stargazers "收藏数")&nbsp;&nbsp;[🖖`46`](https://github.com/88250/liandi/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hacpai.com/tag/liandi-biji`](https://hacpai.com/tag/liandi-biji "项目主页")</span>

📕 一款桌面端的 Markdown 笔记应用，支持 Windows、Mac 和 Linux。A desktop Markdown note-taking application, supports Windows, Mac and Linux. 



---

### 5. [awesome-seeds](https://github.com/88250/awesome-seeds) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`11`](https://github.com/88250/awesome-seeds/watchers "关注数")&nbsp;&nbsp;[⭐️`176`](https://github.com/88250/awesome-seeds/stargazers "收藏数")&nbsp;&nbsp;[🖖`16`](https://github.com/88250/awesome-seeds/network/members "分叉数")</span>

🌱 发现新鲜有趣的小型开源项目，欢迎投稿！



---

### 6. [lute](https://github.com/88250/lute) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`4`](https://github.com/88250/lute/watchers "关注数")&nbsp;&nbsp;[⭐️`173`](https://github.com/88250/lute/stargazers "收藏数")&nbsp;&nbsp;[🖖`18`](https://github.com/88250/lute/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hacpai.com/tag/lute`](https://hacpai.com/tag/lute "项目主页")</span>

🎼 一款对中文语境优化的 Markdown 引擎，支持 Go 和 JavaScript。A structured Markdown engine that supports Go and JavaScript. 



---

### 7. [pipe](https://github.com/88250/pipe) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`6`](https://github.com/88250/pipe/watchers "关注数")&nbsp;&nbsp;[⭐️`166`](https://github.com/88250/pipe/stargazers "收藏数")&nbsp;&nbsp;[🖖`39`](https://github.com/88250/pipe/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hacpai.com/tag/pipe`](https://hacpai.com/tag/pipe "项目主页")</span>

🎷 B3log 分布式社区的 Go 博客端节点系统，欢迎加入下一代社区网络。B3log distributed community blog-end node, welcome to join the next generation community network. 



---

### 8. [gulu](https://github.com/88250/gulu) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`5`](https://github.com/88250/gulu/watchers "关注数")&nbsp;&nbsp;[⭐️`58`](https://github.com/88250/gulu/stargazers "收藏数")&nbsp;&nbsp;[🖖`10`](https://github.com/88250/gulu/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hacpai.com/tag/gulu`](https://hacpai.com/tag/gulu "项目主页")</span>

⭕ Go 语言常用工具库，这个轱辘还算圆！



---

### 9. [wide](https://github.com/88250/wide) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`3`](https://github.com/88250/wide/watchers "关注数")&nbsp;&nbsp;[⭐️`57`](https://github.com/88250/wide/stargazers "收藏数")&nbsp;&nbsp;[🖖`15`](https://github.com/88250/wide/network/members "分叉数")&nbsp;&nbsp;[🏠`https://wide.b3log.org`](https://wide.b3log.org "项目主页")</span>

🌈 一款基于 Web 的 Go 语言 IDE，随时随地玩 golang。



---

### 10. [latke](https://github.com/88250/latke) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`4`](https://github.com/88250/latke/watchers "关注数")&nbsp;&nbsp;[⭐️`53`](https://github.com/88250/latke/stargazers "收藏数")&nbsp;&nbsp;[🖖`18`](https://github.com/88250/latke/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hacpai.com/tag/latke`](https://hacpai.com/tag/latke "项目主页")</span>

🌀 一款以 JSON 为主的 Java Web 框架。A Java Web framework based on JSON. 

