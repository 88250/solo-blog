title: 快来申请 b3log.org 二级域名吧！
date: '2011-09-04 08:38:26'
updated: '2013-10-25 05:06:40'
tags: [B3log Announcement, B3log, GAE, Open Source, Life in Programming]
permalink: /apply-b3log-domain.html
---
<p>----</p>
<p>Update: Oct 24, 2013</p>
<p>b3log 二级域名申请<a href="http://88250.b3log.org/close-apply-b3log-subdomain">已经关闭</a>，谢谢理解。</p>
<p>----</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>亲，还在为别人不能不能访问你的博客而苦恼？</p>
<p>亲，你不绑定自己的域名？</p>
<p>那，亲，不要再犹豫了，快发邮件给我申请 b3log.org 二级域名吧！</p>
<p>&nbsp;</p>
<p>----</p>
<p>邮箱：DL88250@gmail.com</p>
<p>邮件标题：申请 b3log.org 二级域名</p>
<p>内容提要：</p>
<ul>
<li>你的应用 id</li>
<li>需要的二级域名</li>
</ul>
<p>发完邮件后记得把应用共享给我。</p>
<p>--</p>
<p>应用共享方法：</p>
<p>1.&nbsp;<a href="http://appengine.google.com" target="_blank">点此</a>登录 GAE 管理控制台，进入要申请二级域名的应用</p>
<p>2. 左侧点击&nbsp;<span>Administration -&gt; <strong><span style="color: #0000ff;">Permissions </span></strong>一栏</span></p>
<p><span>3. 发邀请给我吧，<span style="color: #ff6600;"><strong>Owner</strong>&nbsp;</span>权限哦 ;-)</span></p>
<p>----</p>
<p>&nbsp;</p>
<p>P.S. 亲，绑定新域名后记得：</p>
<ol>
<li>修改 latke.props 配置，重新上传应用</li>
<li>修改偏好设定中的博客地址</li>
</ol>
<p>&nbsp;</p>