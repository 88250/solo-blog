title: GAE Java 应用性能优化
date: '2011-02-08 23:20:13'
updated: '2011-02-08 23:20:13'
tags: [GAE, Java]
permalink: /gae-java-performance-optimization.html
---
<h1 style="font-family: Verdana;">GAE Java 应用性能优化</h1>
<p style="font-family: Verdana;">转载请保留作者信息：</p>
<p style="font-family: Verdana;">作者：<a id="g4ll" title="88250's Blog" href="../../undefined/">88250</a></p>
<p>日期：2011 年 2 月 8 日</p>
<p>&nbsp;</p>
<p>本文是作者开发 GAE 应用的性能优化经验谈，主要从框架、缓存、异步调用等方面介绍了如何进行高性能 GAE 应用的设计及优化。</p>
<p style="padding-left: 30px;"><strong>ToC</strong></p>
<p style="padding-left: 60px;"><a href="gae-java-performance-optimization.html#memcache">使用 Memcache 进行缓存</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#cache-html">HTML 页面</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#cache-query-result">数据查询结果</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#memcache-note">Memcache 使用注意</a></p>
<p style="padding-left: 60px;"><a href="gae-java-performance-optimization.html#reduce-mem">减少内存使用</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#no-fwk">尽量避免使用框架</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#stateless">无状态设计</a></p>
<p style="padding-left: 60px;"><a href="gae-java-performance-optimization.html#async-apis">异步 APIs</a></p>
<p style="padding-left: 60px;"><a href="gae-java-performance-optimization.html#misc">其他</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#static-resources">静态资源</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#entity-group">实体组</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#naming">域名解析</a></p>
<p style="padding-left: 60px;">&nbsp;&nbsp;&nbsp; <a href="gae-java-performance-optimization.html#impl-logic">实现逻辑</a></p>
<p style="padding-left: 60px;"><a href="gae-java-performance-optimization.html#refs">参考资料</a></p>
<h2>使用 Memcache 进行缓存<a name="memcache"></a></h2>
<p>使用缓存主要是为了提高响应速度。</p>
<h3>HTML 页面<a name="cache-html"></a></h3>
<p>页面可以根据功能来划分进行缓存，请参考：<a href="articles/2010/12/21/1292901251292.html" target="_blank">应用 memcached 提升站点性能&mdash;&mdash;减少读自数据库和数据源</a>。</p>
<p>当然，也可以缓存整个页面，简化缓存及模板处理逻辑。</p>
<h3>数据查询结果<a name="cache-query-result"></a></h3>
<p>如果你是直接使用 GAE <a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/datastore/DatastoreService.html" target="_blank">DatastoreService</a> 来进行数据查询，那么有必要缓存查询结果：</p>
<ul>
<li>单一实体<br />根据唯一标识进行查询的实体。</li>
<li>集合实体<br />根据组合查询条件查询的实体，例如分页结果。</li>
</ul>
<h3>Memcache 使用注意<a name="memcache-note"></a></h3>
<ul>
<li>调用 GAE Memcache 也是会消耗一定 CPU 的（需要进行序列化/反序列化）</li>
<li>使用 GAE <a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/memcache/MemcacheService.html#clearAll%28%29" target="_blank">MemcaheService#clearAll()</a> 方法会清除所有命名空间的缓存</li>
</ul>
<h2>减少内存使用<a name="reduce-mem"></a></h2>
<p>减少内存使用主要是为了充分利用有限的 Memcache 服务，降低实例启动时间。</p>
<h3>尽量避免使用框架<a name="no-fwk"></a></h3>
<p>虽然目前一些流行的 Java Web 框架（Spring、Struts、Play!、etc）是可以运行在 GAE 上的，但如果你想尽量免费地使用 GAE，</p>
<p>那最好还是不要使用现有框架，因为，大多数框架：</p>
<ul>
<li>不是专门为 GAE 设计的</li>
<li>比较消耗内存</li>
<li>将延长启动时间</li>
</ul>
<p>另外，关于 JSP 与其他模板引擎的优劣取舍问题这里不讨论。目前经测试无页面缓冲情况下，FreeMarker 与 JSP 性能非常接近。</p>
<h3>无状态设计<a name="stateless"></a></h3>
<p>有状态的设计是比较吃内存的，服务端最好少使用有状态的模型，除非要处理复杂的业务逻辑（例如多步表单、高级搜索）。</p>
<h2>异步 APIs<a name="async-apis"></a></h2>
<p>GAE 提供了数据存取、HTTP 请求等 APIs 的异步版本。但需要注意：</p>
<ul>
<li>目前 GAE/J（1.4.0）中的 Query 是没有异步 APIs 的<br /><a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/datastore/AsyncDatastoreService.html" target="_blank">AsyncDatastoreService</a> 或者 <a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/datastore/DatastoreService.html" target="_blank">DatastoreService</a> 上使用<a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/datastore/PreparedQuery.html#asIterable%28%29"> PreparedQuery.asIterable()</a> 与 <a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/datastore/PreparedQuery.html#asIterator%28%29">PreparedQuery.asIterator()</a> <br />效果一样，都是调用了就返回，迭代时才真正去获取数据</li>
<li><span style="color: #000000;">阻塞（同步）点<br />异步 APIs 调用后的代码块中要注意在哪个点进行同步，过早进行同步将降低异步 APIs 带来的优势。</span></li>
<li><span style="color: #000000;">调用异步 APIs 与调用同步 APIs 消耗同样的配额<br /></span></li>
</ul>
<h2>其他<a name="misc"></a></h2>
<h3>静态资源<a name="static-resources"></a></h3>
<p>仔细配置 appengine-web.xml 中 &lt;static-files&gt; 元素，这些资源将从单独的 Google 服务器、缓存获取，并不占用</p>
<p>应用服务器配额。</p>
<h3>实体组<a name="entity-group"></a></h3>
<p>实体组是具有一定逻辑关系的、保存在同一 GAE 云存储区域的实体集。事务操作只能针对同一实体组的实体操作。</p>
<p>实体组对性能有一定影响（目前尚未实践证明影响有多大），但请尽量保持实体组的最小化。</p>
<h3>域名解析<a name="naming"></a></h3>
<p>GAE 送的二级域名（*.appspot.com）在国内访问非常不稳定，所以最好绑定绑定自己的域名。</p>
<p>但绑定域名时需要配置 GHS IP，目前在国内已经没有 IP 可用。进一步，需要配置反向代理来进行请求代理。</p>
<p>在服务端性能优化后需要选择一个速度快、稳定的反向代理。不然，辛辛苦苦在服务端优化降低了几百 ms 的处理时间，</p>
<p>结果全耗在路由、丢包上了 :-(</p>
<p>如果免费的反向代理实在不能够满足性能需要，只能自己打个付费的了，或者等到 GHS 可用。。。。</p>
<h3>实现逻辑<a name="impl-logic"></a></h3>
<p>另外，目前 GAE 给的免费 CPU 配额比较少，所以优化实现逻辑以减少 CPU、APIs 使用也是非常关键的。</p>
<p>写代码时应该时刻注意代码的逻辑是否足够简洁，能一次性获取的参数就别重复获取，获取后以方法参数的形式进行传递。</p>
<h2>参考资料<a name="refs"></a></h2>
<ul>
<li><a href="http://code.google.com/appengine/docs/java/overview.html" target="_blank">App Engine Java Overview</a></li>
<li><a href="http://code.google.com/appengine/articles/scaling/overview.html" target="_blank">Best practices for writing scalable applications</a></li>
<li><a href="http://code.google.com/appengine/docs/java/javadoc/" target="_blank">GAE SDK Javadoc</a></li>
<li><a href="gae-transaction.html" target="_blank">GAE 数据存储&mdash;&mdash;事务</a></li>
<li><a href="http://code.google.com/p/latke/" target="_blank">GAE/Java 应用框架&mdash;&mdash;B3log Latke</a></li>
</ul>