title: SourceForge不能上了？
date: '2008-07-10 23:15:00'
updated: '2008-07-10 23:15:00'
tags: [Open Source]
permalink: /articles/2008/07/10/1215674100000.html
---
<font color="#ff0000"><font color="#000000">SourceForge.net 被封了（貌似是DNS解析有问题），虽然可以通过代理访问，但是上面的源代码和开源的项目还是下载不了。今天早上用Google搜索文件时，无意中发现了一个可以下载 SourceForge.net上面的源码和项目的网站，这是SourceForge.net的一个镜像网站。</font></font>
<p><a href="http://www.mirrorservice.org/mirrors">http://www.mirrorservice.org/mirrors</a> 这是镜像的主页，打开后可以看到里面有许多网站的镜像，其他的我们就不管了，我们只管SourceForge.net这个风站的镜像，地址如下，可以直接打开下面的地址就OK了，建议使用FireFox访问，速度明显快很多~~</p>
<p><a href="http://www.mirrorservice.org/sites/download.sourceforge.net/pub/sourceforge/%5Bpeek%5D">http://www.mirrorservice.org/sites/download.sourceforge.net/pub/sourceforge/%5Bpeek%5D</a></p>
转自：http://hi.baidu.com/wowodo/blog/item/5ac9b31b669e231c8718bfd5.html