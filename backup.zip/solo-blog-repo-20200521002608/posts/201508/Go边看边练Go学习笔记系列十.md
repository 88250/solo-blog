title: Go 边看边练 -《Go 学习笔记》系列（十）
date: '2015-08-05 06:40:13'
updated: '2015-12-29 22:43:12'
tags: [Golang, Go学习笔记, 教程, 雨痕]
permalink: /articles/2015/08/04/1438699210452.html
---
上一篇： [1438596722873] 

----

### ToC

* [Go 边看边练 -《Go 学习笔记》系列（一）- 变量、常量](http://symphony.b3log.org/article/1437497122181)
* [Go 边看边练 -《Go 学习笔记》系列（二）- 类型、字符串](http://symphony.b3log.org/article/1437558810339)
* [Go 边看边练 -《Go 学习笔记》系列（三）- 指针](http://symphony.b3log.org/article/1437719712835)
* [Go 边看边练 -《Go 学习笔记》系列（四）- 控制流1](http://symphony.b3log.org/article/1437984612418)
* [Go 边看边练 -《Go 学习笔记》系列（五）- 控制流2](http://symphony.b3log.org/article/1438070631857)
* [Go 边看边练 -《Go 学习笔记》系列（六）- 函数](http://symphony.b3log.org/article/1438164538421)
* [Go 边看边练 -《Go 学习笔记》系列（七）- 错误处理](http://symphony.b3log.org/article/1438260619759)
* [Go 边看边练 -《Go 学习笔记》系列（八）- 数组、切片](http://symphony.b3log.org/article/1438311936449)
* [Go 边看边练 -《Go 学习笔记》系列（九）- Map、结构体](http://symphony.b3log.org/article/1438596722873)
* [Go 边看边练 -《Go 学习笔记》系列（十）- 方法](http://symphony.b3log.org/article/1438699210452)
* [Go 边看边练 -《Go 学习笔记》系列（十一）- 表达式](http://symphony.b3log.org/article/1438763483577)
* [Go 边看边练 -《Go 学习笔记》系列（十二）- 接口](http://symphony.b3log.org/article/1438845728987)
* [Go 边看边练 -《Go 学习笔记》系列（十三）- Goroutine](http://symphony.b3log.org/article/1438938175118)
* [Go 边看边练 -《Go 学习笔记》系列（十四）- Channel](http://symphony.b3log.org/article/1439194647152)

----

### 5.1 方法定义

方法总是绑定对象实例，并隐式将实例作为第一实参 (receiver)。

* 只能为当前包内命名类型定义方法。
* 参数 `receiver` 可任意命名。如方法中未曾使用，可省略参数名。
* 参数 `receiver` 类型可以是 `T` 或 `*T`。基类型 `T` 不能是接口或指针。
* 不支持方法重载，`receiver` 只是参数签名的组成部分。
* 可用实例 `value` 或 `pointer` 调用全部方法，编译器自动转换。

没有构造和析构方法，通常用简单工厂模式返回对象实例。

    type Queue struct {
    	elements []interface{}
    }
    
    func NewQueue() *Queue { // 创建对象实例。
    	return &Queue{make([]interface{}, 10)}
    }
    
    func (*Queue) Push(e interface{}) error { // 省略 receiver 参数名。
    	panic("not implemented")
    }
    
    // func (Queue) Push(e int) error { // Error: method redeclared: Queue.Push
    // 		panic("not implemented")
    // }
    
    func (self *Queue) length() int { // receiver 参数名可以是 self、this 或其他。
    	return len(self.elements)
    }

方法不过是一种特殊的函数，只需将其还原，就知道 `receiver` `T` 和 `*T` 的差别。

<iframe style="border:1px solid" src="https://wide.b3log.org/playground/8e4b597c71c3d3566ae6f8334f0d1ee7.go?embed=true" width="99%" height="680"></iframe>

从 1.4 开始，不再支持多级指针查找方法成员。

    type X struct{}

	func (*X) test() {
    	println("X.test")
    }
    
    func main() {
    	p := &X{}
        p.test()
        
        // Error: calling method with receiver &p (type **X) requires explicit dereference
        // (&p).test()
    }

### 5.2 匿名字段

可以像字段成员那样访问匿名字段方法，编译器负责查找。

<iframe style="border:1px solid" src="https://wide.b3log.org/playground/67600a9a520592a806da510f58be64fa.go?embed=true" width="99%" height="600"></iframe>

通过匿名字段，可获得和继承类似的复用能力。依据编译器查找次序，只需在外层定义同名方法，就可以实现 "override"。

<iframe style="border:1px solid" src="https://wide.b3log.org/playground/69aa1e0de79d63b17e74bf224ea9eb7f.go?embed=true" width="99%" height="700"></iframe>

### 5.3 方法集

每个类型都有与之关联的方法集，这会影响到接口实现规则。

• 类型 `T` 方法集包含全部 `receiver` `T` 方法。
• 类型 `*T` 方法集包含全部 `receiver` `T` + `*T` 方法。
• 如类型 `S` 包含匿名字段 `T`，则 S 方法集包含 `T` 方法。
• 如类型 `S` 包含匿名字段 `*T`，则 S 方法集包含 `T` + `*T` 方法。
• 不管嵌入 `T` 或 `*T`，`*S` 方法集总是包含 `T` + `*T` 方法。

用实例 `value` 和 `pointer` 调用方法 (含匿名字段) 不受方法集约束，编译器总是查找全部方法，并自动转换 `receiver` 实参。

下一篇： [1438763483577] 

----

* ***本系列是基于***[雨痕](https://github.com/qyuhen)***的***[《Go 学习笔记》（第四版）](https://github.com/qyuhen/book/blob/master/Go%20%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0%20%E7%AC%AC%E5%9B%9B%E7%89%88.pdf)***整理汇编而成，非常感谢雨痕的辛勤付出与分享！***
* 转载请注明：文章转载自：**黑客与画家的社区** [[http://symphony.b3log.org](http://symphony.b3log.org)]
* 如果你觉得本章节做得不错，请在下面打赏一下吧~

----

> 社区小贴士
>
> * 关注标签 [golang] 可以方便查看 Go 相关帖子
> * 关注标签 [Go学习笔记] 可以方便查看本系列
> * 关注作者后如有新帖将会收到通知

<p style='font-size: 12px;'><i>该文章同步自 <a href='http://hacpai.com/article/1438699210452' target='_blank'>黑客派</a></i></p>