title: NetBeans 时讯翻译团队礼物
date: '2011-12-23 01:04:27'
updated: '2011-12-23 17:46:18'
tags: [NetBeans, Translation, Life in Programming, Open Source]
permalink: /articles/2011/12/22/1324544667307.html
---
<p>记得从上次收到礼物到现在已经两年多了吧，最近半年我一直在联系 Oracle NetBeans 相关人员，<br /> 希望为我们这个<a href="http://wiki.netbeans.org/Nb6newsletter_zh_CN">团队</a>争取一下礼物 ;-)<br /> <br />今天礼物寄过来了，希望大家喜欢：</p>
<ol>
<li>Translation Team T恤（以前的那个版本，尺码都是 L）</li>
<li>NetBeans Cube（可以摆着看）</li>
<li>NetBeans 圆珠笔</li>
<li>U盘（2G）</li>
</ol>
<p><img src="https://public.sn2.livefilestore.com/y1piNOzaDwVo7oXn0_2mrT024lGjiVsG98U-sF80LjPKgIrlwxLKvrSgCalvOzWx7p5mE4raWA7X85dOdj34kLXrA/%E6%8B%BC%E5%9B%BE2011_12_22_10_04_09.jpg?psid=1" alt="Souvenir" width="631" height="866" /></p>
<p>有需要的同学请联系我，顺便附上你的邮寄地址 ;-)</p>
<p>&nbsp;</p>
<p>----<br />P.S. 关税收了我 ￥510....</p>