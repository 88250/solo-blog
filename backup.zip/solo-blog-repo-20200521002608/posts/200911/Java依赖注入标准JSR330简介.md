title: Java 依赖注入标准（JSR-330）简介
date: '2009-11-20 15:48:00'
updated: '2009-11-20 15:48:00'
tags: [JSR-299, J2SE/JavaSE, Architecture Design, J2EE/JavaEE]
permalink: /articles/2009/11/19/1258674480000.html
---
<h1 style="FONT-FAMILY:Verdana">
  Java 依赖注入标准（JSR-330）简介
</h1>
<p style="FONT-FAMILY:Verdana">
  转载请保留作者信息：</p>
<p style="FONT-FAMILY:Verdana">
  作者：<a id="g4ll" title="88250's Blog" href="http://blog.csdn.net/DL88250" title="88250's Blog">88250</a>
，<a id="xx6q" title="Vanessa's Blog" href="http://blog.csdn.net/Vanessa219" title="Vanessa's Blog">Vanessa</a>

</p>
<p style="FONT-FAMILY:Verdana">
  时间：2009 年 11 月 19 日</p>
<p>
<br />

&nbsp;&nbsp;&nbsp;&nbsp; Java 依赖注入标准（JSR-330，Dependency Injection for Java）1.0 规范已于今年 10 月份<a id="qee6" title="发布" href="http://blog.csdn.net/DL88250/archive/2009/10/16/4679164.aspx" title="发布">发布</a>
。该规范主要是面向依赖注入使用者，而对注入器实现、配置并未作详细要求。目前 <a id="gmwa" title="Spring" href="http://www.springsource.org/node/2174" title="Spring">Spring</a>
、<a id="q4h:" title="Guice" href="http://code.google.com/p/google-guice/" title="Guice">Guice</a>
 已经开始兼容该规范，JSR-299（Contexts and Dependency Injection for Java EE platform，参考实现 <a id="o0j0" title="Weld" href="http://seamframework.org/Weld" title="Weld">Weld</a>
）在依赖注入上也使用该规范。JSR-330 规范并未按 JSR 惯例发布规范文档，只发布了规范 API 源码，本文翻译了该规范 API 文档（Javadoc）以作为对 Java 依赖注入标准规范的简介。</p>
<div id="WritelyTableOfContents" class="writely-toc">
  <ol class="writely-toc-decimal">
<li>
      <a href="#javax_inject_40504930880883183_2007533775100061" target="_self">javax.inject</a>

    </li>
<li>
      <a href="#_Inject_6802068962399098_56394_26207626942120477" target="_self">@Inject</a>

      <ol class="writely-toc-subheading writely-toc-disc" style="MARGIN-LEFT:0pt">
<li>
          <a href="#_7534470724411853_742038611373_8582904548586772" target="_self">限定器</a>

        </li>
<li>
          <a href="#_1763349362688431_111739045016_0020549850838221806" target="_self">可注入的值</a>

        </li>
<li>
          <a href="#_8464816905984055_785867212452" target="_self">循环依赖</a>

        </li>
</ol>

    </li>
<li>
      <a href="#_Qualifier_9535574146353466_06" target="_self">@Qualifier</a>

    </li>
<li>
      <a href="#Provider_003165169731463413_78_6869560700092526" target="_self">Provider</a>

      <ol class="writely-toc-subheading writely-toc-disc" style="MARGIN-LEFT:0pt">
<li>
          <a href="#get_" target="_self">get()</a>

        </li>
</ol>

    </li>
<li>
      <a href="#_Named_1262163341270509_233694_37767472601897867" target="_self">@Named</a>

    </li>
<li>
      <a href="#_Scope_6014748620887402_713421_7367540373832964" target="_self">@Scope</a>

    </li>
<li>
      <a href="#_Singleton_3104547156494192_71_7467978559797065" target="_self">@Singleton</a>

    </li>
</ol>

</div>
<p>&nbsp;</p>
<div>
<h2>
    <a id="javax_inject_40504930880883183_2007533775100061" name="javax_inject_40504930880883183_2007533775100061"></a>
javax.inject
  </h2>
&nbsp;&nbsp;&nbsp;&nbsp; 包 javax.inject 指定了获取对象的一种方法，该方法与构造器、工厂以及服务定位器（例如 JNDI））这些传统方法相比可以获得更好的可重用性、可测试性以及可维护性。此方法的处理过程就是大家熟知的依赖注入，它对于大多数应用是非常有价值的。<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 在我们的程序中，很多类型依赖于其他类型。例如，一个 Stopwatch 可能依赖于一个 TimeSource。一些类型被另一个类型依赖，我们就把这些类型叫做这个类型的<strong>依赖（物）</strong>
。在运行时查找一个依赖实例的过程叫做<strong>解析</strong>
<strong>依赖</strong>
。如果找不到依赖的实例，那我们称该依赖为<strong>不能满足的</strong>
，并导致应用运行失败。<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 在不使用依赖注入时，对象的依赖解析有几种方式。最常见的就是通过编写直接调用构造器的代码完成：<span style="FONT-FAMILY:Courier New"><br />

  <br />

  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; class Stopwatch {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; final TimeSource timeSource;</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Stopwatch () {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; timeSource = new AtomicClock(...);</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; void start() { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; long stop() { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }<br />

  <br />

  <span style="font-family: Arial;">&nbsp;&nbsp;&nbsp;&nbsp; </span>
<span style="FONT-FAMILY:Verdana">如果需要更有弹性一点，那么我们可以通过工厂或服务定位器实现：</span>
</span>
<br />

  <br />

  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="FONT-FAMILY:Courier New">class Stopwatch {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; final TimeSource timeSource;</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Stopwatch () {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; timeSource = DefaultTimeSource.getInstance();</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; void start() { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; long stop() { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }<br />

  <br />

  <span style="font-family: Arial;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="FONT-FAMILY:Verdana">在使用这些传统方式进行依赖解析时，程序员必须</span>
</span>
<span style="FONT-FAMILY:Verdana">做出适当权衡。构造器非常简洁，但却有一些限制（对象生存期，对象复用）。工厂确实解耦了客户与实现，但却需要样本式的代码。</span>
</span>
<span style="FONT-FAMILY:Verdana">服务定位器更进一步地解耦了客户与实现，但却降低了编译时的类型安全。并且，这三个方式都不适合进行单元测试。例如，当程序员使用工厂时，该工厂的</span>
<span style="FONT-FAMILY:Verdana">每一个</span>
<span style="FONT-FAMILY:Verdana">产品都必须模拟出来，测试完后还要得记得清理：</span>
<br />

  <br />
<div style="MARGIN-LEFT:40px">
    <span style="FONT-FAMILY:Courier New">&nbsp;void testStopwatch() {</span>
<br style="FONT-FAMILY:Courier New" />

  </div>
<span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TimeSource original = DefaultTimeSource.getInstance();</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; DefaultTimeSource.setInstance(new MockTimeSource());</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; try {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; // Now, we can actually test Stopwatch.</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Stopwatch sw = new Stopwatch();</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ...</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; } finally {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; DefaultTimeSource.setInstance(original);</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }<br />

  <br />

  <span style="font-family: Arial;">&nbsp;&nbsp;&nbsp;&nbsp; 现实中，</span>
<span style="FONT-FAMILY:Verdana">要模拟工厂将导致更多的样本式代码。测试模拟出的产品并清理它们在依赖多的情况下很快就控制不了了。更糟的是，程序员必须精确地预测</span>
未来到底需要多少这样的弹性，并为他做的&ldquo;弹性选择&rdquo;负责。如果程序员开始时选择了构造器方式，但后来需要一个更有弹性的方式，那他就不得不替换所有调用构造器的代码。</span>
如果程序员一开始过于谨慎地选择了工厂方式，结果可能导致要编写很多额外的样本式代码，引入了不必要的复杂度，潜在的问题比比皆是。<br />

  &nbsp;&nbsp;&nbsp;&nbsp; <strong>依赖注入</strong>
就是为了解决这些问题。代替程序员调用构造器或工厂，一个称作<strong>依赖注入器</strong>
的工具将把依赖传递给对象：<br />

  <br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; class Stopwatch {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; final TimeSource timeSource;</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; @Inject Stopwatch(TimeSource timeSource) {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; this.TimeSource = timeSource;</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; void start() { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; long stop() { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }<br />

  <br />

  <span style="FONT-FAMILY:Verdana">&nbsp;&nbsp;&nbsp;&nbsp; 注入器将更进一步地传递依赖给其他的依赖，直到</span>
</span>
<span style="FONT-FAMILY:Courier New"><span style="FONT-FAMILY:Verdana">它</span>
</span>
<span style="FONT-FAMILY:Courier New"><span style="FONT-FAMILY:Verdana">构造出整个</span>
</span>
<span style="FONT-FAMILY:Verdana">对象图</span>
<span style="FONT-FAMILY:Courier New"><span style="FONT-FAMILY:Verdana">。</span>
例如，假设一个程序员需要注入器创建一个 </span>
StopwatchWidget 实例：<br />

  <br />
<div style="MARGIN-LEFT:40px">
    <span style="FONT-FAMILY:Courier New">&nbsp;/** GUI for a Stopwatch */</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;class StopwatchWidget {</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp; @Inject StopwatchWidget(Stopwatch sw) { ... }</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp; ...</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;}</span>
<br />

    <br style="FONT-FAMILY:Courier New" />

  </div>
&nbsp;&nbsp;&nbsp;&nbsp; 注入器可能会：<br />

</div>
<ol>
<li>
    查找一个 TimeSource 实例
  </li>
<li>
    使用找到的 TimeSource 实例构造一个 Stopwatch
  </li>
<li>
    使用构造的 Stopwatch 实例构造一个 StopwatchWidget
  </li>
</ol>
<p>
&nbsp;&nbsp;&nbsp;&nbsp; 这使得代码保持干净，使得程序员感到使用依赖（物）的基础设施非常容易。</p>
<div>
  &nbsp;&nbsp;&nbsp;&nbsp; 现在，在单元测试中，程序员可以直接构造对象（不使用注入器）并将该对象以模拟依赖的方式直接传入待测对象的构造中。程序员再也不需要为每一次测试都配置并清理工厂或服务定位器。这大大简化了我们的单元测试：<br />

  <br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; void testStopwatch() {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Stopwatch sw = new Stopwatch(new MockTimeSource());</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ...</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }</span>
<br style="FONT-FAMILY:Courier New" />

  <br />

  &nbsp;&nbsp;&nbsp;&nbsp; 完全降低了单元测试的复杂度，降低的复杂程度与待测对象的数目及其依赖成正比。<br />

  <strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 包 javax.inject 为使用这样的轻便类提供了依赖注入注解</strong>
，但没有引入依赖配置方式。依赖配置方式取决于注入器的实现。程序员只需要标注了构造器、方法或字段来说明它们的可注入性（上面的例子就是构造器注入）。依赖注入器通过这些注解来识别一个类的依赖，并在运行时注入这些依赖。此外，注入器要能够在<strong>构建时</strong>
验证所有的依赖是否满足。相比之下，服务定位器在构建时是不能检测到依赖不满足情况的，直到运行时才能发现。<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 注入器实现有很多形式。一个注入器可以通过 XML、注解、DSL（领域规约语言），或是普通 Java 代码来进行配置。注入器实现可以使用反射或代码生成。使用编译时代码生成的注入器甚至可能没有它自己的运行时描述。而其他注入器实现无论在编译时还是运行时可能都不使用代码生成。一个&ldquo;容器&rdquo;，其实可以把它定义为一个注入器，不过包 javax.inject 不涉及非常大概念，旨在最小化注入器实现的限制。<br />

</div>
<p>
<br />

&nbsp;&nbsp;&nbsp;&nbsp; 请查阅：<br />

&nbsp;&nbsp;&nbsp;&nbsp; <a id="e8a6" title="@Inject" href="#_Inject_6802068962399098_56394_26207626942120477" target="_self" title="@Inject">@Inject</a>
</p>
<div>
<h2>
    <a id="_Inject_6802068962399098_56394_26207626942120477" name="_Inject_6802068962399098_56394_26207626942120477"></a>
@Inject
  </h2>
&nbsp;&nbsp;&nbsp;&nbsp; 注解 @Inject 标识了可注入的构造器、方法或字段。可以用于静态或实例成员。一个可注入的成员可以被任何访问修饰符（private、package- private、protected、public）修饰。注入顺序为构造器，字段，最后是方法。超类的字段、方法将优先于子类的字段、方法被注入。对于同一个类的字段是不区分注入顺序的，同一个类的方法亦同。<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 可注入的构造器指的是标注了 @Inject 并接受 0 个或多个依赖作为实参的构造器。对于每一个类而言，@Inject 最多只允许对一个类的一个构造器进行标注：<br />

  <span style="FONT-FAMILY:Courier New"><br />

  &nbsp;&nbsp; <span style="font-size: x-small;">@Inject<br />

  &nbsp;&nbsp; ConstructorModifiers<sub>opt</sub>
 SimpleTypeName(FormalParameterList<sub>opt</sub>
) Throws<sub>opt </sub>
&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; ConstructorBody</span>
</span>
<br style="FONT-FAMILY:Courier New" />

  <br />

  &nbsp;&nbsp;&nbsp; @Inject 对于仅存在默认构造器（访问修饰符为 public 并且无参数）的情况是可选的，注入器将调用默认构造器：<br />

  <br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @Inject<sub>opt </sub>
<br />

  &nbsp;&nbsp; Annotations<sub>opt</sub>
<br />

  &nbsp;&nbsp; public SimpleTypeName() Throws<sub>opt</sub>
 ConstructorBody<br />

  <br />

  <span style="FONT-FAMILY:Verdana">&nbsp;&nbsp;&nbsp;&nbsp; 可注入的字段：</span>
<br />

  </span>

  
<ul>
<li>
      被 @Inject 标注。
    </li>
<li>
      不是 final 的。
    </li>
<li>
      可以使用任何有效名。
    </li>
</ul>
<br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @Inject FieldModifiers<sub>opt</sub>
 Type VariableDeclarators;</span>
<br />

  <br />

  &nbsp;&nbsp;&nbsp;&nbsp; 可注入的方法：<br />

  
<ul>
<li>
      被 @Inject 标注。
    </li>
<li>
      不是 abstract 的。
    </li>
<li>
      没有声明类型参数的方法。
    </li>
<li>
      可以带返回值。
    </li>
<li>
      可以使用任何有效名。
    </li>
<li>
      接受 0 个或多个依赖作为实参。
    </li>
</ul>
<br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @Inject MethodModifiers<sub>opt</sub>
 ResultType Identifier(FormalParameterList<sub>opt</sub>
)&nbsp;&nbsp;&nbsp;<br />

  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Throws<sub>opt</sub>
 MethodBody<br />

  <br />

  <span style="FONT-FAMILY:Verdana">&nbsp;&nbsp;&nbsp;&nbsp; 注入器忽略了注入方法的返回值，因为方法的非空返回可能会用于其他上下文（例如 builder-style 的方法链）。</span>
<br style="FONT-FAMILY:Verdana" />

  <span style="FONT-FAMILY:Verdana">&nbsp;&nbsp;&nbsp;&nbsp; 例子：</span>
</span>
<br />

  <br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; public class Car {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; // Injectable constructor</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; @Inject public Car(Engine engine) { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; // Injectable field</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; @Inject private Provider&lt;Seat&gt; seatProvider;</span>
<br style="FONT-FAMILY:Courier New" />

  <br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; // Injectable package-private method</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; @Inject void install(Windshield windshield, Trunk trunk) { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; }<br />

  <span style="font-family: Verdana;"><br />

  &nbsp;&nbsp;&nbsp;&nbsp; 当一个方法标注了 @Inject 并覆写了其他标注了 @Inject 的方法时，对于每一个实例的每一次注入请求，该方法只会被注入一次。当一个方法没有标注 @Inject 并覆写了其他标注了 @Inject 的方法时，该方法不会被注入。<br />

  </span>
</span>
&nbsp;&nbsp;&nbsp;&nbsp; 要进行成员注入就必须标注 @Inject。一个可注入的成员可以使用任何访问修饰符（包括 private）。不过受于平台或注入器限制（例如安全管理或缺乏反射支持），标注了 @Inject 的非公有成员可能将不被注入。<br />

  <br />
<h3>
    <a id="_7534470724411853_742038611373_8582904548586772" name="_7534470724411853_742038611373_8582904548586772"></a>
<strong>限定器</strong>

  </h3>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="#_Qualifier_9535574146353466_06">限定器</a>
注解用于标注可注入的字段或参数，外加该字段或参数的类型，就可以标识出待注入的实现。限定符是可选的，当与 @Inject 一起使用在与注入器无关的类时，对于一个字段或参数，应该最多只有一个限定符被标注。在下面的例子中，限定符被标注了粗体：<br />

  <br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; public class Car {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; @Inject private <strong>@Leather</strong>
 Provider&lt;Seat&gt; seatProvider;</span>
<br style="FONT-FAMILY:Courier New" />

  <br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; &nbsp; &nbsp; @Inject void install(<strong>@Tinted</strong>
 Windshield windshield,</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>@Big</strong>
 Trunk trunk) { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; }</span>
<br />

  <br />

  &nbsp;&nbsp;&nbsp;&nbsp; 如果一个可注入的方法覆写了其他方法，覆写方法的参数不会自动地从被覆写的方法上继承限定器。<br />
<h3>
    <a id="_1763349362688431_111739045016_0020549850838221806" name="_1763349362688431_111739045016_0020549850838221806"></a>
可注入的值
  </h3>
&nbsp;&nbsp;&nbsp;&nbsp; 对于一个给定的类型 T 与可选的限定器，注入器必须能够注入用户指定的类：<br />

</div>
<p>
&nbsp;&nbsp;&nbsp;&nbsp; a. 与 T 是赋值兼容的，并且</p>
<div>
  &nbsp;&nbsp;&nbsp;&nbsp; b. 有一个可注入的构造器。<br />
<div>
    &nbsp;&nbsp;&nbsp;&nbsp; 例如，用户可能使用外部配置来选择一个 T 的实现。此外，待注入的值取决于注入器实现与它的配置。<br />
<h3>
      <a id="_8464816905984055_785867212452" name="_8464816905984055_785867212452"></a>
循环依赖
    </h3>
&nbsp;&nbsp;&nbsp;&nbsp; 本规范并未详细要求探测循环依赖与解析循环依赖。两个构造器间的循环依赖是一个非常明显的问题，另外，对于可注入字段或方法的循环依赖也很常见，例如：<br />

    <br />

    <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; class A {</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; @Inject B b;</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; }</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; class B {</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; @Inject A a;</span>
<br style="FONT-FAMILY:Courier New" />

    <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; }</span>
<br />

    <br />

    &nbsp;&nbsp;&nbsp;&nbsp; 当构造 A 的一个实例时，一个简单的注入器可能会无限循环构造：B 的一个实例注入给 A 的一个实例，第二个 A 的实例注入给 B 的一个实例，第二个 B 的实例注入给第二个 A 的实例，&hellip;&hellip;<br style="FONT-FAMILY:Courier New" />

    &nbsp;&nbsp;&nbsp;&nbsp; 一个保守的注入器可能会在构建时探测出这个循环依赖，并生成一个错误，指出程序员可以使用<a id="hifs" title="Provider&lt;A&gt;" href="#Provider_003165169731463413_78_6869560700092526" target="_self" title="Provider&lt;A&gt;">Provider&lt;A&gt;</a>
或 Provider&lt;B&gt; 对应替换 A 或 B 来打破这个循环依赖。从注入的构造器或方法调用该 provider 的 <a href="#Provider_003165169731463413_78_6869560700092526">get()</a>
 将打破这个循环依赖。对于方法或字段注入的情况，将其依赖的一边放置到某作用域（例如<a href="#_Singleton_3104547156494192_71_7467978559797065">单例作用域</a>
）也可以使得循环依赖能够被注入器解析。<br />

  </div>
</div>
<p>
<br />

&nbsp;&nbsp;&nbsp;&nbsp; 请查阅：<br />

&nbsp;&nbsp;&nbsp;&nbsp; <a id="s.ek" title="@Qualifier" href="#_Qualifier_9535574146353466_06" target="_self" title="@Qualifier">@Qualifier</a>
<br />

&nbsp;&nbsp;&nbsp;&nbsp; <a id="z6bo" title="@Provider" href="#Provider_003165169731463413_78_6869560700092526" target="_self" title="@Provider">@Provider</a>
</p>
<h2>
  <a id="_Qualifier_9535574146353466_06" name="_Qualifier_9535574146353466_06"></a>
@Qualifier<br />

</h2>
<p>
&nbsp;&nbsp;&nbsp;&nbsp; 注解 @Qualifier 用于标识限定器注解。任何人都可以定义新的限定器注解。一个限定器注解：</p>
<div>
  
<ul>
<li>
      是被 @Qualifier、@Retention(RUNTIME) 标注的，通常也被 @Documented 标注。
    </li>
<li>
      可以拥有属性。
    </li>
<li>
      可能是公共 API 的一部分，就像依赖类型一样，而不像类型实现那样不作为公共 API 的一部分。
    </li>
<li>
      如果标注了 @Target 可能会有一些用法限制。本规范只是指定了限定器注解可以被使用在字段和参数上，但一些注入器配置可能使用限定器注解在其他一些地方（例如方法或类）上。
    </li>
</ul>
&nbsp;&nbsp;&nbsp;&nbsp; 例子：<br />

  <br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @java.lang.annotation.Documented</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @java.lang.annotation.Retention(RUNTIME)</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @javax.inject.Qualifier</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; public @interface Leather {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Color color() default Color.TAN;</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; public enum Color { RED, BLACK, TAN }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; }<br />

  <br style="FONT-FAMILY:Courier New" />

  </span>
&nbsp;&nbsp;&nbsp;&nbsp; 请查阅：<br />

  &nbsp;&nbsp;&nbsp;&nbsp; <a id="grju" title="@Named" href="#_Named_1262163341270509_233694_37767472601897867" target="_self" title="@Named">@Named</a>
<br />

  <br />
<h2>
    <a id="Provider_003165169731463413_78_6869560700092526" name="Provider_003165169731463413_78_6869560700092526"></a>
Provider&lt;T&gt;
  </h2>
&nbsp;&nbsp;&nbsp;&nbsp; 接口 Provider 用于提供类型 T 的实列。Provider 是一般情况是由注入器实现的。对于任何可注入的 T 而言，您也可以注入 Provider&lt;T&gt;。与直接注入 T 相比，注入 Provider&lt;T&gt; 使得：<br />

  
<ul>
<li>
      可以返回多个实例。
    </li>
<li>
      实例的返回可以延迟化或可选
    </li>
<li>
      打破循环依赖。
    </li>
<li>
      可以在一个已知作用域的实例内查询一个更小作用域内的实例。
    </li>
</ul>
&nbsp;&nbsp;&nbsp;&nbsp; 例子：<br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; </span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; class Car {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; @Inject Car(Provider&lt;Seat&gt; seatProvider) {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Seat driver = seatProvider.get();</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Seat passenger = seatProvider.get();</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ...</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; }</span>
<br />

  <br />
<h3>
    <a id="get_" name="get_"></a>
get()
  </h3>
&nbsp;&nbsp;&nbsp;&nbsp; 用于提供一个完全构造的类型 T 的实例。<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 异常抛出：RuntimeException &mdash;&mdash; 当注入器在提供实例时遇到错误将抛出此异常。例如，对于一个可注入的成员 T 抛出了一个异常，注入器将包装此异常并将它抛给 get() 的调用者。调用者不应该尝试处理此类异常，因为不同注入器实现的行为不一样，即使是同一个注入器，也会因为配置不同而表现的行为不同。<br />

  <br />
<h2>
    <a id="_Named_1262163341270509_233694_37767472601897867" name="_Named_1262163341270509_233694_37767472601897867"></a>
@Named
  </h2>
&nbsp;&nbsp;&nbsp;&nbsp; 基于 String 的<a href="#_Qualifier_9535574146353466_06">限定器</a>
。<br />

  &nbsp;&nbsp; &nbsp; 例子：<br />

  <br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; public class Car {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; @Inject @Named(&quot;driver&quot;) Seat driverSeat;</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp; &nbsp;&nbsp; &nbsp; @Inject @Named(&quot;passenger&quot;) Seat passengerSeat;</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; ...</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; }<br />

  </span>
<br />
<h2>
    <a id="_Scope_6014748620887402_713421_7367540373832964" name="_Scope_6014748620887402_713421_7367540373832964"></a>
@Scope
  </h2>
&nbsp;&nbsp;&nbsp;&nbsp; 注解 @Scope 用于标识作用域注解。一个作用域注解是被标识在包含一个可注入构造器的类上的，用于控制该类型的实例如何被注入器重用。缺省情况下，如果没有标识作用域注解，注入器将为每一次注入都创建（通过注入类型的构造器）新实例，并不重用已有实例。如果多个线程都能够访问一个作用域内的实例，该实例实现应该是线程安全的。作用域实现由注入器完成。<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 在下面的例子中，作用域注解 @Singleton 确保我们始终只有一个 Log 实例：<br />

  <br />

  &nbsp;&nbsp;&nbsp;&nbsp; <span style="FONT-FAMILY:Courier New">@Singleton</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; class Log {</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; void log(String message) { ... }</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; }</span>
<br />

  <br />

  &nbsp;&nbsp;&nbsp;&nbsp; 当多于一个作用域注解或不被注入器支持的作用域注解被使用在同一个类上时，注入器将生成一个错误。<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 一个作用域注解：<br />

  
<ul>
<li>
      被标注了 @Scope、@Retention(RUNTIME) 标注的，通常也被 @Documented 标注。
    </li>
<li>
      不应该含有属性。
    </li>
<li>
      不应该被 @Inherited 标注，因此作用域与继承实现（正交）无关。
    </li>
<li>
      如果标注了 @Target 可能会有一些用法限制。本规范只是指定了作用域注解可以被使用在类上，但一些注入器配置可能使用作用域注解在其他一些地方（例如工厂方法返回）上。
    </li>
</ul>
<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 例子：<br />

  <br />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @java.lang.annotation.Documented</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @java.lang.annotation.Retention(RUNTIME)</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; @javax.inject.Scope</span>
<br style="FONT-FAMILY:Courier New" />

  <span style="FONT-FAMILY:Courier New">&nbsp;&nbsp; public @interface RequestScoped {}<br />

  <br />

  <span style="FONT-FAMILY:Verdana">&nbsp;&nbsp;&nbsp;&nbsp; 使用 @Scope </span>
来标识一个作用域注解有助于注入器探测程序员使用了作用域注解但却忘了去配置作用域的情况。一个保守的注入器应该生成一个错误而不是去适用该作用域。<br style="FONT-FAMILY:Courier New" />

  </span>
<br />

  &nbsp;&nbsp;&nbsp;&nbsp; 请查阅：<br />

  &nbsp;&nbsp;&nbsp;&nbsp; <a id="ia:3" title="@Singleton" href="#_Singleton_3104547156494192_71_7467978559797065" target="_self" title="@Singleton">@Singleton</a>
<br />

  <br />
<h2>
    <a id="_Singleton_3104547156494192_71_7467978559797065" name="_Singleton_3104547156494192_71_7467978559797065"></a>
@Singleton
  </h2>
&nbsp;&nbsp;&nbsp;&nbsp; 注解 @Singleton 标识了注入器只实例化一次的类型。该注解不能被继承。<br />

  <br />

  &nbsp;&nbsp;&nbsp;&nbsp; 请查阅：<br />

  &nbsp;&nbsp; &nbsp; <a id="scd5" title="@Scope" href="#_Scope_6014748620887402_713421_7367540373832964" target="_self" title="@Scope">@Scope</a>
<br />

  <br />

</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><a href="http://docs.google.com/View?id=ddrm6c35_1172c4dxsbdq">well-formed</a>
</p>