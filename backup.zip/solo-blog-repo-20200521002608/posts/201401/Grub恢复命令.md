title: Grub 恢复命令
date: '2014-01-14 19:25:43'
updated: '2014-01-14 19:27:11'
tags: [Grub, Ubuntu, My Linux]
permalink: /grub-rescue
---
<p>重装 Win 后，MBR 被重置，会导致 Ubuntu 进不去，这里介绍一个恢复步骤。</p>
<ol>
<li>从 LiveCD 进入</li>
<li>找到已挂载好的原 Linux 根分区（/media/ubuntu/xxx）<br />如果 /boot 是单独安装的，也需要挂载好。</li>
<li>挂载虚拟文件系统<br />
<pre class="brush: bash; gutter: false">sudo mount --bind /dev /media/ubuntu/xxx/dev
sudo mount --bind /proc /media/ubuntu/xxx/proc 
sudo mount --bind /sys /media/ubuntu/xxx/sys</pre>
</li>
<li>为确保 grub 工具是从 LiveCD 执行的，挂在 /usr<br />
<pre class="brush: bash; gutter: false">sudo mount --bind /usr/ /media/ubuntu/xxx/usr 
sudo chroot /media/ubuntu/xxx </pre>
</li>
<li>更新（创建）&nbsp;<span>/boot/grub/grub.cfg</span><br />
<pre class="brush: bash; gutter: false">sudo update-grub2</pre>
</li>
<li>重新安装 grub<br />
<pre class="brush: bash; gutter: false">grub-install /dev/sd<strong>X</strong></pre>
注意：不要带分区号，可以用 sudo fdisk -l 查看</li>
<li>重启<br />
<pre class="brush: bash; gutter: false">sudo reboot</pre>
</li>
<li>进入 Ubuntu 后执行<br />
<pre class="brush: bash; gutter: false">sudu update-grub2</pre>
</li>
<li>Done!</li>
</ol>