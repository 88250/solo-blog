title: 基于MEL算法的音频ID比对技术的研究与实现[00原创]
date: '2007-06-16 14:30:00'
updated: '2007-06-16 14:30:00'
tags: [Life in Programming, MultiMediia, Data-Structrue/Algorithms]
permalink: /articles/2007/06/15/1181946600000.html
---
呵呵，申请学院创新基金终于通过了！<br />￥2500。。。。放假要加油做了，呵呵。
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style>
<div style="text-align: center;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style>  </div>
<p style="margin-bottom: 0cm;"> </p>
<p style="margin-bottom: 0cm; text-align: center;"><font size="4"><span style="font-weight: bold;">基于MEL算法的音频ID比对技术的研究与实现</span></font><br /></p>
<p style="margin-bottom: 0cm;">一、本项目的技术依据和意义（包括实际意义和应用前景，外部环境概况、水平和发展趋势，特色或创新之处，主要参考文献目录和出处）</p>
<p>&nbsp;</p>
<p style="margin-bottom: 0cm;"><font size="3"><strong>一．实际意义和应用前景</strong></font></p>
<p style="margin-bottom: 0cm; line-height: 125%;">首先，<font face="文鼎PL细上海宋Uni, serif">LivaID</font>（<font face="文鼎PL细上海宋Uni, serif">LivaID</font>是我们自己为这个技术取的名字）技术的实现将提出一种新颖的歌曲检索方式。在用户不知道歌曲一切相关信息的情况下自动提取并分析这首歌曲的波型特征，计算产生一个针对本首歌曲的特征值。利用这个值就可以在一定规范下的歌曲特征值库进行歌曲检索；其次，本技术的实现将提出一种新的歌曲检索规范，利用音频特征值的方式使得音频文件在检索上实现统一；最后，在这种检索方式下实现的歌词下载，歌词解析以及歌词同步具有很强的实效性，准确性，便捷性。也体现了第一时间满足用户需求的服务理念。</p>
<p style="margin-bottom: 0cm; line-height: 125%;"><font size="3"><strong>二．外部环境概况、水平和发展趋势</strong></font></p>
<p style="text-indent: 0.77cm; margin-bottom: 0cm;">现今流行于<font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">IT</font></font>界的信息检索技术纷繁多样，常规的信息检索<font face="文鼎PL细上海宋Uni, serif">(IR)</font>研究主要是基于文本，例如我们已经非常熟悉的诸如<font face="文鼎PL细上海宋Uni, serif">Yahoo!</font>和<font face="文鼎PL细上海宋Uni, serif">AltaVista</font>这样的搜索引擎。经典的<font face="文鼎PL细上海宋Uni, serif">IR</font>问题是利用一组关键字组成的查询来定位需要的文本文档，即定位文档中的查询关键字来发现匹配的文档。如果一个文档中包含较多的查询项，那么，它就被认为比其他包含较少查询项的文档更&ldquo;相关&rdquo;。</p>
<p style="text-indent: 0.77cm; margin-bottom: 0cm;">显而易见，这种基于关键字和面向文本的搜索技术在应用层面的推广上有一定的局限性，若我们检索的对象是音频和声乐等流媒体的信息，这种基于文本的<font face="文鼎PL细上海宋Uni, serif">IR</font>技术虽然在某些方面上可以满足我们的需求，但是，这种满足是不稳定的，不可靠的，不完整的，如果我们把数字音频当成一种不透明的位流来管理，虽然可以赋予名字、文件格式、采样率等属性，但存在两个问题，首先，这样的附属文本信息量很大，难于管理，也没有得到规范化，并且在网络中这样的信息很混乱，甚至有很多歌曲就没有这样的文本信息。其次，其中的文本信息可能是重复的，缺失的，甚至是错误的，使我们得不到可靠的比较实体。因此，我们就很有可能不能准确定位到检索的对象。 </p>
<p style="text-indent: 0.77cm; margin-bottom: 0cm;">正因为如此，面对音频对象，我们需要一种从本质上更可靠，更准确，更完整的检索策略和方案，这就是根据音乐的特征值与特征点进行检索的技术，并且我们相信，这也将是以后在流媒体服务中能得到广泛拓展和应用的一项技术，而且是在流媒体检索领域中占主导地位的技术。</p>
<p style="margin-left: 0.01cm; margin-right: 0.01cm; margin-bottom: 0cm; line-height: 125%;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-left: 0.01cm; margin-right: 0.01cm; margin-bottom: 0cm; line-height: 125%;"> <font size="3"><strong>三．特色或创新之处</strong></font></p>
<p>&nbsp;</p>
<p style="margin-left: 0.01cm; margin-right: 0.01cm; margin-bottom: 0cm; line-height: 125%;"> 针对以上提出的问题，我们在此提供一种基于音乐与歌曲内容的检索技术的实现，试想一下，当我们在网上下载到一首自己很喜爱的歌曲时，获取的信息却只是一连串日期序列数，而传统的基于文本的<font face="文鼎PL细上海宋Uni, serif">IR</font>技术在这种没有任何关键字和子词信息的情况下又无能为力。而我们采取的这种新的检索技术通过对歌曲的内容采样，计算出特征值，得到一首歌曲的唯一标识，再在我们建立的特征值库中进行音频编码比对，而后在音频数据库中提取这首歌曲的所有相关信息，并且整个过程是在我们欣赏音乐的前几毫秒中自动完成，然后自动更新。与传统的方法相比，这种技术更具高效性，合理性，以及更人性化。</p>
<p lang="" style="margin-bottom: 0cm; line-height: 0.28cm;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-bottom: 0cm;"><font size="3"><strong>四．</strong></font><font size="3"><strong>主要参考文献目录和出处</strong></font></p>
<p style="margin-bottom: 0cm;">参考著作<font face="文鼎PL细上海宋Uni, serif">:</font></p>
<p style="margin-bottom: 0cm;">《<font face="文鼎PL细上海宋Uni, serif">A Highly Robust Audio Fingerprinting System</font>》，<font face="文鼎PL细上海宋Uni, serif">Jaap Haitsma, Ton Kalker</font></p>
<p style="margin-bottom: 0cm;">《<font face="文鼎PL细上海宋Uni, serif">Robust Audio Hashing for content Identification</font>》，<font face="文鼎PL细上海宋Uni, serif">Jaap Haitsma, Ton Kalker, Job Oostveen</font></p>
<p style="margin-bottom: 0cm;">《<font face="文鼎PL细上海宋Uni, serif">Audio Fingerprinting For Recognition</font>》，<font face="文鼎PL细上海宋Uni, serif">Michael Mandel</font></p>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="margin-bottom: 0cm;">参考网站<font face="文鼎PL细上海宋Uni, serif">:</font></p>
<p style="margin-bottom: 0cm;"> <font face="文鼎PL细上海宋Uni, serif">&lt;http://www.shazamentertainment.com&gt;</font></p>
<p style="margin-bottom: 0cm;"> <font face="文鼎PL细上海宋Uni, serif">&lt;http://www.research.philips.com/InformationCenter/Global&gt;</font></p>
<br />
<p style="margin-bottom: 0cm;"><br /></p>
<p style="margin-bottom: 0cm;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-bottom: 0cm;">二、开发内容和预期成果（说明研究项目的具体内容并明确重点解决的关键实际问题，预期成果和提供的形式。如系理论成果，应写明在理论上解决哪些问题及其科学意义；如系应用性成果或基础性资料，应写明其应用前景及达到的技术指标）。</p>
<p style="margin-bottom: 0cm;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-left: 0.01cm; margin-right: 0.01cm; text-indent: 0.74cm; margin-bottom: 0cm; line-height: 125%;"> <font size="3">本项目的主要任务：</font></p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;"><font face="文鼎PL细上海宋Uni, serif"><font size="3"><strong>1. </strong></font></font><font size="3"><strong>研究内容：</strong></font></p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;"><br /> </p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">   （<font face="文鼎PL细上海宋Uni, serif">1</font>） 研究主流音频的编码方式</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">        <font face="文鼎PL细上海宋Uni, serif">&middot;</font>不同编码方式下还原波形的方法</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">   （<font face="文鼎PL细上海宋Uni, serif">2</font>） 研究去除波谱中毛刺的方法</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">        <font face="文鼎PL细上海宋Uni, serif">&middot;</font>使用<font face="文鼎PL细上海宋Uni, serif">Haar</font>小波函数变换波形幅度</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">   （<font face="文鼎PL细上海宋Uni, serif">3</font>） 音频特征值的提取方法</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">        <font face="文鼎PL细上海宋Uni, serif">&middot;<font face="宋体, SimSun">Mel </font></font>对数倒谱系数<font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">MFCC</font></font></p>
<p align="left" style="text-indent: 1.48cm; margin-bottom: 0cm; line-height: 125%;"> <font face="文鼎PL细上海宋Uni, serif">&middot;</font>峰值过滤</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">   （<font face="文鼎PL细上海宋Uni, serif"><font face="宋体, SimSun">4</font></font>） 对不同提取方法所得的特征值进行处理</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">         <font face="文鼎PL细上海宋Uni, serif">&middot;</font>计算特征值的标准偏差、数学期望值和方差</p>
<p align="left" style="text-indent: 0.56cm; margin-bottom: 0cm; line-height: 125%;"> （<font face="文鼎PL细上海宋Uni, serif">5</font>） 与数据库样本特征值的模式匹配</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">         <font face="文鼎PL细上海宋Uni, serif">&middot;</font>求与样本特征值的相似度</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">     </p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;"><font face="文鼎PL细上海宋Uni, serif"><font size="3"><strong>2</strong></font></font><font size="3"><strong>．解决的关键问题</strong></font></p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">     <font face="文鼎PL细上海宋Uni, serif">&middot;</font>引入<font face="文鼎PL细上海宋Uni, serif">Haar</font>小波函数调节系数，调节波形幅度</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">     <font face="文鼎PL细上海宋Uni, serif">&middot;</font>采用试验统计学原理，进行波形幅度最优化</p>
<p align="left" style="text-indent: 1.17cm; margin-bottom: 0cm; line-height: 125%;"> <font face="文鼎PL细上海宋Uni, serif">&middot;</font>对<font face="文鼎PL细上海宋Uni, serif">Mel (MFCC) </font>算法进行改进</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">     <font face="文鼎PL细上海宋Uni, serif">&middot;</font>对输入样本特征值与数据库样本特征值的相似度描述</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;"><br /> </p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;"><font face="文鼎PL细上海宋Uni, serif"><font size="3"><strong>3.</strong></font></font><font size="3"><strong>预期成果</strong></font></p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">   <font face="文鼎PL细上海宋Uni, serif">1</font>）提交一份基于音频特征值检索技术实现的完美解决方案<font face="文鼎PL细上海宋Uni, serif">(</font>文档形式<font face="文鼎PL细上海宋Uni, serif">)</font>。</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">   <font face="文鼎PL细上海宋Uni, serif">2</font>）编码实现根据采样值计算特征值以及由数字数据转换为模拟波形数据的算法，建立遵循一定规范的特征值码库，使已完成的算法和数据库能够支持特定的模式匹配完成信息检索，并能在测试平台上实现无缝集成（软件应用形式）。</p>
<p align="left" style="margin-bottom: 0cm; line-height: 125%;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-bottom: 0cm;">三、拟采取的研究方法和技术（包括理论分析、计算、实验方法和步骤及可行性论证，可能遇到的问题和可能的解决办法，使用到的主要技术）</p>
<p style="margin-bottom: 0cm;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-bottom: 0cm;"><font size="3">根<span style="border: medium none ; padding: 0cm; background: rgb(255, 255, 255) none repeat scroll 0% 50%; float: left; width: 1.27cm; height: 0.55cm; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;" dir="ltr" id="Frame13"></span><span style="border: medium none ; padding: 0cm; background: rgb(255, 255, 255) none repeat scroll 0% 50%; float: left; width: 1.27cm; height: 0.55cm; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;" dir="ltr" id="Frame12"></span>据拟定的研究内容逐一阐述本项目的研究方法和技术路线。</font><br /><span style="font-weight: bold;"></span></p>
<p style="margin-bottom: 0cm;"><span style="font-weight: bold;"></span></p>
<p style="margin-bottom: 0cm;"><strong>（</strong><font face="Times"><font size="3"><span lang="en-US"><strong>1</strong></span></font></font><strong>）研究主流音频的编码方式</strong></p>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;"><span lang="">我们将重点研究</span><font face="Times"><font size="3"><span lang="en-US"><span lang="">MP3 </span></span></font></font><span lang="">音频编码，</span><span lang="">在采样后对其进行波形还原。</span></p>
<p lang="" style="text-indent: 1.11cm; margin-bottom: 0cm;"><br /> </p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">MP3</span></font></font>格式简介：</p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">所需频宽：<font face="Times"><font size="3"><span lang="en-US">128</span></font></font>～<font face="Times"><font size="3"><span lang="en-US">112kbps</span></font></font>（压缩<font face="Times"><font size="3"><span lang="en-US">10</span></font></font>～<font face="Times"><font size="3"><span lang="en-US">12</span></font></font>倍）</p>
<p style="margin-left: 1.11cm; margin-bottom: 0cm;">特性：编码复杂，用于互联网上的高质量声音的传输，如<font face="Times"><font size="3"><span lang="en-US">MP3</span></font></font>音乐压缩<font face="Times"><font size="3"><span lang="en-US">10</span></font></font>倍，<font face="Times"><font size="3"><span lang="en-US">2</span></font></font>声道。优点：压缩比高，适合用于互联网上的传播</p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">缺点：<font face="Times"><font size="3"><span lang="en-US">MP3</span></font></font>在<font face="Times"><font size="3"><span lang="en-US">128KBitrate</span></font></font>及以下时，会出现明显的高频丢失</p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">应用领域：<font face="Times"><font size="3"><span lang="en-US">voip</span></font></font></p>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="margin-bottom: 0cm;"><span lang=""><strong>（</strong></span><font face="Times"><font size="3"><span lang="en-US"><span lang=""><strong>2</strong></span></span></font></font><span lang=""><strong>）</strong></span><strong>研究去除波谱中毛刺的方法</strong></p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">基本<font face="Times"><font size="3"><span lang="en-US">Haar</span></font></font>函数的定义为<font face="Times"><font size="3"><span lang="en-US">: </span></font></font></p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">设有一段分辨率为<font face="Times"><font size="3"><span lang="en-US">N </span></font></font>个数据的立体声音频数据<font face="Times"><font size="3"><span lang="en-US">X = { x1 , x2 , <font face="MS Mincho, ＭＳ 明朝, monospace">⋯</font>, x N } ( N mod 2 = 0)</span></font></font></p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">用小波函数转换为：</p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">            <font face="Times"><font size="3"><span lang="en-US">i=1.2&hellip;N/4 j = 4 * (i-1) + 1       (1)</span></font></font></p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">            <font face="Times"><font size="3"><span lang="en-US">i=1.2&hellip;N/4 j = 4 * (i-1) + 1    (2)</span></font></font></p>
<p style="margin-left: 4.26cm; text-indent: -3.15cm; margin-bottom: 0cm;"> 分别利用<font face="Times"><font size="3"><span lang="en-US">(1) </span></font></font>、<font face="Times"><font size="3"><span lang="en-US">(2) </span></font></font>两公式即可得到一阶小波变换后的音频数据新序列：                <font face="Times"><font size="3"><span lang="en-US">X&prime;= { x&prime;1 , x&prime;2 ,<font face="MS Mincho, ＭＳ 明朝, monospace">⋯</font>, x&prime;N&prime;} </span></font></font> </p>
<p style="text-indent: 1.11cm; margin-bottom: 0cm;">以及重构系数序列 <font face="Times"><font size="3"><span lang="en-US">Y&prime;= { y&prime;1 , y&prime;2 , <font face="MS Mincho, ＭＳ 明朝, monospace">⋯</font>, y&prime;N&prime;} ,</span></font></font>式中<font face="Times"><font size="3"><span lang="en-US">N&prime;= N/ 2.</span></font></font></p>
<p style="margin-bottom: 0cm;">      下图是波谱优化之前的和频谱优化之后的两个帧级波谱图的例子<font face="Times"><font size="3"><span lang="en-US">:</span></font></font></p>
<p style="margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US"><img src="http://p.blog.csdn.net/images/p_blog_csdn_net/dl88250/273209/o_%e6%b3%a2%e8%b0%b1%e5%9b%be.jpg" alt="" /><br /></span></font></font></p>
<p align="center" style="margin-bottom: 0cm;">&nbsp;</p>
<p align="center" style="margin-bottom: 0cm;">波谱优化之前&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                          波谱优化之后</p>
<p style="margin-bottom: 0cm; text-align: left;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-bottom: 0cm;"><font size="2"><span lang=""><strong>（</strong></span></font><font face="Times"><font size="3"><span lang="en-US"><font size="2"><span lang=""><strong>3</strong></span></font></span></font></font><font size="2"><span lang=""><strong>）</strong></span></font><strong>音频特征值的提取方法</strong></p>
<p style="margin-bottom: 0cm;">     <font face="Times"><font size="3"><span lang="en-US"><strong>1) </strong></span></font></font><strong>峰值过滤</strong></p>
<p style="text-indent: 1.3cm; margin-bottom: 0cm;">对于每个帧级的峰值点（<font face="Times"><font size="3"><span lang="en-US">x, y</span></font></font>）都进行如下的操作<font face="Times"><font size="3"><span lang="en-US">:</span></font></font></p>
<p style="text-indent: 2.96cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">If Exy== max(Eij ) </span></font></font> </p>
<p style="text-indent: 3.7cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">E<sub>xy  </sub></span></font></font>为特征点</p>
<p style="text-indent: 2.96cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">Else </span></font></font> </p>
<p style="text-indent: 3.7cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">E<sub>xy</sub> </span></font></font>不为特征点</p>
<p style="text-indent: 1.85cm; margin-bottom: 0cm;">其中<font face="Times"><font size="3"><span lang="en-US">x </span></font></font>是该峰值点的频率值，<font face="Times"><font size="3"><span lang="en-US">y </span></font></font>是该峰值点的时间值。</p>
<p style="margin-left: 1.3cm; text-indent: 0.56cm; margin-bottom: 0cm;"> 有<font face="Times"><font size="3"><span lang="en-US">x &minus; df &le; i &le; x + df </span></font></font>，<font face="Times"><font size="3"><span lang="en-US">y&minus;dt &le; j &le; y+dt </span></font></font>。<font face="Times"><font size="3"><span lang="en-US">df </span></font></font>为允许频率误差。</p>
<p style="text-indent: 0.93cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US"><font size="2"><span lang=""><strong>2) </strong></span></font><font face="宋体, SimSun"><strong>Mel </strong></font></span></font></font><strong>对数倒谱系数</strong><font face="Times"><font size="3"><span lang="en-US"><font face="宋体, SimSun"><strong>MFCC</strong></font></span></font></font></p>
<p style="text-indent: 1.06cm; margin-bottom: 0cm;">（<font face="Times"><font size="3"><span lang="en-US">1</span></font></font>）计算频域信息<font face="Times"><font size="3"><span lang="en-US">: </span></font></font> </p>
<p style="text-indent: 1.85cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">1) </span></font></font>对音频帧进行快速傅里叶变换<font face="Times"><font size="3"><span lang="en-US">( Fast Fourier Transformation , FFT) </span></font></font>。</p>
<p style="text-indent: 1.85cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">2) </span></font></font>将时域信息<font face="Times"><font size="3"><span lang="en-US">xi ( n) ( n &isin; [1. .Num ]) </span></font></font>转换为频域信息<font face="Times"><font size="3"><span lang="en-US">yi ( n) ( n&isin;[0. .Num - 1 ]) :</span></font></font></p>
<p style="text-indent: 2.54cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US"><font size="3">yi ( n) =  </font>k = 0 ,1 , <font face="MS Mincho, ＭＳ 明朝, monospace">⋯</font>, Num - 1 </span></font></font>　<font face="Times"><font size="3"><span lang="en-US">j </span></font></font>为虚数单位 <font face="Times"><font size="3"><span lang="en-US">(6)</span></font></font></p>
<p style="margin-bottom: 0cm;">      （<font face="Times"><font size="3"><span lang="en-US">2</span></font></font>）计算<font face="Times"><font size="3"><span lang="en-US">Mel </span></font></font>频率<font face="Times"><font size="3"><span lang="en-US">:</span></font></font></p>
<p style="margin-left: 2.96cm; text-indent: -0.74cm; margin-bottom: 0cm;"> <font face="Times"><font size="3"><span lang="en-US">f i ( i &isin;[1. . 24 ]) :</span></font></font></p>
<p style="text-indent: 4.41cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">f 1 = 20 Hz</span></font></font></p>
<p style="text-indent: 4.45cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">f 12 = 1 000 Hz</span></font></font></p>
<p style="text-indent: 4.45cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">f <sub>i </sub>= f <sub>i</sub>- 1 + Hz  i &isin;[2. . 11 ]        (7)</span></font></font></p>
<p style="text-indent: 0.56cm; margin-bottom: 0cm;">                    <font face="Times"><font size="3"><span lang="en-US">==...=</span></font></font></p>
<p style="text-indent: 4.26cm; margin-bottom: 0cm;"><font face="Times"><font size="3"><span lang="en-US">f 24 = 22 000 Hz</span></font></font></p>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="text-indent: 2.96cm; margin-bottom: 0cm;">根据<font face="Times"><font size="3"><span lang="en-US">(7) </span></font></font>式的计算结果<font face="Times"><font size="3"><span lang="en-US">,</span></font></font>代入<font face="Times"><font size="3"><span lang="en-US">(8) </span></font></font>式<font face="Times"><font size="3"><span lang="en-US">,</span></font></font>即可计算出对应的<font face="Times"><font size="3"><span lang="en-US">Mel </span></font></font>频率<font face="Times"><font size="3"><span lang="en-US">.</span></font></font></p>
<p style="margin-bottom: 0cm;">                    <font face="Times"><font size="3"><span lang="en-US">Fi=61n   +               (8)</span></font></font></p>
<p style="margin-bottom: 0cm;"><br /> </p>
<ol start="3">
    <li>
    <p style="margin-bottom: 0cm;">计算<font face="Times"><font size="3"><span lang="en-US">Mel 	</span></font></font>倒谱系数<font face="Times"><font size="3"><span lang="en-US">:</span></font></font></p>
    </li>
</ol>
<p style="margin-left: 2.62cm; text-indent: -0.56cm; margin-bottom: 0cm;"> <font face="Times"><font size="3"><span lang="en-US">1) </span></font></font>利用<font face="Times"><font size="3"><span lang="en-US">24 </span></font></font>个三角带通滤波器分别与⑹式计算出的频域信息<font face="Times"><font size="3"><span lang="en-US">yi ( n) ( n&isin;[0..Num - 1 ]) </span></font></font>求卷积<font face="Times"><font size="3"><span lang="en-US">,</span></font></font>得到每个频率点的对数能量<font face="Times"><font size="3"><span lang="en-US">pi ( n) ( n &isin;[1. . 24 ]) . </span></font></font> </p>
<p style="margin-left: 1.69cm; text-indent: 0.37cm; margin-bottom: 0cm;"> <font face="Times"><font size="3"><span lang="en-US">2) </span></font></font>根据该频点能量进行余弦变换<font face="Times"><font size="3"><span lang="en-US">(DCT) </span></font></font>即可得到<font face="Times"><font size="3"><span lang="en-US">Nel </span></font></font>倒谱系数<font face="Times"><font size="3"><span lang="en-US">. </span></font></font> </p>
<p style="margin-left: 1.69cm; text-indent: 1.77cm; margin-bottom: 0cm;"> <font face="Times"><font size="3"><span lang="en-US">M<span style="border: medium none ; padding: 0cm; background: rgb(255, 255, 255) none repeat scroll 0% 50%; float: left; width: 1.27cm; height: 0.55cm; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;" dir="ltr" id="Frame15">
<p style="margin-bottom: 0cm;">&mdash;<font face="Times"><font size="3"><span lang="en-US">7&mdash;</span></font></font></p>
</span>FCC<sub>i</sub> ( d) = <font face="宋体, SimSun">d&isin;[1,2&hellip;12]    (9)</font></span></font></font></p>
<p style="margin-bottom: 0cm;"><strong>（</strong><font face="Times"><font size="3"><span lang="en-US"><font face="宋体, SimSun"><strong>4</strong></font></span></font></font><strong>） 对不同提取方法所得的特征值进行处理</strong></p>
<p style="margin-bottom: 0cm;">     标准偏差： <font face="Times"><font size="3"><span lang="en-US"><font face="宋体, SimSun">S =  (Xn</font></span></font></font>为特征值 <font face="Times"><font size="3"><span lang="en-US"><font face="宋体, SimSun">y </font></span></font></font>为特征值的算数平均数<font face="Times"><font size="3"><span lang="en-US"><font face="宋体, SimSun">)</font></span></font></font></p>
<p style="text-indent: 2.86cm; margin-bottom: 0cm;"><font size="2" style="font-size: 9pt;">标准偏差越小，这些值偏离平均值就越少。</font></p>
<p style="margin-bottom: 0cm;">      数学期望值（均值）： <font face="Times"><font size="3"><span lang="en-US">E(X) = </span></font></font></p>
<p style="margin-bottom: 0cm;">     方差：    <font face="Times"><font size="3"><span lang="en-US">D(x) = </span></font></font></p>
<p style="margin-bottom: 0cm;">               <font face="Times"><font size="3"><span lang="en-US">E(x<sup>2</sup>) =  </span></font></font> </p>
<p style="margin-bottom: 0cm;">               <font face="Times"><font size="3"><span lang="en-US">E(x) = </span></font></font></p>
<p style="margin-bottom: 0cm;">     根据标准偏差，数学期望，方差对不同算法所得到的特征值进行均值计算。</p>
<p style="margin-bottom: 0cm;"><br /> </p>
<p style="margin-bottom: 0cm;"> <strong>（</strong><font face="Times"><font size="3"><span lang="en-US"><font face="宋体, SimSun"><strong>5</strong></font></span></font></font><strong>）</strong><strong>与数据库样本特征值的模式匹配</strong></p>
<p style="text-indent: 0.64cm; margin-bottom: 0cm; line-height: 150%;"> 对音频数据提取特征后，假设共<font face="Times"><font size="3"><span lang="en-US"><em>N</em></span></font></font>个特征，则形成了一个<font face="Times"><font size="3"><span lang="en-US"><em>N</em></span></font></font>维特征矢量的序列。<font color="#000000">对</font><font face="Times"><font size="3"><span lang="en-US"><font color="#000000"><em>N</em></font></span></font></font><font color="#000000">维特征矢量进行聚类，一般采用模糊聚类法，模糊聚类首先要对</font><font face="Times"><font size="3"><span lang="en-US"><font color="#000000"><em>N</em></font></span></font></font><font color="#000000">维特征矢量进行归一化，一般采用高斯归一化。</font><font color="#000000">音频聚类质心生成图如下。</font></p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm; line-height: 150%;"> <font size="2" style="font-size: 9pt;">音频波形</font></p>
<p style="margin-bottom: 0cm; line-height: 150%;">          </p>
<p style="text-indent: 1.91cm; margin-bottom: 0cm; line-height: 150%;">   <font size="2" style="font-size: 9pt;">加窗处理</font></p>
<p style="margin-bottom: 0cm; line-height: 150%;"><br /> </p>
<p style="margin-bottom: 0cm; line-height: 150%;">                                    </p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm; line-height: 150%;"> <font size="2" style="font-size: 9pt;">特征序列 </font> </p>
<p style="margin-bottom: 0cm; line-height: 150%;"><br /> </p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm; line-height: 150%;"> <font size="2" style="font-size: 9pt;">模糊聚类</font></p>
<p style="margin-bottom: 0cm; line-height: 150%;"><br /> </p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm; line-height: 150%;"> <font size="2" style="font-size: 9pt;">音频模板　          </font> </p>
<p style="margin-bottom: 0cm; line-height: 150%;"><font color="#000000"> <span style="border: medium none ; padding: 0cm; background: rgb(255, 255, 255) none repeat scroll 0% 50%; float: left; width: 1.27cm; height: 0.55cm; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;" dir="ltr" id="Frame16">
<p style="margin-bottom: 0cm;">&mdash;<font face="Times"><font size="3"><span lang="en-US">8&mdash;</span></font></font></p>
</span>    </font><font color="#000000">                               </font> </p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm; line-height: 150%;"> 计算<font face="Times"><font size="3"><span lang="en-US">request</span></font></font>和<font face="Times"><font size="3"><span lang="en-US">clip</span></font></font>的相似度：</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm; line-height: 150%;"> <font face="Times"><font size="3"><span lang="en-US">1</span></font></font>）对于<font face="Times"><font size="3"><span lang="en-US"><em>V</em></span></font></font>中的每个，在<font face="Times"><font size="3"><span lang="en-US"><em>W</em></span></font></font>中找到与其最相似的，记为，其中<font face="Times"><font size="3"><span lang="en-US"><em>d</em></span></font></font>表示余弦相似度。同理，对于<font face="Times"><font size="3"><span lang="en-US"><em>W</em></span></font></font>中的每个<font face="Times"><font size="3"><span lang="en-US"><em>V</em></span></font></font>中的每个，在<font face="Times"><font size="3"><span lang="en-US">V</span></font></font>中找到与其最相似的，记为。</p>
<p style="text-indent: 0.56cm; margin-bottom: 0cm; line-height: 150%;"> <font face="Times"><font size="3"><span lang="en-US">2)  request</span></font></font>和<font face="Times"><font size="3"><span lang="en-US">clip</span></font></font>之间的相似度</p>
<p style="text-indent: 2.96cm; margin-bottom: 0cm; line-height: 150%;">      </p>
<p lang="" style="text-indent: 2.82cm; margin-bottom: 0cm; line-height: 150%;"> <br /> </p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm; line-height: 150%;"> <font size="2" style="font-size: 9pt;">音频库</font>   　 <font face="Times"><font size="3"><span lang="en-US">		         &hellip;&hellip;</span></font></font></p>
<p style="margin-bottom: 0cm; line-height: 150%;">                                  <font face="Times"><font size="3"><span lang="en-US"><font size="2" style="font-size: 9pt;"><em>A</em></font><font size="2" style="font-size: 9pt;"> </font>         <font size="2" style="font-size: 9pt;"><em>B</em></font>            <font size="2" style="font-size: 9pt;"><em>N</em></font></span></font></font></p>
<p style="text-indent: 2.22cm; margin-bottom: 0cm; line-height: 150%;"> <font size="2" style="font-size: 9pt;">样本音频</font></p>
<p style="margin-bottom: 0cm; line-height: 150%;"><br /> </p>
<p style="text-indent: 6.4cm; margin-bottom: 0cm; line-height: 150%;"><font face="Times"><font size="2" style="font-size: 9pt;"><span lang="en-US"><em>X</em></span></font></font></p>
<p style="margin-bottom: 0cm; line-height: 150%;">                                                <font face="Times"><font size="3"><span lang="en-US"><font size="2" style="font-size: 9pt;"><em>D</em></font><font size="2" style="font-size: 9pt;">(</font><font size="2" style="font-size: 9pt;"><em>X</em></font><font size="2" style="font-size: 9pt;">,</font><font size="2" style="font-size: 9pt;"><em>A</em></font><font size="2" style="font-size: 9pt;">), </font><font size="2" style="font-size: 9pt;"><em>D</em></font><font size="2" style="font-size: 9pt;">(</font><font size="2" style="font-size: 9pt;"><em>X</em></font><font size="2" style="font-size: 9pt;">,</font><font size="2" style="font-size: 9pt;"><em>B</em></font><font size="2" style="font-size: 9pt;">), &hellip;,</font><font size="2" style="font-size: 9pt;"><em>D</em></font><font size="2" style="font-size: 9pt;">(</font><font size="2" style="font-size: 9pt;"><em>X</em></font><font size="2" style="font-size: 9pt;">,</font><font size="2" style="font-size: 9pt;"><em>N</em></font><font size="2" style="font-size: 9pt;">)</font></span></font></font></p>
<p style="text-indent: 1.32cm; margin-bottom: 0cm; line-height: 150%;"> <br /> </p>
<p style="text-indent: 1.32cm; margin-bottom: 0cm; line-height: 150%;"> <br /> </p>
<p style="margin-bottom: 0cm; line-height: 150%;"><br /> </p>
<p style="margin-bottom: 0cm; line-height: 150%;">   </p>
<p style="margin-bottom: 0cm; line-height: 150%;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-bottom: 0cm;">四、研究工作年度计划安排（在研究工作期限内，按月阐明研究工作具体内容）</p>
<p>&nbsp;</p>
<p style="margin-bottom: 0cm; line-height: 150%;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-bottom: 0cm;"><font size="3" style="font-size: 11pt;">（</font><font face="文鼎PL细上海宋Uni, serif">1</font>）研究工作和总体安排</p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm; line-height: 0.71cm;"> 研究工作分三个阶段进行<font face="文鼎PL细上海宋Uni, serif">:</font></p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm; line-height: 0.71cm;"> 第一阶段<font face="文鼎PL细上海宋Uni, serif">: </font>收集并整理资料、阅读相关文献<font face="文鼎PL细上海宋Uni, serif">,</font>对研究内容中涉及到的各问题作综述性研究。</p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;"><br /> </p>
<p style="text-indent: 0.74cm; margin-bottom: 0cm; line-height: 0.71cm;"> 第二阶段<font face="文鼎PL细上海宋Uni, serif">: </font>理论分析和研究。</p>
<p style="text-indent: 1.48cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">&middot; </font>研究主流音频的编码方式</p>
<p style="text-indent: 1.48cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">&middot; </font>不同编码方式下还原波形的方法</p>
<p style="text-indent: 1.48cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">&middot; </font>研究去除波谱中毛刺的方法</p>
<p style="text-indent: 1.48cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">&middot; </font>音频特征值的提取方法</p>
<p style="text-indent: 1.48cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">&middot; </font>对不同提取方法所得的特征值进行处理</p>
<p style="text-indent: 1.48cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">&middot; </font>与数据库样本特征值的模式匹配</p>
<p style="text-indent: 1.48cm; margin-bottom: 0cm; line-height: 0.71cm;"> <br /> </p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 第三阶段<font face="文鼎PL细上海宋Uni, serif">: </font>编程实现<font face="文鼎PL细上海宋Uni, serif">,</font>进行实验研究和性能分析。</p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;">
<meta content="text/html; charset=utf-8" http-equiv="CONTENT-TYPE" />
<title></title>
<meta content="OpenOffice.org 2.2  (Linux)" name="GENERATOR" />
<meta content="lmb" name="AUTHOR" />
<meta content="20070421;17290000" name="CREATED" />
<meta content="番茄花园" name="CHANGEDBY" />
<meta content="20070422;23320000" name="CHANGED" /> 	 	 	 	 	 	 	<style type="text/css">
	<!--
		@page { size: 21cm 29.7cm; margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</style> </p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;">（<font face="文鼎PL细上海宋Uni, serif">2</font>）分月计划安排</p>
<p style="text-indent: 0.56cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">4 </font>月<font face="文鼎PL细上海宋Uni, serif">--2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">7 </font>月  查阅资料、整理相关工作<font face="文鼎PL细上海宋Uni, serif">,</font>作综述性研究和报告。</p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;"><br /> </p>
<p style="text-indent: 0.56cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">7 </font>月<font face="文鼎PL细上海宋Uni, serif">--2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">9 </font>月  设计系统框架<font face="文鼎PL细上海宋Uni, serif">,</font>以及各部分功能的实施策略。</p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;"><br /> </p>
<p style="text-indent: 0.56cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">9 </font>月<font face="文鼎PL细上海宋Uni, serif">--2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">10 </font>月 不同编码方式下还原波形及去除波谱中毛刺的方法</p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;"><br /> </p>
<p style="text-indent: 0.56cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">10 </font>月<font face="文鼎PL细上海宋Uni, serif">--2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">11 </font>月 音频特征值的提取方法</p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;"><br /> </p>
<p style="text-indent: 0.56cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">11 </font>月<font face="文鼎PL细上海宋Uni, serif">--2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">12 </font>月 对不同提取方法所得的特征值进行处理</p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;"><br /> </p>
<p style="text-indent: 0.56cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">2007 </font>年 <font face="文鼎PL细上海宋Uni, serif">12 </font>月<font face="文鼎PL细上海宋Uni, serif">--2008 </font>年 <font face="文鼎PL细上海宋Uni, serif">2 </font>月  与数据库样本特征值的模式匹配</p>
<p style="margin-bottom: 0cm; line-height: 0.71cm;"><br /> </p>
<p style="margin-left: 0.56cm; margin-bottom: 0cm; line-height: 0.71cm;"> <font face="文鼎PL细上海宋Uni, serif">2008 </font>年 <font face="文鼎PL细上海宋Uni, serif">2 </font>月<font face="文鼎PL细上海宋Uni, serif">--2008 </font>年 <font face="文鼎PL细上海宋Uni, serif">4 </font>月 编程实现<font face="文鼎PL细上海宋Uni, serif">,</font>使用实际的数据对所提出的方法及策略进行实验研究和性能分析。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<br />
<p style="margin-bottom: 0cm;">&nbsp;</p>
<p style="margin-bottom: 0cm;">（格式有问题，大家如果有兴趣的话可以下载这个Word文档看看）<br /> </p>
<p>&nbsp;http://download1.csdn.net/down3/20070615/15224910580.doc</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>