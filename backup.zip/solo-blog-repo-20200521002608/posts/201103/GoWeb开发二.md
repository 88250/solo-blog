title: Go Web 开发（二）
date: '2011-03-11 06:37:07'
updated: '2014-08-11 17:12:34'
tags: [Google, golang, Web]
permalink: /go-web-2.html
---
<div>
<h2>目的</h2>
<p>了解使用 Go 模板技术开发 Web 应用的。</p>
<h2>效果</h2>
<p><img src="https://sn2files.storage.live.com/y1pVjaR1JowIjXKZfjxur14qI4--pUUrR93S0CZ885C80C3JuzXpGsef47SiBXdE-KsnYX0IP-XWrY/go-web-1-1.png?psid=1" alt="" width="355" height="141" /></p>
<p><img src="https://sn2files.storage.live.com/y1ph5rXJ-BR_3ir0MLGhEH58ehfR8DbPpHg7WAl_f0GcCNMmyUXgHBOJv2di0OS1zzmIQOUVGKhD3A/go-web-2-2.png?psid=1" alt="" width="310" height="111" /></p>
<h2>代码</h2>
<p><strong>server.go</strong></p>
<blockquote>
<p>package main<br /> <br /> import (<br /> &nbsp;&nbsp;&nbsp; "fmt"<br /> &nbsp;&nbsp;&nbsp; "http"<br /> &nbsp;&nbsp;&nbsp; "template"<br /> )<br /> <br /> type User struct {<br /> &nbsp;&nbsp;&nbsp; Name&nbsp;&nbsp;&nbsp; string<br /> }<br /> <br /> func Register(w http.ResponseWriter, r *http.Request) {<br /> &nbsp;&nbsp;&nbsp; if "GET" == r.Method {<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; fmt.Fprintln(w, "&lt;h1&gt;Register&lt;/h1&gt;" +<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; "&lt;form action='/' method='POST'&gt;" +<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; " User Name: &lt;input name='userName' value='Type in your name'/&gt;&lt;input type='submit' value='Register'/&gt;" +<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; "&lt;/form&gt;")<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; return<br /> &nbsp;&nbsp;&nbsp; }<br /> <br /> &nbsp;&nbsp;&nbsp; user := &amp;User{r.FormValue("userName")}<br /> &nbsp;&nbsp;&nbsp; <strong>t, _ := template.ParseFile("hello.html", nil)</strong><br /> &nbsp;&nbsp;&nbsp; <strong>t.Execute(w, user)</strong><br /> }<br /> <br /> func main() {<br /> &nbsp;&nbsp;&nbsp; http.HandleFunc("/", Register)<br /> &nbsp;&nbsp;&nbsp; http.ListenAndServe(":8080", nil)<br /> }</p>
</blockquote>
<p><strong>hello.html</strong></p>
<blockquote>
<p>&lt;h1&gt;Hello, {Name}&lt;/h1&gt;</p>
</blockquote>
<h2>总结</h2>
<ul>
<li>自动解析类型字段</li>
<li>模板需要自行编程进行缓存</li>
</ul>
<h2>下一步</h2>
<ul>
<li>数据持久化</li>
</ul>
</div>
<p>&nbsp;----</p>
<p>Updates:</p>
<p>Nov 26, 2011 - 把图片移到了 SkyDrive</p>