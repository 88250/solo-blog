title: JavaMail 使用 163 发送邮件
date: '2014-04-10 23:18:07'
updated: '2014-04-10 23:18:07'
tags: [JavaMail, Java, '163']
permalink: /javamail-smtp-163
---
<p>在通过 JavaMail 使用 163 邮箱发邮件时有几点问题需要注意。</p>
<ul>
<li>550 用户被锁定：普通 163 邮箱是无法通过 smtp.163.com&nbsp;发送邮件的，只有 163 VIP 邮箱才行，然后设置&nbsp;mail.smtp.host=smtp.vip.163.com</li>
<li>454 Command not permitted when TLS active：需要设置&nbsp;mail.smtp.starttls.enable=false</li>
<li>553 authentication is required：需要设置&nbsp;mail.smtp.auth=true</li>
<li>550 Invalid User：from 必须写成带 @ 的邮件格式，且 username 要用 @ 前面的</li>
</ul>
<p>一个完整的配置示例：</p>
<pre class="brush: bash; gutter: false; toolbar: false; auto-links: false">mail.smtp.auth=true
mail.smtp.starttls.enable=false
mail.debug=false
mail.smtp.host=smtp.vip.163.com
mail.smtp.port=465
mail.smtp.socketFactory.class=javax.net.ssl.SSLSocketFactory
mail.smtp.socketFactory.fallback=false
mail.smtp.socketFactory.port=465</pre>
<p>&nbsp;</p>
<p>编程实参：Authenticator 用户名：xxx；mimeMessage.setFrom("xxx@vip.163.com")</p>
<p>&nbsp;</p>