title: 自动清理日志 Shell 脚本
date: '2014-02-09 00:34:48'
updated: '2014-02-09 00:37:18'
tags: [Shell, Linux]
permalink: /autoremove-logs
---
<p>以删除 Jetty 日志为例，仅保留最近 7 天的日志文件。</p>
<p>&nbsp;</p>
<pre class="brush: bash; gutter: false; toolbar: false; auto-links: false">#!/bin/bash
 
# 要清理的目录，多个目录用空格分开
dirs=(d-jetty/logs v-jetty/logs rhythm-jetty/logs symphony-jetty/logs) 
 
# 循环 dirs 数组
for dir in ${dirs[*]}
  do
    # 删除目录下 7 天之前的日志文件
    find $dir -mtime +7 -name *.log* | xargs rm
  done
</pre>
<p>&nbsp;</p>
<p>最后，加入 crontab，每天定时执行：</p>
<pre class="brush: bash; gutter: false; toolbar: false; auto-links: false">crontab -e</pre>
<p>设置为凌晨 4 点执行：</p>
<pre class="brush: bash;gutter: false;toolbar: false;auto-links: false">* 4 * * * /root/clean_jetty_logs.sh</pre>
<p>&nbsp;</p>