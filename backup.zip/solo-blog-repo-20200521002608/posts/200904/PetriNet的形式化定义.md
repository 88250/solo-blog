title: Petri Net 的形式化定义
date: '2009-04-06 16:43:00'
updated: '2009-04-06 16:43:00'
tags: [Mathematics]
permalink: /articles/2009/04/06/1238978580000.html
---
<h1>Petri Net 定义 <br /></h1>
<p><br /><strong>定义 1.1 </strong>如果三元组&nbsp; (S, T, W) 称为一个 Petri 网图，那么</p>
<ul>
<li><span class="texhtml">S 是库所的有限集合</span></li>
<li><span class="texhtml">T 是变迁的有限集合<br /></span></li>
<li><span class="texhtml">S</span> &cup; T &ne; &Phi;，且 S &cap; T = &Phi;</li>
<li>W: (S &times; T) &cup; (T &times; S) &rarr; N 为弧的多重集</li>
</ul>
<p>流关系是弧的集合：F = {(x, y) | W(x, y) &gt; 0}。在一些介绍 Petri 网相关文献中，弧的重度只定义为 1，并在定义 Petri 网图时使用 F 代替了 W。</p>
<p>&nbsp;</p>
<p><strong>定义 1.3</strong> 设 N = (S, T, F) 为一个 Petri 网图，&sum; ＝ (S, T, F, M) 称为一个标记网，其中</p>
<ul>
<li>M &sube; S，称为 N 的一个标记或一个瞬态</li>
<li>若 S &isin; T，且 <sup><strong><span style="font-size: small;">.</span></strong></sup>x &sube; M，x<sup><strong><span style="font-size: small;">.</span></strong></sup> &cap; M ＝ &Phi;，称事件 x 为可触发的</li>
<li>若事件 x 被触发（称为点火），则标记网 &sum; 转化为 &sum;' = (S, T, F, M')，其中 M' = (M - <sup><strong><span style="font-size: small;">.</span></strong></sup>x) &cup; x<sup><strong><span style="font-size: small;">.</span></strong></sup>，M' 也是 N 的一个标记，&sum;' 也是一个标记网</li>
</ul>
<p><strong>定义 1.2</strong> 设 N = (S, T, F) 为一个 Petri 网图，x &isin; S &cup; T，则</p>
<ul>
<li><sup><strong><span style="font-size: small;">.</span></strong></sup>x = {y &isin; S &cup; T | (y, x) &isin; F}</li>
<li>x<sup><strong><span style="font-size: small;">.</span></strong></sup> = {y &isin; S &cup; T | (x, y) &isin; F}</li>
<li><strong><span style="font-size: medium;"><sup>.</sup></span></strong>x<strong><span style="font-size: medium;"><sup>.</sup></span></strong><span style="font-size: large;"><strong><sup>&nbsp;</sup></strong></span>＝ <sup><span style="font-size: small;"><strong>.</strong></span></sup>x &cup; x<sup><span style="font-size: small;"><strong>.</strong></span></sup></li>
</ul>
<p>其中，<sup><strong><span style="font-size: small;">.</span></strong></sup>x 称为 x 的前提，x<sup><span style="font-size: small;"><strong>. </strong></span></sup> 称为 x 的后提，<span style="font-size: medium;"><strong><sup>.</sup></strong></span>x<span style="font-size: medium;"><sup><strong>. </strong></sup></span>称为 x 的前后提。 <br /><br /><strong>定义 1.4</strong> 六元组 &sum; = (S, T, F, K, W, M) 称为一个库所 / 变迁系统，简称为 P / T 系统，如果下列条件成立</p>
<ul>
<li>(S, T, F) 是一个 Petri 网图，<span class="texhtml">S 是库所的有限集合，</span><span class="texhtml">T 是变迁的有限集合，F 是有向弧的有限集合</span></li>
<li><span class="texhtml">K: S </span>&rarr; N &cup; {&omega;} 是一个映射，使 S 中的每个元素 x 与一个自然数或无穷大值相对应，称为 x 的容量</li>
<li>W: F &rarr; N - {0} 是一个映射，使 F 中的每条弧 f 与一个正整数对应，称为 f 的流量</li>
<li>M: S &rarr; N &cup; {&omega;} 是一个映射，使 S 中的每个元素与一个有穷或无穷的初始标码数相对应，整个 M 称为 &sum; 的初始标记，满足 M(x) &le; K(x)</li>
</ul>
<p><br /><strong>定义 1.5</strong> P / T 系统 &sum; = (S, T, F, K, W, M) 的运行规则如下：</p>
<ul>
<li>T 中任一变迁 t 被允许发生的条件是：<br />&forall; s &isin; <sup><strong><span style="font-size: small;">.</span></strong></sup>t，M(s)
	&ge; W(s, t)<br />&forall; s &isin; t<sup><strong><span style="font-size: small;">.</span></strong></sup>，M(s) &le; K(s) - W(t, s)<br />其中 W(s, t) 表示从 s 到 t 的弧的流量</li>
<li>如果变迁发生前的标记为 M，则变迁发生后的标记 M' 是<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; M(s) - W(s, t)， 若 s &isin; <sup><strong><span style="font-size: small;">.</span></strong></sup>t - t<sup><strong><span style="font-size: small;">.</span></strong></sup><br />M'(s) = <strong>{</strong> M(s) + W(t, s)，若 s &isin; t<sup><strong><span style="font-size: small;">.</span></strong></sup> - <sup><strong><span style="font-size: small;">.</span></strong></sup>t <strong>}</strong><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; M(s)，&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 其他 <br />注意，这里恒要求 <sup><strong><span style="font-size: small;">.</span></strong></sup>t &cap; t<sup><strong><span style="font-size: small;">. </span></strong></sup>= &Phi;</li>
<li>初始标记是标记，任一标记经过变迁以后仍然变为标记 </li>
</ul>
<h3>
参考 <br /></h3>
<p>[1] 李彤, 孔兵, 王黎霞等. 软件并行开发过程. 北京:科学出版社, 2003<br />[2] http://en.wikipedia.org/wiki/Petri_net </p>
<p>&nbsp;</p>
<p><strong>well-formatted doc: </strong></p>
<p><a href="http://docs.google.com/Doc?id=ddrm6c35_512f45hshcz">http://docs.google.com/Doc?id=ddrm6c35_512f45hshcz</a></p>
<p>&nbsp;</p>