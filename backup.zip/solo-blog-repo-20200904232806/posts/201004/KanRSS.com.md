title: KanRSS.com
date: '2010-04-25 15:18:00'
updated: '2010-04-25 15:18:00'
tags: [Life in Programming]
permalink: /articles/2010/04/24/1272151080000.html
---
<p>非常莫名的收到从 <a href="http://kanrss.com">http://kanrss.com</a>
 发来的邮件。上去看了一下，虽然还在开发，但简洁的聚合社交风格确实不错，不知道能不能持之以恒 :-)</p>
<p>&nbsp;</p>
<p>http://kanrss.com/rss/4263/claim/10015940/DZTnCaL2PzA-Aofhae4R_w
</p>