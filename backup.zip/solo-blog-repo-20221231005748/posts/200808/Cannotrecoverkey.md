title: Cannot recover key
date: '2008-08-20 03:01:00'
updated: '2008-08-20 03:01:00'
tags: [JavaEE Security, CAS &amp; SAML &amp; SSO]
permalink: /articles/2008/08/19/1219143660000.html
---
<b>&nbsp;java.security.UnrecoverableKeyException: Cannot recover key 处理<br><br></b><font face="Helvetica, Arial, sans-serif" size="-1">This exception may result from the fact that you had provided a key password that was different from the keystore password<br>
<br>
此错误由调用getKey（alias,aliaspassword）函数抛出。<br>
可能原因为aliaspassword的密码不正确，<br>
注意</font><font face="Helvetica, Arial, sans-serif" size="-1">aliaspassword必须是aias数字证书的密码。而不是keystore的密码。</font><br>