title: For the love of God
date: '2012-09-23 11:22:31'
updated: '2012-09-23 11:22:31'
tags: [Steve Vai, Music]
permalink: /for-the-love-of-god
---
<p>神曲。</p>
<p>让人感到战争的恐惧，让人向往心灵深处的未知。</p>
<p>&nbsp;</p>
<p><a href="http://pan.baidu.com/share/link?shareid=62380&amp;uk=3255126224">http://pan.baidu.com/share/link?shareid=62380&amp;uk=3255126224</a></p>