title: Windows 10 搭建 TensorFlow 试玩 fast-style-transfer
date: '2020-03-15 19:08:02'
updated: '2020-03-15 19:08:02'
tags: [TensorFlow, 深度学习, 图片处理]
permalink: /articles/2020/03/15/1584270480065.html
---
本文适用于 TensorFlow 新手搭建试玩“图片快速风格迁移”，系统环境：

* Windows 10
* 显卡 NVIDIA GTX 1070

### 安装 TensorFlow 环境

用 [Anaconda](https://www.anaconda.com) 来装环境可以省很多事。

1. 安装 Anaconda，步骤中有两个选项记得勾上（添加 PATH 环境变量和使用 Anaconda 作为 Python 环境）
2. 现在的 Anaconda 似乎已经内置了国内的几个镜像源，所以不用手动切换镜像，用默认配置即可

   如果已经折腾过，可以考虑用如下命令恢复：

   ```shell
   conda config --remove-key channels
   conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/free/
   conda config --set show_channel_urls yes
   ```
3. 如果你像我一样只是个入门玩家（并且平时没装过 Python 环境），那就不用搞 conda 的环境隔离了。直接执行 `conda install tensorflow-gpu`，然后等待

如果一切顺利的话 Tensorflow 环境就装好了（如果不顺利的话可能多半是网络问题，重试执行下试试）。

目前我用默认参数装好的 TF 版本是 1.14，lengstrom/fast-style-transfer 刚好只能在 TF v1.x 上用。

### 图片快速风格迁移

克隆[仓库](https://github.com/lengstrom/fast-style-transfer)，然后[下载](https://drive.google.com/drive/folders/0B9jhaT37ydSyRk9UX0wwX3BpMzQ?usp=sharing)已经训练好的风格，放到 model 目录下。

弄好以后就可以开始玩了，仓库根目录下执行：

```shell
python evaluate.py --checkpoint model/udnie.ckpt --in-path eval/ --out-path result/
```

如果报错，请参考[报错处理](#报错处理)解决。

如果要创建新风格，需要自己训练。先下载训练所需数据：

* [imagenet-vgg-verydeep-19.mat](http://www.vlfeat.org/matconvnet/models/beta16/imagenet-vgg-verydeep-19.mat)
* [train2014.zip](http://msvocds.blob.core.windows.net/coco2014/train2014.zip)

不要下其他的，就用 beta16 目录下的，否则后面训练时会报错。新手入门就按部就班吧，别折腾。

下载好后将 train2014.zip 解压到 data 目录下，imagenet-vgg-verydeep-19.mat 直接放到 data 目录下，可参考根目录下的 setup.sh 脚本。

```
├─data
│  │  imagenet-vgg-verydeep-19.mat
│  │
│  ├─bin
│  └─train2014
│          COCO_train2014_000000000009.jpg
│          COCO_train2014_000000000025.jpg
```

然后根目录下执行：

```shell
python style.py --style style/1.jpg --checkpoint-dir checkpoint --content-weight 1.5e1 --checkpoint-iterations 1000 --batch-size 12
```

大概经过 6 小时以后训练完成，在 checkpoint 目录下生成了模型文件：

```
checkpoint
fns.ckpt.data-00000-of-00001
fns.ckpt.index
fns.ckpt.meta
```

将 fns.ckpt.meta 复制一个，重命名为 fns.ckpt，然后就可以使用评估方法来生成图片了：

```shell
python evaluate.py --checkpoint checkpoint/fns.ckpt --in-path eval/ --out-path result/
```

### 报错处理

1. `AttributeError: 'module' object has no attribute 'imread'`，执行：
   ```shell
   pip install --upgrade scipy==1.1.0
   ```
2. `ImportError: No module named moviepy.video.io.VideoFileClip`，执行：
   ```shell
   pip install moviepy
   ```
3. `cudaGetDevice() failed. Status: CUDA driver version is insufficient for runtime version`，升级显卡驱动就行了
4. `tensorflow.python.framework.errors_impl.ResourceExhaustedError: OOM when allocating tensor with shape`，降低 `--bach-size` 参数就行了，8G 显存的话设置为 12

### 其他好玩的库

* [anishathalye/neural-style](https://github.com/anishathalye/neural-style)

  该仓库的输入是待处理图片+风格图片，边训练边生成，优点是方便切换风格，缺点是每次生成大概需要好几分钟。imagenet-vgg-verydeep-19.mat 和 train2014 可以用上面下载好的。

  ```shell
  python neural_style.py --content examples/test.png --styles examples/style/udnie.jpg --output test-result.jpg
  ```
* 如果觉得本地搭建 TensorFlow 太麻烦，可以通过 [IBM/MAX-Fast-Neural-Style-Transfer](https://github.com/IBM/MAX-Fast-Neural-Style-Transfer)（PyTorch）用 Docker 搭建试玩，或者直接[在线试玩](http://max-fast-neural-style-transfer.max.us-south.containers.appdomain.cloud/)
