title: Go Web 开发（一）
date: '2011-03-10 08:53:08'
updated: '2014-08-11 17:12:18'
tags: [Google, golang]
permalink: /go-web-1.html
---
<h2>目的</h2>
<p>了解 Go 开发 Web 应用的基本原理。</p>
<h2>效果</h2>
<p><img src="https://sn2files.storage.live.com/y1pVjaR1JowIjXKZfjxur14qI4--pUUrR93S0CZ885C80C3JuzXpGsef47SiBXdE-KsnYX0IP-XWrY/go-web-1-1.png?psid=1" alt="" width="355" height="141" /></p>
<p><img src="https://sn2files.storage.live.com/y1pNKLWcmfICnSldmCbkR6GYx4ADb1dRF_5KfKRUsAUvNKyaOwVvLMCHnYr2OkJXONX2ZXqPVZE9ds/go-web-1-2.png?psid=1" alt="" width="307" height="71" /></p>
<h2>代码</h2>
<blockquote>
<p>package main<br /> <br /> import (<br /> &nbsp;&nbsp;&nbsp; "fmt"<br /> &nbsp;&nbsp;&nbsp; "http"<br /> )<br /> <br /> type User struct {<br /> &nbsp;&nbsp;&nbsp; Name&nbsp;&nbsp;&nbsp; string<br /> }<br /> <br /> func Register(w http.ResponseWriter, r *http.Request) {<br /> &nbsp;&nbsp;&nbsp; if "GET" == r.Method {<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; fmt.Fprintln(w, "&lt;h1&gt;Register&lt;/h1&gt;" +<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; "&lt;form action='/' method='POST'&gt;" +<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; " User Name: &lt;input name='userName' value='Type in your name'/&gt;&lt;input type='submit' value='Register'/&gt;" +<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; "&lt;/form&gt;")<br /> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; return<br /> &nbsp;&nbsp;&nbsp; }<br /> <br /> &nbsp;&nbsp;&nbsp; user := &amp;User{r.FormValue("userName")}<br /> &nbsp;&nbsp;&nbsp; fmt.Fprintln(w, "Hello ", user.Name)<br /> }<br /> <br /> func main() {<br /> &nbsp;&nbsp;&nbsp; http.HandleFunc("/", Register)<br /> &nbsp;&nbsp;&nbsp; http.ListenAndServe(":8080", nil)<br /> }</p>
</blockquote>
<h2>总结</h2>
<ul>
<li>相比 Java Web 开发，简洁不少（语法、配置）</li>
<li>调试不方便，需要重编译、链接</li>
</ul>
<h2>下一步</h2>
<ul>
<li>模板入门</li>
<li>数据持久化</li>
</ul>
<p>----</p>
<p>Updates:</p>
<p>Nov 26, 2011 - 把图片移到了 SkyDrive</p>