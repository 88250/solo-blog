title: Java 执行命令
date: '2014-01-15 21:40:03'
updated: '2014-01-15 21:40:03'
tags: [Java]
permalink: /java-exec-utli
---
<p>Java 调用命令行有两种方式，ProcessBuilder 或 Runtime。</p>
<p>在使用 Runtime 时，有两点需要注意：</p>
<ol>
<li>需要开启线程读取错误流，否则可能会造成进程阻塞</li>
<li>执行带管道或重定向的命令时需要拆成多个命令执行<br />
<pre class="brush: java; gutter: false; toolbar: false">Execs.exec(new String[]{"/bin/sh", "-c", "cat /proc/cpuinfo | grep 'model name' | awk '{ print $NF }'"});</pre>
</li>
</ol>
<p>细节请参考这个<a href="https://github.com/b3log/b3log-latke/blob/master/latke/src/main/java/org/b3log/latke/util/Execs.java" target="_blank">实现</a>。</p>