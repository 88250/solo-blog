title: VirtualBox的文件共享
date: '2007-02-21 15:08:00'
updated: '2007-02-21 15:08:00'
tags: [My Linux]
permalink: /articles/2007/02/20/1172012880000.html
---
<span class="postbody"><font size="2"> 1. 安装VirtualBox&nbsp;Guest&nbsp;Additions，的VirtualBox的Devices选项里。<br /> <br />2. 终端中输入&nbsp;<br /> VBoxManage&nbsp;sharedfolder&nbsp;add&nbsp; 虚拟机名称 -name&nbsp; 共享文件夹名称 -hostpath 共享文件夹路径<br />比如：VBoxManage sharedfolder add MyXP -name test -hostpath /home/<br />这里的虚拟机名称可以用</font></span>VBoxManage list vms命令查看。<br /><br /><span class="postbody"><font size="2">3. XP中开始--&gt;运行--&gt;cmd <br /> net&nbsp;use&nbsp;x:&nbsp;\\vboxsvr\共享文件夹名称 <br />注意：这里的x:后面有一个空格哟 :-)<br /><br /> 4.在&ldquo;我的电脑&rdquo;中出现的x盘符就是共享文件夹，默认就具有读写权限 </font></span>