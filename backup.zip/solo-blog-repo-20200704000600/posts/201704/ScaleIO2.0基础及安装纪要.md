title: ScaleIO 2.0 基础及安装纪要
date: '2017-04-20 08:08:30'
updated: '2017-04-20 08:08:30'
tags: [ScaleIO, EMC, SAN, VMWare]
permalink: /articles/2017/04/20/1492618091927.html
---
## ScaleIO 基础概念

ScaleIO 是一套由 EMC 提供的软件定义存储的解决方案，用于实现虚拟化 SAN。它主要的优势是

* 不局限于平台：可以融合异构系统，比如可以同时使用 VMware、Windows、Linux 来构建存储池并使用
* 优秀的横向扩展能力：存储提供可以扩展到上千节点
* 动态扩容能力：动态增减节点非常容易

![ec1e4ddc791247f0b912ae33192116e4.png](https://img.hacpai.com/file/2017/4/ec1e4ddc791247f0b912ae33192116e4.png) 

### MDM

Meta Data Manager，即元数据管理器。至少由 3 个节点组成一个集群：

* Primary MDM：主管理器
* Secondary MDM：从管理器
* Tie Breaker：决策器

### SDS

ScaleIO Data Server，即数据服务器。将主机上的磁盘通过网络抽象为存储池。

### SDC

ScaleIO Data Client，即数据客户端。创建卷后在安装了 SDC 的系统上可以看见卷被暴露为标准块设备，格式化后就能直接用了。

### GW

Gateway，即网关。是一个 Web 服务，提供了 ScaleIO 的 RESTFul API。

### GUI 

管理客户端，UI 很酷炫并且简单易用。可以直观看到容量、IO 情况，创建池、卷等。

## vSphere 环境安装

### 网络规划

管理网络使用当前虚拟机的网络，数据网络使用部署向导来创建。数据网络最好使用单独的高带宽网卡，和其他虚拟机网络分开网段。

如果要建立多个数据网络，那要注意不能在同一个网段。

### 部署步骤

1. [下载](http://downloads.emc.com/emc-com/usa/ScaleIO/ScaleIO_VMware_v2.0.zip)软件、文档包
2. 安装 vSphere 插件
3. 安装 SDC，这一步手动安装也不复杂，建议手动安装，因为需要确认 SDC 配置的 MDM IP
4. 在 vSphere Web Client 中通过第 2 步安装好的插件部署 ScaleIO 环境

### 安装常见问题

* Failed: Configure SDC driver on ESX (The SDC cannot communicate with the MDM cluster. Verify vmkernel and/or portgroup settings.)
   这个问题是由于 SDC 配置不对引起的，在安装 SDC 后一定要到 ESX 上看一下 SDC 的参数，通过命令 `esxcli system module parameters list -m scini` 查看。如果 MDM IP 不对，可使用 `esxcli system module parameters set -m scini -p "IoctlMdmIPStr=<LIST_VIP_MDM_IPS>"` 进行更新。***配置完成后一定要记得重启 ESX！只有当 SDC 正确配置完成后再进行 ScaleIO 环境部署。***

* Failed: Add MASTER_MDM to MDM cluster (ScaleIO - Cannot connect to master MDM)
   在只回滚失败的任务后下次部署会碰到这个报错，应该是因为 MDM 已经成功安装过，不能重复加入同一集群。部署碰到失败时最好回滚整个部署过程（SDC 可以不重置）。

## 杂项记录

记录一下一些可能会用到的命令。

### PowerShell 

开放执行权限： `Set-ExecutionPolicy -ExecutionPolicy UNRESTRICTED`

### VMware

* 查看 ESX 上 SDC 的参数：`esxcli system module parameters list -m scini`
* 配置 ESX 上 SDC 的参数：`esxcli system module parameters set -m scini -p ""IoctlIniGuidStr=<GUID> IoctlMdmIPStr=<LIST_VIP_MDM_IPS>"`

### Linux 

在 Linux（虚拟机）上安装 SDC：`MDM_IP=<LIST_VIP_MDM_IPS> rpm -i EMC-ScaleIO-sdc-2.0-12000.122.el7.x86_64.rpm`

### SDC

管理和状态查看：`/opt/emc/scaleio/sdc/bin/drv_cfg`

## 参考

* [EMC ScaleIO 解决方案简介](https://wenku.baidu.com/view/a05279e1680203d8cf2f241b.html)
* [ScaleIO 一些基础知识介绍](http://www.nextech.space/nextech/2016/07/scaleio%E4%B8%80%E4%BA%9B%E5%9F%BA%E7%A1%80%E7%9F%A5%E8%AF%86%E4%BB%8B%E7%BB%8D/)
* [在 vSphere 中安装 ScaleIO 1.32](http://www.nextech.space/nextech/2016/07/gui%E6%96%B9%E5%BC%8F%E5%9C%A8vsphere%E7%8E%AF%E5%A2%83%E4%B8%AD%E5%AE%89%E8%A3%85emc-scaleio-1-32-x-part2/)