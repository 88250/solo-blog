title: BeyondTrack ---- 项目管理与团队协作工具
date: '2008-11-02 08:41:00'
updated: '2008-11-02 08:41:00'
tags: [Open Source, BeyondTrack, JBoss Seam]
permalink: /articles/2008/11/01/1225557660000.html
---
<meta http-equiv="CONTENT-TYPE" content="text/html; charset=utf-8">
	<title></title>
	<meta name="GENERATOR" content="OpenOffice.org 2.4  (Linux)">
	<style type="text/css">
	<!--
		@page { size: 8.5in 11in; margin: 0.79in }
		P { margin-bottom: 0.08in }
		H1 { margin-bottom: 0.08in }
		H1.western { font-family: "Nimbus Sans L", sans-serif; font-size: 16pt }
		H1.cjk { font-family: "DejaVu Sans"; font-size: 16pt }
		H1.ctl { font-family: "DejaVu Sans"; font-size: 16pt }
		H3 { margin-bottom: 0.08in }
		H3.western { font-family: "Nimbus Sans L", sans-serif }
	-->
	</style>

<h1 class="western" align="left">BeyondTrack <font face="DejaVu Sans">项目简介
</font>
</h1>
<h3 class="western"><font face="DejaVu Sans">一、项目概述 </font>
</h3>
<p align="left">ByondTrack <font face="DejaVu Sans">是一个基于
</font>JavaEE <font face="DejaVu Sans">平台的 </font>B/S
<font face="DejaVu Sans">结构项目管理与团队协作工具。该工具具有如下特性：
</font>
</p>
<p align="left">
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;<b>1. </b><font face="DejaVu Sans"><b>工作流管理（</b></font><b>Workflow
Management</b><font face="DejaVu Sans"><b>）</b></font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="DejaVu Sans">基于工作流引擎</font>(jBPM)<font face="DejaVu Sans">，团队流程建模后的流程定义可以直接部署到系统中，系统将按照流程</font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <font face="DejaVu Sans">定义控制团队过程
</font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;<b>2. </b><font face="DejaVu Sans"><b>任务管理（</b></font><b>Task
Management</b><font face="DejaVu Sans"><b>） </b></font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BeyondTrack
<font face="DejaVu Sans">提供了对项目个生命周期的管理，从项目计划、需求，到实施、发布、维护全方</font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<font face="DejaVu Sans">位的监控。管理项基本分为两类：流程任务与自定制任务
</font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;<b>3. </b><font face="DejaVu Sans"><b>文档管理（</b></font><b>Document
Management</b><font face="DejaVu Sans"><b>） </b></font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="DejaVu Sans">在
</font>BeyondTrack <font face="DejaVu Sans">中，所有文档都是使用
</font>Wiki <font face="DejaVu Sans">进行管理，以方便修改与历史追踪
</font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;<b>4. </b><font face="DejaVu Sans"><b>与已有系统的整合（</b></font><b>Integration
of Existing systems</b><font face="DejaVu Sans"><b>） </b></font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="DejaVu Sans">将提供</font>CAS<font face="DejaVu Sans">、</font>LDAP<font face="DejaVu Sans">、</font>Subversion<font face="DejaVu Sans">、</font>Mylyn<font face="DejaVu Sans">等外部系统方便的整合配置
</font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;<b>5. </b><font face="DejaVu Sans"><b>适合各种类型的团队
（</b></font><b>Adapt to your Team</b><font face="DejaVu Sans"><b>）
</b></font>
</p>
<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="DejaVu Sans">无论是敏捷方法的团队还是使用非敏捷方法的团队都可以使用该工具进行项目管理与团队协作
</font>
</p>
<p align="left">
</p>
<h3 class="western"><font face="DejaVu Sans">二、关键架构决策
</font>
</h3>
<p align="left"><font face="DejaVu Sans">在考虑了现有一些 </font>Java
<font face="DejaVu Sans">框架 </font>/ <font face="DejaVu Sans">框架组合与技术后，决定采用
</font>JBoss Seam <font face="DejaVu Sans">作为应用框架，这个决定出于以下几点考虑：
</font>
</p>
<ul><li><p align="left">Seam <font face="DejaVu Sans">是下一代的</font>Java<font face="DejaVu Sans">企业级开发框架，</font>Web
	Beans<font face="DejaVu Sans">（</font>JSR299<font face="DejaVu Sans">）参考实现
	</font>
</p>
	</li><li><p align="left">Seam <font face="DejaVu Sans">整合的技术在整体性上比
	</font>Spring <font face="DejaVu Sans">整合的技术更适合本项目，设计、开发、配置更为简化
	</font>
</p>
	</li><li><p align="left">Seam <font face="DejaVu Sans">提供的上下文管理
	、组件注射、表达式语言、作用域管理是现有框架不能比拟的
	</font>
</p>
</li></ul>
<p align="left"><font face="DejaVu Sans">但是，</font>Seam <font face="DejaVu Sans">也带来一些问题：
</font>
</p>
<ul><li><p align="left"><font face="DejaVu Sans">当前，</font>Seam<font face="DejaVu Sans">对
	</font>JBoss AS <font face="DejaVu Sans">的支持更好，要想“简单地”使用
	</font>Seam <font face="DejaVu Sans">带来的所有好处，必须使用</font>JBoss
	AS<font face="DejaVu Sans">。虽然 </font>Seam
	<font face="DejaVu Sans">承诺了可以允许在很多服务器上，但是，配置复杂度和开发限制是个问题
	</font>
</p>
	</li><li><p align="left">Seam <font face="DejaVu Sans">框架目前属于高速发展期，技术变革风险很难避免
	</font>
</p>
</li></ul>
<h3 class="western"><font face="DejaVu Sans">三、</font>Open
Source<font face="DejaVu Sans">！ </font>
</h3>
<p align="left">BeyondTrack <font face="DejaVu Sans">是一个开源的项目，在
</font>CDDL<font face="DejaVu Sans">（</font>Common Development and
Distribution License<font face="DejaVu Sans">，通用开发与发布许可）开源许可证下。如果你对这个项目有兴趣，请访问：
</font><a href="https://beyondtrack.dev.java.net/">https://beyondtrack.dev.java.net/</a></p>