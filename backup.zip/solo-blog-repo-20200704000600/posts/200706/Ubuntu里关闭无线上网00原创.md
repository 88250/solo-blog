title: Ubuntu里关闭无线上网[00原创]
date: '2007-06-30 03:13:00'
updated: '2007-06-30 03:13:00'
tags: [My Linux]
permalink: /articles/2007/06/29/1183115580000.html
---
我的无线网卡和红外用的都是一个指示灯，上次关闭了红外连接，不过那个指示灯还是会不时的闪一下，这次应该彻底了:<br /><br />
<div style="border: 0.5pt solid windowtext; padding: 4px 5.4pt; background: rgb(230, 230, 230) none repeat scroll 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; width: 95%;">
<div><img align="top" src="http://images.csdn.net/syntaxhighlighting/OutliningIndicators/None.gif" alt="" /><span style="color: rgb(0, 0, 0);">sudo&nbsp;gedit&nbsp;</span><span style="color: rgb(0, 0, 0);">/</span><span style="color: rgb(0, 0, 0);">etc</span><span style="color: rgb(0, 0, 0);">/</span><span style="color: rgb(0, 0, 0);">iftab</span></div>
</div>
&nbsp;<br />注释掉不需要的网卡，OK！