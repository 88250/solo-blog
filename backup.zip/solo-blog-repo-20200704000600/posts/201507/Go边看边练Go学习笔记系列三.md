title: Go 边看边练 -《Go 学习笔记》系列（三）
date: '2015-07-24 22:35:15'
updated: '2015-12-29 22:41:44'
tags: [Golang, Go学习笔记, 教程, 雨痕]
permalink: /articles/2015/07/24/1437719712835.html
---
上一篇： [1437558810339] 

----

### ToC

* [Go 边看边练 -《Go 学习笔记》系列（一）- 变量、常量](http://symphony.b3log.org/article/1437497122181)
* [Go 边看边练 -《Go 学习笔记》系列（二）- 类型、字符串](http://symphony.b3log.org/article/1437558810339)
* [Go 边看边练 -《Go 学习笔记》系列（三）- 指针](http://symphony.b3log.org/article/1437719712835)
* [Go 边看边练 -《Go 学习笔记》系列（四）- 控制流1](http://symphony.b3log.org/article/1437984612418)
* [Go 边看边练 -《Go 学习笔记》系列（五）- 控制流2](http://symphony.b3log.org/article/1438070631857)
* [Go 边看边练 -《Go 学习笔记》系列（六）- 函数](http://symphony.b3log.org/article/1438164538421)
* [Go 边看边练 -《Go 学习笔记》系列（七）- 错误处理](http://symphony.b3log.org/article/1438260619759)
* [Go 边看边练 -《Go 学习笔记》系列（八）- 数组、切片](http://symphony.b3log.org/article/1438311936449)
* [Go 边看边练 -《Go 学习笔记》系列（九）- Map、结构体](http://symphony.b3log.org/article/1438596722873)
* [Go 边看边练 -《Go 学习笔记》系列（十）- 方法](http://symphony.b3log.org/article/1438699210452)
* [Go 边看边练 -《Go 学习笔记》系列（十一）- 表达式](http://symphony.b3log.org/article/1438763483577)
* [Go 边看边练 -《Go 学习笔记》系列（十二）- 接口](http://symphony.b3log.org/article/1438845728987)
* [Go 边看边练 -《Go 学习笔记》系列（十三）- Goroutine](http://symphony.b3log.org/article/1438938175118)
* [Go 边看边练 -《Go 学习笔记》系列（十四）- Channel](http://symphony.b3log.org/article/1439194647152)

----

### 1.7 指针

支持指针类型 `*T`，指针的指针 `**T`，以及包含包名前缀的 `*<package>.T`。

* 默认值 `nil`，没有 `NULL` 常量。
* 操作符 "&" 取变量地址，"\*" 透过指针访问目标对象。
* 不支持指针运算，不支持 "->" 运算符，直接用 "." 访问目标成员。

<iframe style="border:1px solid" src="https://wide.b3log.org/playground/184423db927cf64ca677675ab6db789d.go?embed=true" width="99%" height="400"></iframe>

不能对指针做加减法等运算。

    x := 1234
    p := &x
    p++ // Error: invalid operation: p += 1 (mismatched types *int and int)

可以在 `unsafe.Pointer` 和任意类型指针间进行转换。

<iframe style="border:1px solid" src="https://wide.b3log.org/playground/7af2e598bd6ba3613dbad1fc8cf83168.go?embed=true" width="99%" height="500"></iframe>

返回局部变量指针是安全的，编译器会根据需要将其分配在 GC Heap 上。

    func test() *int {
    	x := 100
    	return &x // 在堆上分配 x 内存。但在内联时，也可能直接分配在目标栈。
    }

将 `Pointer` 转换成 `uintptr`，可变相实现指针运算。

<iframe style="border:1px solid" src="https://wide.b3log.org/playground/4e01a7824fff97c5a8bf4f16771a3abd.go?embed=true" width="99%" height="600"></iframe>

注意：GC 把 `uintptr` 当成普通整数对象，它无法阻止 "关联" 对象被回收。

### 1.8 自定义类型

可将类型分为命名和未命名两大类。命名类型包括 `bool`、`int`、`string` 等，而 `array`、`slice`、`map` 等和具体元素类型、长度等有关，属于未命名类型。

具有相同声明的未命名类型被视为同一类型。

* 具有相同基类型的指针。
* 具有相同元素类型和长度的 `array`。
* 具有相同元素类型的 `slice`。
* 具有相同键值类型的 `map`。
* 具有相同元素类型和传送方向的 `channel`。
* 具有相同字段序列 (字段名、类型、标签、顺序) 的匿名 `struct`。
* 签名相同 (参数和返回值，不包括参数名称) 的 `function`。
* 方法集相同 (方法名、方法签名相同，和次序无关) 的 `interface`。

例如，

	var a struct { x int \`a\` }
    var b struct { x int \`ab\` }
    
    // cannot use a (type struct { x int "a" }) as type struct { x int "ab" } in assignment
    b = a

可用 `type` 在全局或函数内定义新类型。

    func main() {
    	type bigint int64
    
    	var x bigint = 100
    	println(x)
    }

新类型不是原类型的别名，除拥有相同数据存储结构外，它们之间没有任何关系，不会持有原类型任何信息。除非目标类型是未命名类型，否则必须显式转换。

    x := 1234
    var b bigint = bigint(x) // 必须显式转换，除非是常量。
    var b2 int64 = int64(b)
    
    var s myslice = []int{1, 2, 3} // 未命名类型，隐式转换。
    var s2 []int = s

下一篇： [1437984612418] 

----

* ***本系列是基于***[雨痕](https://github.com/qyuhen)***的***[《Go 学习笔记》（第四版）](https://github.com/qyuhen/book/blob/master/Go%20%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0%20%E7%AC%AC%E5%9B%9B%E7%89%88.pdf)***整理汇编而成，非常感谢雨痕的辛勤付出与分享！***
* 转载请注明：文章转载自：**黑客与画家的社区** [[http://symphony.b3log.org](http://symphony.b3log.org)]
* 如果你觉得本章节做得不错，请在下面打赏一下吧~

----

> 社区小贴士
>
> * 关注标签 [golang] 可以方便查看 Go 相关帖子
> * 关注标签 [Go学习笔记] 可以方便查看本系列
> * 关注作者后如有新帖将会收到通知

<p style='font-size: 12px;'><i>该文章同步自 <a href='http://hacpai.com/article/1437719712835' target='_blank'>黑客派</a></i></p>