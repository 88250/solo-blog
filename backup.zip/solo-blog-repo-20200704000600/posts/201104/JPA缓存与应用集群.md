title: JPA 缓存与应用集群
date: '2011-04-25 21:40:40'
updated: '2011-11-27 03:23:04'
tags: [Java Persistence API, JPA, Cache, Oracle, JavaEE, Architecture Design]
permalink: /jpa-cache-cluster.html
---
<h1>JPA 缓存与集群</h1>
<p>转载请保留作者信息：<br />作者：<a id="g4ll" title="88250's Blog" href="http://b3log-88250.appspot.com/undefined/">88250</a><br />日期：2011 年 4 月 25 日</p>
<h2>ToC</h2>
<p style="padding-left: 30px;"><a href="#abstraction">摘要</a></p>
<p style="padding-left: 30px;"><a href="#jpa-cache">JPA 缓存</a></p>
<p style="padding-left: 30px;"><a href="#jpa-cluster">JPA 与应用集群</a></p>
<p style="padding-left: 30px;">&nbsp;&nbsp;&nbsp; <a href="#strategy1-disable-l2cache">策略 1：禁用 L2 缓存</a></p>
<p style="padding-left: 30px;">&nbsp;&nbsp;&nbsp; <a href="#strategy2-cache-coordination">策略 2：L2 缓存同步</a></p>
<p style="padding-left: 30px;">&nbsp;&nbsp;&nbsp; <a href="#strategy3-coherent-data-service">策略 3：一致性数据层</a></p>
<p style="padding-left: 30px;"><a href="#conclusion">结语</a></p>
<p style="padding-left: 30px;">&nbsp;&nbsp;&nbsp; <a href="#reflection">反思</a></p>
<p style="padding-left: 30px;"><a href="#reference">参考</a></p>
<p>&nbsp;</p>
<h2>摘要<a name="abstraction"></a></h2>
<p>本文主要介绍了 JPA 缓存体系结构以及在集群环境下 JPA 二级缓存的问题及应对策略。</p>
<h2>JPA 缓存<a name="jpa-cache"></a></h2>
<p>JPA 缓存分为一级缓存（L1）与二级缓存（L2）。</p>
<p>其中，一级缓存即实体管理器（EntityManager），主要负责实体状态管理。<br />二级缓存即 EntityManagerFactory 缓存，主要负责缓存实体或数据行（例如 EclipseLink 缓存实体，Hibernate 缓存实体 Id 与数据行）。</p>
<p>查询时，二级缓存可以有效缓解数据库压力，并有助于集合实体的初始化。</p>
<p><img src="https://sn2files.storage.live.com/y1pWKDxEFMij0zxNKgX_lhUqaeFR62lPZjKKR7ly_um6Q91HtEihEETBybFxqy6np7oJQy__KakeFs/JPACache1.png?psid=1" alt="JPA Cache" width="288" height="404" /></p>
<h2>JPA 与应用集群<a name="jpa-cluster"></a></h2>
<p>当应用运行在一个 JVM 里时，JPA 缓存是没有问题的。但如果进行应用集群，那么 L2 的更新机制将出现一致性问题。</p>
<p><img src="https://sn2files.storage.live.com/y1pPuSs30DQkDK_EgXA6PBBap5Ybp0pLpdztE2NNbbRIAJxBLm5CRaY50k11-THBAGe8ufZn1Dhs6A/JPACache2.png?psid=1" alt="JPA Cache in Cluster" width="612" height="393" />&nbsp;</p>
<p>下面提供两个通用策略以及一个产品相关策略来解决这个问题。</p>
<h3>策略 1：禁用 L2 缓存<a name="strategy1-disable-l2cache"></a></h3>
<p>如果禁用二级缓存的话，</p>
<ul>
<li>所有节点的数据视图总是可以保证一致<br />
<ul>
<li>数据总是一致的</li>
<li>每一次事务查询时都将从数据库获取数据构造实体</li>
</ul>
</li>
</ul>
<ul>
<li>不存在节点间消息</li>
<li>应用占用内存上升，因为每次事务都要构造实体</li>
<li>每次事务需要效率变低，因为需要构造实体</li>
<li><span style="color: #ff0000;">性能瓶颈&mdash;&mdash;数据库</span></li>
</ul>
<h3>策略 2：L2 缓存同步<a name="strategy2-cache-coordination"></a></h3>
<p><img src="https://sn2files.storage.live.com/y1pGKMpanIlF2A0O4UH36RwVa9qUTFsblo0uv_5ebcM7hAXBGsCrt6lm8xeO71qEBRjcwmtg7Vyh4s/JPACache3.png?psid=1" alt="JPA Cache Coordination in Cluster" width="594" height="376" /></p>
<p>如果进行 L2 缓存同步，</p>
<ul>
<li>所有节点的数据视图总是可以保证一致<br />
<ul>
<li>数据总是一致的</li>
<li>事务查询尽量使用 L2 缓存的实体</li>
</ul>
</li>
</ul>
<ul>
<li>创建/更新/删除 实体时需要同步所有其他节点</li>
<li>同步代价为 O(n<sup>2</sup>)&mdash;&mdash;<span style="color: #ff0000;">网络通讯与同步处理开销可能会超过缓存带来的好处</span><br />
<p><img src="https://sn2files.storage.live.com/y1pAzqWsbNguFcsRC-oShNG0sPXRcyfOsPfdhgfJfrSjt77ci6VDnH8f_N5-atp37Rib0O4FfDDvow/Cache%2BCoordination.png?psid=1" alt="Cache Cooradination" width="267" height="230" />（Orz）</p>
</li>
<li>L2 缓存大小受限于单个节点 JVM 内存堆大小</li>
</ul>
<p>主流 JPA 实现一般会提供 JMS、RMI、JGroups 来进行缓存同步。</p>
<h3>策略3：一致性数据层<a name="strategy3-coherent-data-service"></a></h3>
<p>这里所谓的&ldquo;一致性数据层&rdquo;就是指使用一个能够保证分布式时数据一致性的服务，用于替换 L2。</p>
<p>例如组合使用 <a href="http://www.oracle.com/technetwork/middleware/coherence/overview/index.html" target="_blank">Oracle Coherence</a> 与 <a href="http://www.oracle.com/technetwork/middleware/toplink/overview/index.html" target="_blank">TopLink Grid</a>。</p>
<h2>结语<a name="conclusion"></a></h2>
<p>对于一个基于 JPA 的 Web 应用，我们必须注意 JPA 二级缓存在集群时的问题，这是可伸缩的基本点之一。</p>
<p>为了解决 JPA 二级缓存不一致的问题，我们必须牺牲一定的应用性能，或是使用商业产品。</p>
<h3>反思<a name="reflection"></a></h3>
<p>ORM 固然方便，但我认为它带来的问题远比解决的问题多，基于关系型数据库的应用还是 JDBC 直接。</p>
<p>框架是为了简化代码，统一管理。但同时带来的限制也不容忽视。</p>
<p>个人还是偏向于自造轮子，宁肯多写一些代码，也不愿被框架束缚。</p>
<h2>参考<a name="reference"></a></h2>
<ul>
<li>Shaun Smith, <em>TopLink Grid: Scaling JPA Application with Coherence</em>, 2010</li>
<li>Tom Pfaeffle, <em>Oracle Fusion Middleware Integration Guide for Oracle TopLink with Coherence Grid, 11g Release 1 (11.1.1)&nbsp; E16596-02</em>, 2011-02</li>
<li>Doug Clarke, <em>Persistence Strategies for Java EE and WebLogic</em></li>
<li><a href="http://www.eclipse.org/eclipselink/" target="_blank">EclipseLink</a></li>
<li>Sandesh, <a href="http://www.google.com/url?sa=t&amp;source=web&amp;cd=1&amp;ved=0CBcQFjAA&amp;url=http%3A%2F%2Fsandeshudupa.blogspot.com%2F2010%2F11%2Ftoplink-cache-and-weblogic-cluster.html&amp;rct=j&amp;q=Toplink%20Cache%20and%20Weblogic%20Cluster%20&amp;ei=AQG1TYCgHYGKvQP74dCHBw&amp;usg=AFQjCNGmLKyS9DR16dY05Bqx2ExJ8FRKJg&amp;sig2=DfqZORIN0UgIhnFKShsPyw&amp;cad=rja" target="_blank"><em>Toplink Cache and Weblogic Cluster</em></a></li>
</ul>
<p>----</p>
<p>Updates:</p>
<p>Nov 26, 2011 - 把图片移到了 SkyDrive</p>