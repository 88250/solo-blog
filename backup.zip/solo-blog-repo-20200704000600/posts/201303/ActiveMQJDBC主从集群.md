title: ActiveMQ JDBC 主从集群
date: '2013-03-08 01:05:43'
updated: '2013-07-01 23:02:26'
tags: [Translation, ActiveMQ, JMS]
permalink: /ActiveMQ-JDBC-Master-Slave
---
<p>从 ActiveMQ 4.1 版本开始支持 JDBC 主从集群。</p>
<p>如果你正在使用纯 JDBC 以及非高性能日志，那可以认为数据库是一个存在单点故障的地方。</p>
<p>如果你的应用没有高性能需求，那单一数据库的方式是最容易备份与管理的。（译注：可以理解为使用 JDBC 主从集群使用单一数据库容易配置）</p>
<h2>启动</h2>
<p>当你使用 JDBC 作为数据源时，你可以使用主从方式进行 ActiveMQ 集群，运行多个代理如下图。</p>
<p>启动时，一个主代理将从数据库获取排它锁&mdash;&mdash;所有其他的从代理将暂停服务，等待获取锁。</p>
<p><span><img src="https://pyqebw.dm1.livefilestore.com/y1ppjaNmr4-UPWlDqz6BgkecpHO2OIn8ytlTKciI3lsulh6WymOj5EP6-Bly1ki0KJ7IaiKlI63AsnVdmzkztl9oSQYOQ5y3LPX/Startup.png?psid=1" alt="Startup" width="328" height="247" /></span></p>
<p>客户端应该使用<a href="http://activemq.apache.org/failover-transport-reference.html" target="_blank">故障转移传输</a>来连接 ActiveMQ 服务代理。例如使用如下形式的 URL：</p>
<pre class="brush: plain">failover:(tcp://broker1:61616,tcp://broker2:61616,tcp://broker3:61616)</pre>
<p><span><span><span>主代理必须启动传输连接器后客户端才能连接到，详见文末配置示例。（译注：获取排它锁后，主代理才会启动传输连接器）</span></span></span></p>
<h2><span><span><span>主代理故障</span></span></span></h2>
<p><span><span><span>当主代理丢失数据库连接或丢失排它锁时，主代理将被关闭。当主代理关闭或故障时，其他任一从代理将获取到排它锁，拓扑逻辑如下图：</span></span></span></p>
<p><span><span><span><span><img src="https://pyqebw.dm1.livefilestore.com/y1p_vnTTWIQEcYk-YF0FsJRZU_FpdFUKrsMZabyM0MFh4Hk5OjWRJ69dWXulblEjHuOfENQtc8Yf1Tc4iG0NB8tphs8oAq0D1N_/MasterFailed.png?psid=1" alt="MasterFailed" width="229" height="247" /></span></span></span></span></p>
<p><span><span><span><span>一旦某一从代理获取了数据库排它锁，则它将成为主代理，并启用传输连接器。</span></span></span></span></p>
<p>客户端丢失对已经停止服务的代理，并使用故障转移传输尝试连接其他代理&mdash;&mdash;唯一可用的就是刚才新启的主代理。（译注：客户端应该是逐一尝试，因为此时客户端并不知道哪个地址的代理成为了主代理）</p>
<h2>主代理重启</h2>
<p>任何时刻你都可以重启集群中已经挂了的代理，重启后拓扑逻辑如下图：</p>
<p><span><img src="https://pyqebw.dm1.livefilestore.com/y1ppjaNmr4-UPV02ix2WOrBAAzaTjhgLNEdJLliIf3eqhBX-lOg1LfC7M5aS8ST8-LAuC8iMane3psWUYpjXIeerTbrQOUJKc9L/MasterRestarted.png?psid=1" alt="MasterRestarted" width="328" height="247" /></span></p>
<h2><span>配置 JDBC 主从</span></h2>
<p><span>使用&nbsp;<strong>&lt;jdbcPersistenceAdapter/&gt;&nbsp;</strong>避免高性能日志，从而使用默认的 JDBC 主从配置。你只需启动多个代理并配置客户端 URLs 来连接该主从集群。</span></p>
<p>这些代理都会尝试获取数据库表排它锁，并且只有一个代理会获取到从而成为主代理。</p>
<p>&nbsp;</p>
<p>如下的配置示例展示了如何配置 ActiveMQ JDBC 主从集群：</p>
<pre class="brush: xml">&lt;beans&gt;

  &lt;!-- Allows us to use system properties as variables in this configuration file --&gt;
  &lt;bean class="org.springframework.beans.factory.config.PropertyPlaceholderConfigurer"/&gt;
  
  &lt;broker xmlns="http://activemq.apache.org/schema/core"&gt;

    &lt;destinationPolicy&gt;
      &lt;policyMap&gt;&lt;policyEntries&gt;
        
          &lt;policyEntry topic="FOO.&gt;"&gt;
            &lt;dispatchPolicy&gt;
              &lt;strictOrderDispatchPolicy /&gt;
            &lt;/dispatchPolicy&gt;
            &lt;subscriptionRecoveryPolicy&gt;
              &lt;lastImageSubscriptionRecoveryPolicy /&gt;
            &lt;/subscriptionRecoveryPolicy&gt;
          &lt;/policyEntry&gt;

      &lt;/policyEntries&gt;&lt;/policyMap&gt;
    &lt;/destinationPolicy&gt;
  
  
    &lt;persistenceAdapter&gt;
        &lt;jdbcPersistenceAdapter dataDirectory="${activemq.base}/activemq-data"/&gt;

        &lt;!-- 
        &lt;jdbcPersistenceAdapter dataDirectory="activemq-data" dataSource="#oracle-ds"/&gt;
        --&gt; 
    &lt;/persistenceAdapter&gt;
  
    &lt;transportConnectors&gt;
       &lt;transportConnector name="default" uri="tcp://localhost:61616"/&gt;
    &lt;/transportConnectors&gt;
    
  &lt;/broker&gt;
  
  &lt;!--  This xbean configuration file supports all the standard spring xml configuration options --&gt;
  
  &lt;!-- Postgres DataSource Sample Setup --&gt;
  &lt;!-- 
  &lt;bean id="postgres-ds" class="org.postgresql.ds.PGPoolingDataSource"&gt;
    &lt;property name="serverName" value="localhost"/&gt;
    &lt;property name="databaseName" value="activemq"/&gt;
    &lt;property name="portNumber" value="0"/&gt;
    &lt;property name="user" value="activemq"/&gt;
    &lt;property name="password" value="activemq"/&gt;
    &lt;property name="dataSourceName" value="postgres"/&gt;
    &lt;property name="initialConnections" value="1"/&gt;
    &lt;property name="maxConnections" value="10"/&gt;
  &lt;/bean&gt;
  --&gt;
  
  &lt;!-- MySql DataSource Sample Setup --&gt;
  &lt;!-- 
  &lt;bean id="mysql-ds" class="org.apache.commons.dbcp.BasicDataSource" destroy-method="close"&gt;
    &lt;property name="driverClassName" value="com.mysql.jdbc.Driver"/&gt;
    &lt;property name="url" value="jdbc:mysql://localhost/activemq?relaxAutoCommit=true"/&gt;
    &lt;property name="username" value="activemq"/&gt;
    &lt;property name="password" value="activemq"/&gt;
    &lt;property name="poolPreparedStatements" value="true"/&gt;
  &lt;/bean&gt;
  --&gt;  
   
  &lt;!-- Oracle DataSource Sample Setup --&gt;
  &lt;!--
  &lt;bean id="oracle-ds" class="org.apache.commons.dbcp.BasicDataSource" destroy-method="close"&gt;
    &lt;property name="driverClassName" value="oracle.jdbc.driver.OracleDriver"/&gt;
    &lt;property name="url" value="jdbc:oracle:thin:@localhost:1521:AMQDB"/&gt;
    &lt;property name="username" value="scott"/&gt;
    &lt;property name="password" value="tiger"/&gt;
    &lt;property name="poolPreparedStatements" value="true"/&gt;
  &lt;/bean&gt;
  --&gt;
      
  &lt;!-- Embedded Derby DataSource Sample Setup --&gt;
  &lt;!-- 
  &lt;bean id="derby-ds" class="org.apache.derby.jdbc.EmbeddedDataSource"&gt;
    &lt;property name="databaseName" value="derbydb"/&gt;
    &lt;property name="createDatabase" value="create"/&gt;
  &lt;/bean&gt;
  --&gt;  

&lt;/beans&gt;</pre>
<p><span>&nbsp;</span></p>
<p><span><span><span><span>译自：http://activemq.apache.org/jdbc-master-slave.html</span></span></span></span></p>