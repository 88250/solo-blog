title: 奇妙的 Docker Inspect 模版
date: '2015-03-31 22:50:59'
updated: '2015-03-31 22:50:59'
tags: [Translation, Inspect, Template, 模版, Docker, golang]
permalink: /docker-inspect-template-magic-chinese
---
<h3>概述</h3>
<p>很多 Docker 用户都知道 <em>docker inspect</em> 命令，该命令用于获取容器/镜像的元数据，其中&nbsp;<em>-f</em> 参数可以用于获取指定的数据，例如使用&nbsp;<em>docker inspect -f {{.IPAddress}}</em> 来获取容器的 IP 地址。不过很多用户容易被该特性的语法搞晕，并很少有人能将它的优势发挥出来（大部分人都是通过 <em>grep</em>&nbsp;来获取指定数据，虽然有效但比较零散混乱）。本文将详细介绍&nbsp;<em>-f</em>&nbsp;参数，并给出一些例子来说明如何使用它。</p>
<h3>docker inspect&nbsp;</h3>
<p>简单地说，<em>-f</em>&nbsp;的实参是个 Go 模版，并在容器/镜像的元数据上以该 Go 模版作为输入，最终返回模版指定的数据。第一个问题就是该命令说明文档中的用词&ldquo;Go 模版&rdquo;对于没有 Go 开发经验的人来说很模糊&mdash;&mdash;我的第一感觉就是它类似恐怖的 C++ 模版。还好 Go 模版和 C++ 模版/泛型毫不相干，Go 模版是一种<a href="https://en.wikipedia.org/wiki/Template_processor" target="_blank">模板引擎</a>，让数据以指定的模式输出。这个概念对于 Web 开发者是非常熟悉的，Web 领域有很多模版引擎，比如 Jinga2（用于 Python 和 Flask）、Mustache、JSP 等等，看下面的简单示例：</p>
<pre class="prettyprint">$ docker inspect -f 'Hello from container {{.Name}}' jenkins
Hello from container /jenkins</pre>
<p><span>我们可以看到，<em>-f</em>&nbsp;指定了一个简单的模式（或称之为<em>模版</em>）并应用于容器的元数据。当然，对于元数据，我们也可以什么都不指定：</span></p>
<pre class="prettyprint">$ docker inspect -f "This is a bit pointless" jenkins
This is a bit pointless</pre>
<p><span><span>下面让我们来进一步看看 Go 模版的奇妙之处，例如我们可以通过模版来查找所有退出码为非 0 的容器名：</span></span></p>
<pre class="prettyprint">$ docker inspect -f '{{if ne 0.0 .State.ExitCode }}{{.Name}} {{.State.ExitCode}}{{ end }}' $(docker ps -aq)

/tender_colden 1
/clever_mcclintock 126

/grave_bartik 1</pre>
<p>（无论是否匹配到，对于每个容器都会输出一行）</p>
<p>或者在&nbsp;<em>jenkins-data</em> 容器中查找卷&nbsp;<em>/var/jenkins_home</em> 对应在 host 的目录：</p>
<pre class="prettyprint">docker inspect -f '{{index .Volumes "/var/jenkins_home"}}' jenkins-data
/var/lib/docker/vfs/dir/5a6f7b306b96af38723fc4d31def1cc515a0d75c785f3462482f60b730533b1a</pre>
<p><span>上面的例子可能稍微有点难理解，不过没关系，我们先来了解一下 Go 模版的基本用法。</span></p>
<h3>模版指令</h3>
<p>{{ }} 语法用于处理模版指令，大括号外的任何字符都将直接输出。</p>
<h3>上下文</h3>
<p>&ldquo;.&rdquo; 表示&ldquo;当前上下文&rdquo;。大多数情况下表示了容器元数据的整个数据结构，但在某些情况下可以重新规定上下文，比如使用 <em>with</em>&nbsp;函数：</p>
<pre class="prettyprint">$ docker inspect -f '{{.State.Pid}}' jenkins
6331
$ docker inspect -f '{{with .State}} {{.Pid}} {{end}}' jenkins
6331</pre>
<p><span>可以使用 <em>$</em>&nbsp;来获取根上下文，例如：</span></p>
<pre class="prettyprint">$ docker inspect -f '{{with .State}} {{$.Name}} has pid {{.Pid}} {{end}}' jenkins
 /jenkins has pid 6331</pre>
<p><span><span>注意，单独使用 &ldquo;.&rdquo; 本身也是可以的，将输出未格式化的完整元数据：</span></span></p>
<pre class="prettyprint">$ docker inspect -f '{{.}}' jenkins
...</pre>
<h3>数据类型</h3>
<p>inspect 数据可以由浮点数、字符串和布尔组成，可以使用 Go 模版内置函数进行比较判断。虽然 Go 模版支持整数，但目前 inspect 数据中的数值类型都是浮点数，而整数应该对于大多数场景更方便（详见该 <a href="https://github.com/docker/docker/issues/11641" target="_blank">Issue</a>）。使用字符串时可以使用双引号。</p>
<p>数据中不存在的值是不可以用来比较的：</p>
<pre class="prettyprint">$ docker inspect -f '{{.ExecIDs}}' jenkins
&lt;no value&gt;
$ docker inspect -f '{{eq .ExecIDs .ExecIDs}}' jenkins
FATA[0000] template: :1:2: executing "" at &lt;eq .ExecIDs .ExecIDs&gt;: error calling eq: invalid type for comparison</pre>
<h3>数据结构</h3>
<p>inspect 数据使用 map 以及数组保存。Map 结构非常简单，前面我们曾经展示过，可以通过 . 的链式来访问&nbsp;map 内部数据：</p>
<pre class="prettyprint">$ docker inspect -f '{{.State.ExitCode}}' jenkins
0</pre>
<p>不过有些情况（比如 map 的键不是字符串）是不能直接使用 . 方式来获取 map 值的，此时我们可以使用 <em>index</em>&nbsp;函数，前面卷的例子可以这样写：</p>
<pre class="prettyprint">docker inspect -f '{{index .Volumes "/var/jenkins_home"}}' jenkins-data
/var/lib/docker/vfs/dir/5a6f7b306b96af38723fc4d31def1cc515a0d75c785f3462482f60b730533b1a</pre>
<p><span><span>我们也可以使用&nbsp;<em>index</em>&nbsp;来获取指定下标的数组值：</span></span></p>
<pre class="prettyprint">$ docker inspect -f '{{.HostConfig.Binds}}' jenkins
[/var/run/docker.sock:/var/run/docker.sock /usr/bin/docker:/usr/bin/docker]
$ docker inspect -f '{{index .HostConfig.Binds 1}}' jenkins
/usr/bin/docker:/usr/bin/docker</pre>
<h3>函数</h3>
<p>除了 <em>index</em>&nbsp;&nbsp;函数，其他很多函数也很常用。比如逻辑函数 <em>and</em>、<em>or</em>&nbsp;可以返回布尔结果。注意，函数是不能放在中间：</p>
<pre class="prettyprint">$ docker inspect -f '{{and true true}}' jenkins
true</pre>
<p><span><span>而不是：</span></span></p>
<pre class="prettyprint">$ docker inspect -f '{{true and true}}' jenkins
FATA[0000] template: :1:2: executing "" at &lt;true&gt;: can't give argument to non-function true </pre>
<p>下面是一些常用的比较函数：</p>
<ul>
<li>eq (等于)</li>
<li>ne (不等于)</li>
<li>lt (小于)</li>
<li>le (小于等于)</li>
<li>gt (大于)</li>
<li>ge (大于等于)</li>
</ul>
<p>我们可以用这些函数来比较字符串、浮点数或整数：</p>
<pre class="prettyprint">$ docker inspect -f '{{eq "abc" "abc"}}' jenkins
true
$ docker inspect -f '{{ge 1 -1}}' jenkins
true
$ docker inspect -f '{{lt 4.5 4.6}}' jenkins
true
$ docker inspect -f '{{ne 4.5 4.5}}' jenkins
false</pre>
<p><span><span>要注意的是操作数类型必须匹配，数字比较时使用浮点数：</span></span></p>
<pre class="prettyprint">$ docker inspect -f '{{eq "4.5" 4.5}}' jenkins
FATA[0000] template: :1:2: executing "" at &lt;eq "4.5" 4.5&gt;: error calling eq: incompatible types for comparison
$ docker inspect -f '{{gt .State.Pid 1}}' jenkins
FATA[0000] template: :1:2: executing "" at &lt;gt .State.Pid 1&gt;: error calling gt: incompatible types for comparison 
$ docker inspect -f '{{gt .State.Pid 1.0}}' jenkins
true</pre>
<p>另外，可以使用&nbsp;<em>json</em>&nbsp;函数来生成 JSON 输出：</p>
<pre class="prettyprint">$ docker inspect -f '{{json .NetworkSettings.Ports}}' jenkins
{"50000/tcp":null,"8080/tcp":[{"HostIp":"0.0.0.0","HostPort":"8080"}]}</pre>
<p>我们也可以使用&nbsp;<a href="https://stedolan.github.io/jq/">jq</a>&nbsp;工具来组合结果：</p>
<pre class="prettyprint">$ docker inspect -f '{{json .State}}' jenkins-data | jq '.StartedAt'
"2015-03-15T20:26:30.526796706Z"</pre>
<p><span><span>当然，<em>docker inspect</em>&nbsp;的默认输出结果就是 JSON，所以下面这样也可以：</span></span></p>
<pre class="prettyprint">$ docker inspect jenkins-data | jq '.[] | .State.StartedAt'
"2015-03-15T20:26:30.526796706Z"</pre>
<p>更多函数请参考 <a href="http://golang.org/pkg/text/template/" target="_blank">Go 官方文档</a>，不过很奇怪的是官方文档中并没有描述 <em>json</em>&nbsp;函数（我是从 <a href="http://nathanleclaire.com/blog/2014/07/12/10-docker-tips-and-tricks-that-will-make-you-sing-a-whale-song-of-joy/">Nathan LeClaire&rsquo;s blog</a>&nbsp;中学到的），你如果知道其中原因，记得告诉我！</p>
<h3>If 语句</h3>
<p>条件语句 <em>if</em>&nbsp;可以和前面的比较函数一起使用：</p>
<pre class="prettyprint">$ docker inspect -f '{{if eq .State.ExitCode 0.0}} 
Normal Exit
{{else if eq .State.ExitCode 1.0}} 
Not a Normal Exit 
{{else}} 
Still Not a Normal Exit 
{{end}}' jenkins

Normal Exit</pre>
<p>注意，<em>{{end}}</em> 语句必须有，<em>else if</em> 和 <em>else</em>&nbsp;按需使用。</p>
<h3>结论</h3>
<p>我想本文应该涵盖了 <em>docker inspect -f</em>&nbsp;使用模版时的大部分内容，不过另外还有一些很常用的特性，比如使用&nbsp;<em>range</em>&nbsp;来迭代数据、自定义函数、使用管道等需要你来自己摸索实践。</p>
<p>我还没找到一份全面的使用 Go 模版的参考文档，目前我觉得这份还不错：<a href="http://jan.newmarch.name/go/template/chapter-template.html">chapter from a the free e-book &ldquo;Network programming with Go&rdquo;</a>&nbsp;by Jan Newmarch。</p>
<p>当然，你可以参考 <a href="http://golang.org/pkg/text/template/" target="_blank">Go&nbsp;官方文档</a>，但是它太精简了，特别是对于非 Go 程序员来说比较难理解。<a href="http://golang.org/pkg/text/template/" target="_blank"></a></p>
<p>&nbsp;</p>
<p>本文译自：<a href="http://container-solutions.com/2015/03/docker-inspect-template-magic" target="_blank">Docker Inspect Template Magic</a></p>