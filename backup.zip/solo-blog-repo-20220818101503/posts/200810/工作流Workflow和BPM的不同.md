title: 工作流(Workflow)和BPM的不同
date: '2008-10-22 01:27:00'
updated: '2008-10-22 01:27:00'
tags: [Workflow &amp; BPM]
permalink: /articles/2008/10/21/1224581220000.html
---
<p><span style="font-weight: bold; font-style: italic;">1、工作流(Workflow)</span><br>
在模拟、定义、执行和分析方面并不是非常关心完整周期的流程管理。没有内置的流程管理概念。<br>
有限的可测量性和可靠性，通常只是为部门级的使用进行设计并只有有限的平台支持。<br>
缺乏整合能力，通常只限于传送图片或者文档附件。<br>
通常只能运行指定的应用系统，无法运行外部的主机应用系统，比如Oracle、SAP等等。<br>
功能着重于提供强大的电子表单功能。<br>
通常在非任务验证和收入结算领域使用。<br>
<span style="font-weight: bold; font-style: italic;">2、BPM</span><br>
业务流程的管理、模拟、执行和分析的独立的软件平台，通常用于P2P、P2A和A2A(STP)任务验证和收入结算流程中。<br>
高可测性、高事务数、大用户量的设计。<br>
很强的集成能力，业务流程能够通过不同应用系统与多个软/硬件平台进行端到端的连接。<br>
提供的主要功能<br>
a.高可视化<br>
b.可管理化<br>
c.灵活性<br>
d.模块化<br>
e.整合性<br>
f.基于规则<br>
g.持续的优化<br>
h.嵌入的<br>
<span style="font-style: italic;">工作流关注于通过预定义指令集组成活动组件的特定应用的序列，包括自动过程(基于软件的)和手动活动(人工工作)。<br>
<br>
</span><span style="font-style: italic;">BPM关注于由一些独立的应用系统组成的业务流程的的模拟、定义、执行、分析和管理。BPM是工作流的超集，最大的不同是使不同的应用活动相互协作提供强大的整合能力。</span><br>
</p>
<p>工作流管理系统用于控制流程从一个人到另一个人，从一个应用到另一个应用，因此，它用于管理工作流的信息。工作流管理不考虑业务流程的优化。BPM真正控制整个流程，确保工作流能够按计划实施。<br>
<br>
ＢＰＭ的解决方案包含很多工具，可以帮助业务人员很容易的创建和记录流程。可以为IT人员提供一个协同环境，来将业务人员创建的业务流程转换为可以执行
的、与数据库、电子表格和业务规则相集成的代码。当业务流程很复杂的时候，一个人是不够的，很多不同的人要一起工作，协同工具是有必要的，它使得业务人员
和IT人员可以进行协作。<br>
<br>
ＢＰＭ可以帮助软件开发人员来集成第三方的应用软件。在企业中有很多不同的应用系统。例如，ERP、PLM、财务软件等。这些系统可以通过ＢＰＭ平台进行
集成。此外ＢＰＭ还用于处理流程执行过程中的意外和特殊情况，发布流程，并对流程进行版本控制。另外有一种工具，可以从正在执行的流程中提取一系列的指
标，生成各种形式的报告，使流程的拥有者能够管理流程的资源，实现流程的优化。<br>
<br>
简而言之，BPM可以提供所有的流程控制功能，并实现与各类应用软件的集成，但工作流管理不能实现这些功能。</p>
<p>BPM/Workflow Both Target Business Enablement<br>
By STEVE WEISSMAN<br>
<br>
Even the most casual observer of today’s enterprise software market is aware that “BPM” and<br>
“workflow” are two of the catchiest phrases now in play. But the way these technologies have<br>
progressed, even the most expert participant currently finds it difficult to clearly delineate<br>
between the two. Last year we wrote that these once-disparate market segments would dramatically<br>
converge until they’d come to occupy a single functional niche (see Enterprise<br>
Interoperability Takes Center Stage), and we were right – to the point where such stalwart<br>
defenders of the workflow faith as Staffware and Ultimus now readily and comfortably speak<br>
BPM as well.</p>
区分Workflow与BPM<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 按照我最初的设想，这篇文章本不应该写Workflow与BPM的区别的，但是世界总是变化这么快。前几天给公司内部的期刊写了篇介绍工作流的文章，之后就有很多同事询问Workflow与BPM的区分问题。于是不得已就写了点这方面自己的看法，现摘录如下：<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <font size="2">对Workflow和BPM，没有严格的概念界限区分。<br>
&nbsp;&nbsp;&nbsp;&nbsp; 首先让我们回顾到上个世纪九十年代，诞生了“Process Reengineering”，可惜那个时候只是一阵风，因为技术跟不上，所以大多都只停留在管理层概念。但是，在九十年代，workflow技术却蓬勃发展，可谓是百家争鸣，蒸蒸日上。<br>
&nbsp;&nbsp;&nbsp;&nbsp; 2000左右，工作流技术应用已经非常成熟，数据集成，应用集成也发展迅速。随之也推动了业务过程管理、整合、统计、优化等方面的应用需求。于是就诞生了“BPM”这个概念。<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;<font color="#0000ff">&nbsp;<strong>如果Workflow是早期人们为了解决“办公自动化”“流程自动化”而诞生的应用技术和解决方案的话；那么BPM则是为了“对全局性的业务分析、整合”，以及“能够基于这些分析提供对上层管理决策的支持”的一种应用技术和解决方案</strong></font>。<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp; 事实上，如何去描述业务过程“Business Process”，一直还是个争论不休的话题，也因此存在几种标准。主要是以WfMC为代表的XPDL，OASIS为代表的BPEL，OMG为代表的BPMN和BPDM。<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp; 虽然描述过程“Process”的标准并不一样，但是在圈定以：<strong>过程定义</strong>、<strong>过程执行</strong>、<strong>过程监控</strong>、<strong>过程分析</strong>、<strong>过程优化</strong>这几个方面为核心的BPM Solution ，这一方面各家几乎都是相同的，只是实现技术不同。<br>
&nbsp;&nbsp;&nbsp;&nbsp; 当然，随着SOA浪潮的到来，BPM基于SOA已经是一种必然趋势。<br><br><br>整理自网络资料。。。。<br></font>