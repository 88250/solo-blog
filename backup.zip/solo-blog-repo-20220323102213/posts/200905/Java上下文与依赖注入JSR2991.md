title: 'Java 上下文与依赖注入（JSR 299）[1] '
date: '2009-05-21 06:40:00'
updated: '2009-05-21 06:40:00'
tags: [JSR-299, J2EE/JavaEE]
permalink: /articles/2009/05/20/1242830400000.html
---
<div id="doc-contents">
<h1><a id="Java_JSR_299_1__46746427292970727" name="Java_JSR_299_1__46746427292970727"></a>Java 上下文与依赖注入（JSR 299）[1]&nbsp;</h1>
转载请保留作者信息： <br />作者：88250 <br />Blog：<a href="http://blog.csdn.net/DL88250">http:/blog.csdn.net/DL88250</a> <br />MSN &amp; Gmail &amp; QQ：DL88250@gmail.com <br /><br />
<h2><em>摘要 </em><br /></h2>
本文从 <a id="il08" title="JSR 299" href="http://jcp.org/en/jsr/detail?id=299">JSR 299</a> 规范入手，整理并翻译了该规范中非常重要的概念，并结合一些短小的例子对 JSR 299 的使用进行了说明。文中略过了如何使用 XML 配置 bean，主要介绍使用标注（annotation）配置。 <br />
<h2>1. <a id="_06934473381654227" name="_06934473381654227"></a>绑定 <br /></h2>
<h3>1.1 <a id="_14665515542566476" name="_14665515542566476"></a>定义新的绑定类型 <br /></h3>
<strong>@BindingType</strong><br />@Retention(RUNTIME)<br />@Target({METHOD, FIELD, PARAMETER, TYPE})<br />public @interface Synchronous {}<br /><br /><strong>@BindingType</strong><br />@Retention(RUNTIME)<br />@Target({METHOD, FIELD, PARAMETER, TYPE})<br />public @interface Asynchronous {}<br /><br />这里定义了两个<em>绑定类型</em>，@Synchronous 与 @Asynchronous，以后就可以使用它们定义 bean 了，这个定义步骤就是<em>绑定</em>。<br /><br />对于类型安全解析算法而言，<em>绑定类型</em>的成员值是非常重要的：<br /><strong>@BindingType</strong><br />@Retention(RUNTIME)<br />@Target({METHOD, FIELD})<br />public @interface PayBy {<br />&nbsp;&nbsp;&nbsp; PaymentMethod value();<br />}<br />
<h3>1.2 <a id="__7158220147342836" name="__7158220147342836"></a>绑定 <br /></h3>
这里使用上述的<em>绑定类型</em>进行两个 beans 的<em>绑定</em>：<br />@Synchronous<br />public class SynchronousPaymentProcessor<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; implements PaymentProcessor {<br />&nbsp;&nbsp;&nbsp; ...<br />}<br /><br />@Asynchronous<br />public class AsynchronousPaymentProcessor<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; implements PaymentProcessor {<br />&nbsp;&nbsp;&nbsp; ...<br />}<br /><br />这两个 bean 都实现了 PaymentProcessor 这个<em> bean 类型</em>，在<em>注入点</em>就可以根据需要进行注入了：<br />@Synchronous PaymentProcessor paymentProcessor;<br />@Asynchronous PaymentProcessor paymentProcessor;<br /><br />一个 bean 可以定义多个<em>绑定类型</em>：<br />@Synchronous @Reliable<br />public class SynchronousReliablePaymentProcessor<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; implements PaymentProcessor {<br />&nbsp;&nbsp;&nbsp; ...<br />}<br />
<h3>1.3 缺省绑定 </h3>
<em>缺省绑定</em>可以使用 @Current：<br />@Current<br />public class Order {}<br />等价于<br />public class Order {}<br /><br />在注入时，<br />public class Order {<br />&nbsp;&nbsp;&nbsp; public Order(@Current OrderProcessor processor) { ... }<br />}<br />等价于<br />public class Order {<br />&nbsp;&nbsp;&nbsp; public Order(OrderProcessor processor) { ... }<br />}<br />
<div style="text-align: left;">
<h2>2. 作用域 </h2>
<h3>2.1 内建的作用域</h3>
<h4>2.1.1 ＠SessionScoped <br /></h4>
该作用域被激活于任意的 servlet.service() 方法，并跨越任意 filter.doFilter() 方法。Session <em>上下文</em>将被所有同一 HTTP servlet session 内的 servlet requests 所共享，在 httpSession.invalidate() 方法调用时销毁。<br />
<h4>2.1.2 @RequestScoped <br /></h4>
<ul>
<li>该作用域被激活于任意的 servlet.service() 方法，并跨越任意 filter.doFilter() 方法。Request <em>上下文</em>将在 servlet request 结束时被销毁，即在 sevlet.service() 方法与所有 filter.doFilter() 方法返回后</li>
<li>该作用域被激活于 Java EE web service 调用，并在该 web service 调用完成时销毁</li>
<li>该作用域被激活于任意的<em>异步的观察者</em>方法通知时，并在该通知结束完成时销毁</li>
<li>该作用域被激活于任意的 EJB 远程方法调用，并跨越任意 EJB 超时方法以及对于任意 EJB 消息驱动 bean 的消息递送。该上下文在远程方法调用完成、超时或消息递送完成时被销毁 </li>
</ul>
<h4>2.1.3 @ApplicationScoped <br /></h4>
<ul>
<li>该作用域被激活于任意的 servlet.service() 方法，并跨越任意 filter.doFilter() 方法</li>
<li>该作用域被激活于 Java EE web service 调用</li>
<li>该作用域被激活于任意的<em>异步的观察者</em>方法通知时</li>
<li>该作用域被激活于任意的 EJB 远程方法调用，并跨越任意 EJB 超时方法以及对于任意 EJB 消息驱动 bean 的消息递送</li>
</ul>
<br />Application <em>上下文</em>在同一应用中的所有 servlets、<em>异步的观察者</em>方法通知、web service 调用、EJB 远程方法调用、EJB 超时方法以及 EJB 消息驱动 bean 的消息递送执行所共享，在应用反部署时被销毁。该作用域可以看作是应用内的静态作用域。<br /><br />
<h4>2.1.4 @ConversationScoped <br /></h4>
后续文章分析 :-)<br /><br />
<h4>2.1.5 @Dependent <br /></h4>
后续文章分析 :-)<br /><br /></div>
作用域类型是可扩展的：<br /><strong>@ScopeType</strong><br />@Inherited<br />@Target({TYPE, METHOD, FIELD})<br />@Retention(RUNTIME)<br />public @interface BusinessProcessScoped {}<br /><br />
<h2>3. 部署类型 <br /></h2>
<h3>3.1 内建的部署类型 <br /></h3>
内建的<em>部署类型</em>：@Standard, @Production<br /><br /><em>部署类型</em>是可扩展的：<br /><strong>@DeploymentType</strong><br />@Target({TYPE, METHOD, FIELD})<br />@Retention(RUNTIME)<br />public @interface Australian {}<br />****<br />@Production<br />public class TaxPolicies {<br />&nbsp;&nbsp; @Produces @Australian<br />&nbsp;&nbsp; public TaxPolicy getAustralianTaxPolicy() { ... }<br />}<br /><br />缺省情况下，如果没有显示指定部署类型标注，bean 中的产生器方法或者字段将继承这个 bean 的部署类型。如果 bean 显示声明了部署类型，那么由构型声明的部署类型将被忽略。<br />
<h2>4. 构型 <br /></h2>
在体系结构设计中，构型是非常重要的一个概念。一个构型定义了一种 bean 角色，允许开发人员对这种 bean 统一地标识出公共的元数据。在 JSR 299 中，构型可以封装下列概念的任意组合：<br />
<ul>
<li>一个缺省部署类型</li>
<li>一个缺省作用域</li>
<li>对 bean 作用域的一个限制（restriction）</li>
<li>对一个 bean 实现或者是对一个类型的扩展的需求</li>
<li>一个拦截器绑定的集合</li>
</ul>
<br />
<h3>4.1 定义新的构型 <br /></h3>
<strong>@Stereotype</strong><br />@RequestScoped<br />@Production<br />@Target(TYPE)<br />@Retention(RUNTIME)<br />public @interface Action {}<br /><br />标注了 @Action 的 bean 都将默认拥有 @RequestScoped 的作用域与 @Production 的部署类型，除非在 bean 上显示标注了其他作用域与部署类型：<br /><br />@Mock @ApplicationScoped @Action<br />public class MockLoginAction extends LoginAction { ... }<br /><br />
<h3>4.2 内建的构型 <br /></h3>
内建的构型有如下三种：<br />@Model<br />@Interceptor<br />@Decorator<br /><br /><br />
<h2>后记 <br /></h2>
<br />JSR 299 规范还处于草稿阶段，从 EDR（Early Draft Review） 发布到现在改变很大：<br /><ol>
<li>规范名从 WebBeans -&gt; Java Contexts and Dependency Inject -&gt; Contexts and Dependency Injection for Java -&gt; 目前最新的<a id="np2x" title="社区草稿" href="http://in.relation.to/Bloggers/NewDraftOfJSR299ForReviewByTheCommunity">社区草稿 </a>Contexts and Dependency Injection for Java EE</li>
<li>从对 Spring Bean &amp; Seam Components 的明确支持 -&gt; 使用 SPIs 方式支持</li>
<li>从对 SE 的支持 -&gt; 没有支持（WebBeans RI 倒是支持）</li>
<li>从提供 XML 配置 -&gt; 不提供 XML 配置</li>
<li>http://in.relation.to/Bloggers/NewDraftOfJSR299ForReviewByTheCommunity</li>
</ol><br />不过，其核心思想：服务端组件状态模型一点没变，对 JSF EJB 的整合没变。当然，目前改规范还不是很稳定，最终草稿可能在下个月发布，拭目以待。<br />
<h2><a id="_2715716551630244" name="_2715716551630244"></a>术语中英对照</h2>
annotation: 标注<br />binding (type): 绑定（类型）<br />scope: 作用域<br />asynchronous: 异步的<br />observer: 观察者<br />context: 上下文<br />deployment (type): 部署（类型）<br />stereotype: 构型<br />producer (method): 产生器（方法）<br />field: 字段<br />injection point: 注入点<br />bean type: bean 类型<br /><br /></div>
<p>
<script>&lt;!--
    viewOnLoad();
    
    
    var urchinPage = "/View";

    
    function getXHR() {
      if (typeof XMLHttpRequest != "undefined") {
        return new XMLHttpRequest();
      }
      try { return new ActiveXObject("Msxml2.XMLHTTP.6.0") } catch(e) {}
      try { return new ActiveXObject("Msxml2.XMLHTTP.3.0") } catch(e) {}
      try { return new ActiveXObject("Msxml2.XMLHTTP") } catch(e) {}
      try { return new ActiveXObject("Microsoft.XMLHTTP") } catch(e) {}
      return null;
    }

    function reportAbuse() {
      var req = getXHR();
      if (req) {
        
          var docid = 'ddrm6c35_1134dpq85h7n';
          var posttoken = '';
        
        req.onreadystatechange = function() {
          try {
            if (req.readyState == 4 &amp;&amp; req.status == 200) {
              var button = document.getElementById("report-abuse-button");
              button.value = 'Thank you!';
              button.disabled = true;
            }
          } catch (ex) {
            
          }
        }
        try {
          req.open('POST', 'MiscCommands', true);
          req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
          req.send('command=report_abuse&amp;abuseDoc=' + encodeURIComponent(docid) +
                   '&amp;POST_TOKEN=' + encodeURIComponent(posttoken));
        } catch (ex) {
          
        }
      }
    }
  --&gt;</script>
</p>