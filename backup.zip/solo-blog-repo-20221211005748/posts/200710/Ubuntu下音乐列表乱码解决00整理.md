title: Ubuntu下音乐列表乱码解决[00整理]
date: '2007-10-22 03:49:00'
updated: '2007-10-22 03:49:00'
tags: [My Linux]
permalink: /articles/2007/10/21/1192967340000.html
---
<p>虽然下载了w32codecs,gstreamer,&nbsp; mp3这些是可以顺利的播放了，但是 Rhythmbox 0.10.0还是在播放列表中显示为乱码，虽然不影响音质，但总归是不爽的。在网上搜索了下，还真有解决办法，甚至还有原因分析，我是懒人，也懒得搞懂这 些，只要解决的办法方便我继续深入的使用ubuntu就可以。<br /><br />方法如下：一种办法就像 Win 上的播放器一样，可以根据本地的编码方式来解码，或使用一些其他转码机制，要不还可以选择优先读取顺序。以上测试的播放器中除了 Audacious 外其他都不支自定义编码读取功能。另外一个解决办法就是把 mp3 标签转换为 Unicode 编码，这种方式既简单又支持标准，推荐大家使用。如果像 Banshee 一样支持显示文件路径也可以解决乱码问题，但这不是根本之道。 </p>
<p>目前发现有 2 个工具可以把标签转换为 Unicode 编码，而且都支持批量转换。</p>
<p>1) 一个是<a href="http://www.cs.berkeley.edu/%7Ezf/">周枫</a>用 java 编写的 <a href="http://www.cs.berkeley.edu/%7Ezf/id3iconv/">ID3iconv 0.2.1</a>，最后更新时间为 2004/2/20。</p>
<p>使用方法：<br /> java -jar ~/id3iconv-0.2.1.jar -e gbk *.mp3</p>
<p>如果想转换当前目录下的所有 mp3 (包括子目录)：<br /> find . -iname &quot;*.mp3&quot; -execdir java -jar ~/id3iconv-0.2.1.jar -e gbk {} ;</p>
<p>* 注意以上 ~/id3iconv-0.2.1.jar 位置根据自己情况而定<br /> * 相信现在大陆绝大多数能找到的 mp3 标签都是以 GBK/GB18030 编码，使用 -e gbk 来处理就够了，当然你也可以使用 -e gb18030 来处理。<br /> * -e gbk 参数是代表把 GBK 编码的标签转换为 Unicode 编码，本身是 Unicode 编码的就不转换。如果需要转换其他编码的文件可以自行修改，如改为 Big5。<br /> * 经测试，转换后为 2.3 版的 ID3v2，编码格式为 uft-16</p>
<p>2) 另外一个是用 Python 写的 &ldquo;<a href="http://www.sacredchao.net/quodlibet/wiki/Development/Mutagen">Mutagen</a>&rdquo;，目前最新版本 1.11，Ubuntu 7.04 源里也带有 1.10 版本的 Mutagen，可以用这个命令来安装：<br /> sudo apt-get install python-mutagen</p>
<p style="text-indent: 2em;">ps:安装 Quod Libet 和 Listen 都必须这个<br><br /></br></p>
使用方法：<br />
<p style="text-indent: 2em;">#转换mp3文件所在的目录下，执行：<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   mid3iconv -e gbk *.mp3   </p>
&nbsp;&nbsp;&nbsp; &nbsp; #转换当前目录下所有mp3文件(包括子目录)执行：<br /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   find . -iname &quot;*.mp3&quot; -execdir mid3iconv -e gbk {} \;
<p>* 相信现在大陆绝大多数能找到的 mp3 标签都是以 GBK/GB18030 编码，使用 -e gbk 来处理就够了，当然你也可以使用 -e gb18030 来处理。<br /> * -e gbk 参数是代表把 GBK 编码的标签转换为 Unicode 编码，本身是 Unicode 编码的就不转换。如果需要转换其他编码的文件可以自行修改，如改为 Big5。<br /> * 经测试，转换后为 2.4 版的 ID3v2，编码格式为 uft-16<br /> * 不过它会同时用 Unicode 编码填满 D3v1, ID3v2, APEv2 标签，但是 ID3v1 又不支持中文的 Unicode 编码，所以转换后的 ID3v1 标签全是问号。所以最好加上 &ndash;remove-v1 参数，转换后删除 ID3v1 标签。<br /> mid3iconv -e gbk --remove-v1 *.mp3</p>
<p>以上解决方法部分是无漏的 转载，我自己的 体会在我存放音乐的目录下运行 mid3iconv -e gbk *.mp3就可以转换该目录下的mp3标签，子目录下文件需再深入目录。</p>
&nbsp;