title: Liva视频Show
date: '2007-07-13 15:44:00'
updated: '2007-07-13 15:44:00'
tags: [LivaPlayer]
permalink: /articles/2007/07/12/1184283840000.html
---
Liva目前是这个样子的，不会让大家失望吧:-)<br />&nbsp;<br /><a href="http://dl2.csdn.net/down4/20070712/12234241119.gz">视频演示下载</a><br />