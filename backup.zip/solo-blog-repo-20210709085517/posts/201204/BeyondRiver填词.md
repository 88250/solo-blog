title: Beyond River 填词
date: '2012-04-13 09:31:21'
updated: '2012-04-13 09:31:21'
tags: [Beyond, Music]
permalink: /beyond-river.html
---
<p>这是家驹没有填词的作品之一，虽然后面也有成歌&nbsp;<a title="千秋思念" href="http://mp3.baidu.com/m?f=ms&amp;rf=idx&amp;tn=baidump3&amp;ct=134217728&amp;lf=&amp;rn=&amp;word=%C7%A7%C7%EF%CB%BC%C4%EE&amp;lm=-1" target="_blank">《千秋思念》</a>（田震）&nbsp;。</p>
<p>尝试自己填词，也算作是第一个音乐作品，与家驹的励志、自由系有点太过偏差，不过也算是半励志，共勉吧。</p>
<p>----</p>
<p>曲：<a href="http://www.tudou.com/programs/view/2PkuVo9Gmmg/">http://www.tudou.com/programs/view/2PkuVo9Gmmg/</a></p>
<p>River！</p>
<p>（Music）</p>
<p>&nbsp;</p>
<p>时日几多太天真，过往之时无奈我，面对明日只想要平淡</p>
<p>但也许是太认真，过于纵于了自我，今天想不清明日多少</p>
<p>&nbsp;</p>
<p>太难面对现实这一切，无法面对纷扰世间里</p>
<p>WoHo</p>
<p>&nbsp;</p>
<p>无法逃避过去，但愿你我共面对，只想你明白，一切将过去</p>
<p>WoHo</p>
<p>但愿这世间里，没有一丝丝逃避，所有的自责，都将风飘去</p>
<p>WoHoWo</p>
<p>&nbsp;</p>
<p><span style="color: #ff6600;">（Music）</span></p>
<p>&nbsp;</p>
<p>是时面对今日我共你，分清真善丑或美故事</p>
<p>WoHoWo</p>
<p>&nbsp;</p>
<p>无法逃避过去，但愿你我共面对，只想你明白，一切将过去</p>
<p>WoHo</p>
<p>但愿这世间里，没有一丝丝逃避，所有的自责，都将风飘去</p>
<p>WoHoWo</p>
<p>&nbsp;</p>
<p>（Music/Mixing 我与你远去）</p>
<p>----</p>
<p>田震：<a title="千秋思念" href="http://mp3.baidu.com/m?f=ms&amp;rf=idx&amp;tn=baidump3&amp;ct=134217728&amp;lf=&amp;rn=&amp;word=%C7%A7%C7%EF%CB%BC%C4%EE&amp;lm=-1" target="_blank">《千秋思念》</a></p>