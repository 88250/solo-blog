title: 定制CAS登录验证
date: '2008-08-27 03:37:00'
updated: '2008-08-27 03:37:00'
tags: [Network Engineering, Open Source, Portal &amp; Portlet, J2EE/JavaEE]
permalink: /articles/2008/08/26/1219750620000.html
---
<title></title>
	<meta name="GENERATOR" content="OpenOffice.org 2.4  (Linux)">
	<style type="text/css">
	<!--
		@page { size: 8.5in 11in; margin: 0.79in }
		P { margin-bottom: 0.08in }
		H2 { margin-bottom: 0.08in }
		H2.western { font-family: "Nimbus Sans L", sans-serif; font-size: 14pt; font-style: italic }
		H2.cjk { font-size: 14pt; font-style: italic }
		H2.ctl { font-size: 14pt; font-style: italic }
		H3 { margin-bottom: 0.08in }
		H3.western { font-family: "Nimbus Sans L", sans-serif }
	-->
	</style>

<p style="margin-top: 0.17in; page-break-after: avoid; font-size: 20pt;" align="center"><font face="DejaVu Sans"><font size="4"><font face="DejaVu Sans"></font></font></font>


	<meta http-equiv="CONTENT-TYPE" content="text/html; charset=utf-8">
	<title></title>
	<meta name="GENERATOR" content="OpenOffice.org 2.4  (Linux)">
	<style type="text/css">
	<!--
		@page { size: 8.5in 11in; margin: 0.79in }
		P { margin-bottom: 0.08in }
	-->
	</style>

</p><p style="margin-top: 0.17in; page-break-after: avoid;" align="center"><font face="DejaVu Sans"><font style="font-size: 20pt;" size="5"><font face="DejaVu Sans">定制</font></font></font><font face="Nimbus Sans L, sans-serif"><font style="font-size: 20pt;" size="5">CAS</font></font><font face="DejaVu Sans"><font style="font-size: 20pt;" size="5"><font face="DejaVu Sans">登录验证</font></font></font></p>

<p><font face="Microsoft YaHei">转载请保留作者信息：</font></p>
<p><font face="DejaVu Sans"><font face="Microsoft YaHei">作者：</font></font><font face="Microsoft YaHei">88250</font></p>
<p><font face="Microsoft YaHei">Blog</font><font face="DejaVu Sans"><font face="Microsoft YaHei">：</font></font><a href="http://blog.csdn.net/DL88250"><font color="#2300dc"><font face="Microsoft YaHei">http:/blog.csdn.net/DL88250</font></font></a></p>
<p><font face="Microsoft YaHei">MSN &amp; Gmail &amp;
QQ</font><font face="DejaVu Sans"><font face="Microsoft YaHei">：</font></font><a href="mailto:DL88250@gmail.com"><font face="Microsoft YaHei">DL88250@gmail.com</font></a></p>
<div id="Table of Contents1" dir="ltr">
	<div id="Table of Contents1_Head" dir="ltr">
		<p style="margin-top: 0.17in; page-break-after: avoid;"><font face="DejaVu Sans"><font style="font-size: 16pt;" size="4"><b>目录</b></font></font></p>
	</div>
	<p style="margin-left: 0.2in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">摘要</font></font><font size="4">	1</font></p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">环境</font></font>	1</p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">新建工程</font></font>	1</p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">添加依赖包</font></font>	2</p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">编写测试用例</font></font>	2</p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">编写实现代码</font></font>	3</p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">工程结构截图</font></font>	5</p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">测试与打包</font></font>	5</p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">启用定制后的登录验证</font></font>	6</p>
	<p style="margin-left: 0.39in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">整合测试</font></font>	7</p>
	<p style="margin-left: 0.2in; margin-bottom: 0in;"><font face="DejaVu Sans"><font size="3">总结</font></font><font size="4">	7</font></p>
</div>
<p><br><br>
</p>
<h2 class="western"><font face="DejaVu Sans">摘要</font></h2>
<p><font face="DejaVu Sans">本文以</font><font face="Microsoft YaHei">Liferay</font><font face="DejaVu Sans">与</font><font face="Microsoft YaHei">CAS</font><font face="DejaVu Sans">整合为例，将</font><font face="Microsoft YaHei">CAS</font><font face="DejaVu Sans">登录验证从输入相同的用户名</font><font face="Microsoft YaHei">/</font><font face="DejaVu Sans">密码定制为以</font><font face="Microsoft YaHei">Liferay</font><font face="DejaVu Sans">的用户身份进行验证。</font></p>
<p><br><br>
</p>
<h3 class="western"><font face="DejaVu Sans">环境</font></h3>
<ul><li><p style="margin-bottom: 0in;">MySQL5.0.5</p>
	</li><li><p style="margin-bottom: 0in;">JRE 1.6.0.7</p>
	</li><li><p style="margin-bottom: 0in;"><font face="Microsoft YaHei">Ubuntu
	8.04</font></p>
	</li><li><p style="margin-bottom: 0in;"><a href="http://downloads.sourceforge.net/lportal/liferay-portal-tomcat-6.0-5.1.1.zip">Liferay
	5.1.1 Bundled with Tomcat 6.0</a></p>
	</li><li><p style="margin-bottom: 0in;"><a href="http://www.ja-sig.org/downloads/cas/cas-server-3.3-release.zip"><font face="Microsoft YaHei">CAS
	Server 3.3.1</font></a></p>
	</li><li><p style="margin-bottom: 0in;"><a href="http://www.ja-sig.org/downloads/cas-clients/cas-client-2.0.11.zip"><font face="Microsoft YaHei">Yale
	CAS Client 2.0.11</font></a></p>
	</li><li><p style="margin-bottom: 0in;"><a href="http://www.netbeans.org/"><font face="Microsoft YaHei">NetBeans
	IDE 6.1</font></a></p>
</li></ul>
<p style="margin-bottom: 0in;"><br>
</p>
<p style="margin-bottom: 0in;"><font face="DejaVu Sans"><i><b>在进行本文示例前，请参考</b></i><a href="http://blog.csdn.net/DL88250/archive/2008/08/20/2802525.aspx"><i><b>这里</b></i></a><i><b>。</b></i></font></p>
<p style="margin-bottom: 0in;"><br>
</p>
<h3 class="western"><a name="DDE_LINK"></a><font face="DejaVu Sans">新建工程</font></h3>
<p><font face="DejaVu Sans">打开</font>NetBeans IDE<font face="DejaVu Sans">，新建</font>Java
Class Library<font face="DejaVu Sans">工程：</font>PortalAuthHandler<font face="DejaVu Sans">。</font></p>
<p><br><br>
</p>
<h3 class="western"><font face="DejaVu Sans">添加依赖包</font></h3>
<p><font face="DejaVu Sans">从</font>CAS<font face="DejaVu Sans">中的</font>lib<font face="DejaVu Sans">下找到如下</font>jar<font face="DejaVu Sans">：</font></p>
<ul><li><p>cas-server-core-3.3.jar</p>
	</li><li><p>inspektr-core-0.7.0.jar</p>
</li></ul>
<p><font face="DejaVu Sans">下载</font>spring-core.jar(2.5.5)<font face="DejaVu Sans">，点<a href="http://sourceforge.net/project/downloading.php?group_id=73357&amp;use_mirror=osdn&amp;filename=spring-framework-2.5.5.zip&amp;94840949">这里</a>。</font></p>
<p><font face="DejaVu Sans">将这三个</font>jar<font face="DejaVu Sans">包添加到工程</font>PortalAuthHandler<font face="DejaVu Sans">下。</font></p>
<p><br><br>
</p>
<h3 class="western"><font face="DejaVu Sans">编写测试用例</font></h3>
<p><font face="DejaVu Sans">在</font>Test Packages<font face="DejaVu Sans">下建立测试用例，代码如下：</font></p>
<p><br><br>
</p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">package
com.jinfonet.developer.portal;</font></font></p>
<p><br><br>
</p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
junit.framework.TestCase;</font></font></p>
<p><a name="DDE_LINK1"></a><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
org.jasig.cas.authentication.handler.PasswordEncoder;</font></font></p>
<p><br><br>
</p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">/**</font></font></p>
<p> <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*</font></font></p>
<p> <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*
@author 88250 &lt;DL88250@gmail.com&gt;</font></font></p>
<p> <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*/</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">public
final class Base64PasswordEncoderTests extends TestCase {</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">private
final PasswordEncoder passwordEncoder = new
Base64PasswordEncoder("SHA1");</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">public
void testHashBase64Encoded() {</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">assertEquals("qUqP5cyxm6YcTAhz05Hph5gvu9M=",
this.passwordEncoder.encode("test"));</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">public
void testNullPassword() {</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">assertEquals(null,
this.passwordEncoder.encode(null));</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">public
void testInvalidEncodingType() {</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">final
PasswordEncoder pe = new Base64PasswordEncoder("invalid
encoding");</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">try
{</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">pe.encode("test");</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">fail("exception
expected.");</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}
catch (final Exception e) {</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">return;</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">这个测试用例有三个测试方法，其中</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">HashBase64Encoded</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">最为重要。因为在</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">Liferay</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">的帐户表</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">User_</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">中的</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">password_</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">字段默认是以</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">SHA1</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">进行加密，然后再以</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">Base64</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">进行编码存放的。而</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">CAS</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">中自带的</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">Password
Encoder</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">只有用加密算法进行加密的步骤，没有</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">Base64</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">编码的步骤，所以我们要写一个带有</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">Base64</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">编码功能的</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">Encoder</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">，且必须是实现
</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2"><font style="font-size: 9pt;" size="2">org.jasig.cas.authentication.handler.PasswordEncoder</font></font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2"><font style="font-size: 9pt;" size="2">接口的。</font></font></font></p>
<p><br><br>
</p>
<h3 class="western"><font face="DejaVu Sans">编写实现代码</font></h3>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">package
com.jinfonet.developer.portal;</font></font></p>
<p><br><br>
</p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
java.io.UnsupportedEncodingException;</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
java.security.MessageDigest;</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
java.security.NoSuchAlgorithmException;</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
org.inspektr.common.ioc.annotation.NotNull;</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
org.jasig.cas.authentication.handler.PasswordEncoder;</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
org.springframework.util.StringUtils;</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">import
sun.misc.BASE64Encoder;</font></font></p>
<p><br><br>
</p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">/**</font></font></p>
<p> <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*</font></font></p>
<p> <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*
@author 88250 &lt;DL88250@gmail.com&gt;</font></font></p>
<p> <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*/</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">public
class Base64PasswordEncoder implements PasswordEncoder {</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">private
static final char[] HEX_DIGITS = {'0', '1', '2', '3', '4', '5',</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">'6',
'7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">};</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">@NotNull</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">private
final String encodingAlgorithm;</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">private
String characterEncoding;</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">public
Base64PasswordEncoder(final String encodingAlgorithm) {</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">this.encodingAlgorithm
= encodingAlgorithm;</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">public
String encode(final String password) {</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">if
(password == null) {</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">return
null;</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">try
{</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">MessageDigest
messageDigest = MessageDigest.getInstance(this.encodingAlgorithm);</font></font></p>
<p><br><br>
</p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">if
(StringUtils.hasText(this.characterEncoding)) {</font></font></p>
<p>               
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">messageDigest.update(password.getBytes(this.characterEncoding));</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}
else {</font></font></p>
<p>                <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">messageDigest.update(password.getBytes());</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p><br><br>
</p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">final
byte[] digest = messageDigest.digest();</font></font></p>
<p><br><br>
</p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">return
getFormattedText(digest);</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}
catch (final NoSuchAlgorithmException e) {</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">throw
new SecurityException(e);</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}
catch (final UnsupportedEncodingException e) {</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">throw
new RuntimeException(e);</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">/**</font></font></p>
<p>     <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*
Takes the raw bytes from the digest and formats them correct.</font></font></p>
<p>     <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*
</font></font>
</p>
<p>     <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*
@param bytes the raw bytes from the digest.</font></font></p>
<p>     <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*
@return the formatted bytes.</font></font></p>
<p>     <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">*/</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">private
String getFormattedText(byte[] bytes) {</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">final
StringBuilder buf = new StringBuilder(bytes.length * 2);</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">sun.misc.BASE64Encoder
e = new BASE64Encoder();</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">final
String buf2 = e.encode(bytes);</font></font></p>
<p><br><br>
</p>
<p><br><br>
</p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">for
(int j = 0; j &lt; bytes.length; j++) {</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">buf.append(HEX_DIGITS[(bytes[j]
&gt;&gt; 4) &amp; 0x0f]);</font></font></p>
<p>            <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">buf.append(HEX_DIGITS[bytes[j]
&amp; 0x0f]);</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">System.out.println("Final:
" + buf2);</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">System.out.println(encodingAlgorithm
+ ": " + buf);</font></font></p>
<p>        
</p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">return
buf2.toString();</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">public
final void setCharacterEncoding(final String characterEncoding) {</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">this.characterEncoding
= characterEncoding;</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">}</font></font></p>
<p><br><br>
</p>
<p><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2"><b>注意：</b>这里，我们使用了</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">Sun</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">的一个受限类：</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">BASE64Encoder</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">。如果你自己有实现，尽量用自己的。</font></font></p>
<p><br><br>
</p>
<h3 class="western"><font face="DejaVu Sans">工程结构截图</font></h3>
<p><font face="DejaVu Sans">工程的完整结构截图如下：</font></p><p><font face="DejaVu Sans"><br></font></p><div align="center"><img alt="" src="http://p.blog.csdn.net/images/p_blog_csdn_net/DL88250/273209/o_PortalAuthHandler.png" align=""><br>

</div><p><br><br>
</p>
<h3 class="western"><font face="DejaVu Sans">测试与打包</font></h3>
<p><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">单元测通过后到工程目录下的</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">dist</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">目录下把</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">Build</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">出的</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">jar</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">中的</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">class</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">文件</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">(with
package)</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">打包到</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">$LIFERAY_HOME/webapps/cas-web/cas-server-core-3.3.jar</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">中。</font></font></p>
<p><br><br>
</p>
<h3 class="western"><font face="DejaVu Sans">启用定制后的登录验证</font></h3>
<p><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">编辑</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">$LIFERAY_HOME/webapps/cas-web/WEB-INF/deployerConfigContext.xml</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">文件，将</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;bean&nbsp;class="org.jasig.cas.authentication.handler.support.SimpleTestUsernamePasswordAuthenticationHandler"&nbsp;/&gt;</font></font></p>
<p><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">替换为</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;bean
class="org.jasig.cas.adaptors.jdbc.QueryDatabaseAuthenticationHandler"&gt;
</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;property
name="sql" value="select password_ from User_ where
</font></font><font color="#ff0000"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">screenName</font></font></font><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">=?"/&gt;
</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;property
name="passwordEncoder" ref="base64PasswordEncoder"/&gt;
</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;property
name="dataSource" ref="dataSource"/&gt;
</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;/bean&gt;</font></font></p>
<p><font face="DejaVu Sans"><b><font style="font-size: 9pt;" size="2">注意：</font></b><font style="font-size: 9pt;" size="2"><span style="">在</span></font></font><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2"><span style="">Liferay</span></font></font><font face="DejaVu Sans"><font style="font-size: 9pt;" size="2"><span style="">中最好使用</span></font></font><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2"><span style="">screenName</span></font></font><font face="DejaVu Sans"><font style="font-size: 9pt;" size="2"><span style="">作为</span></font></font><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2"><span style="">CAS</span></font></font><font face="DejaVu Sans"><font style="font-size: 9pt;" size="2"><span style="">验证的用户名，</span></font></font><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2"><span style="">emailAddress</span></font></font><font face="DejaVu Sans"><font style="font-size: 9pt;" size="2"><span style="">是不能用的，</span></font></font><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2"><span style="">ID</span></font></font><font face="DejaVu Sans"><font style="font-size: 9pt;" size="2"><span style="">方式没经过测试。</span></font></font></p>
<p><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">然后，在紧跟的</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">			&lt;/list&gt;
</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">		&lt;/property&gt;
</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	&lt;/bean&gt;</font></font></p>
<p><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">后加入：</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;bean
id="dataSource"
</font></font></p>
<p>       
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">class="org.springframework.jdbc.datasource.DriverManagerDataSource"&gt;
</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;property
name="driverClassName" value="${db.driver}" /&gt;
</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;property
name="url" value="${db.url}" /&gt;
</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;property
name="username" value="${db.username}" /&gt;
</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;property
name="password" value="${db.password}" /&gt;
</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;/bean&gt;
</font></font></p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">
</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;bean
id="base64PasswordEncoder"
</font></font></p>
<p>       
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">class="com.jinfonet.developer.portal.Base64PasswordEncoder"
autowire="byName"&gt;
</font></font></p>
<p>        <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;constructor-arg
value="SHA1" /&gt;
</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">&lt;/bean&gt;</font></font></p>
<p><br><br>
</p>
<p><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">最后，修改在文件</font></font><font style="font-size: 10pt;" size="2"><font face="Courier 10 Pitch">$LIFERAY_HOME/webapps/cas-web/WEB-INF/cas.properties</font></font><font face="DejaVu Sans"><font style="font-size: 10pt;" size="2">中配置一下数据库连接，如下：</font></font></p>
<p><br><br>
</p>
<p><font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch">#database.hibernate.dialect=org.hibernate.dialect.OracleDialect
</font></font></p>
<p><font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch">database.hibernate.dialect=org.hibernate.dialect.MySQLDialect
</font></font></p>
<p><font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch">#database.hibernate.dialect=org.hibernate.dialect.HSQLDialect</font></font></p>
<p><br><br>
</p>
<p><font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch">db.driver=com.mysql.jdbc.Driver</font></font></p>
<p><font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch">db.url=jdbc:mysql://localhost:3306/lportal?useUnicode=true&amp;amp;characterEncoding=UTF-8&amp;amp;useFastDateParsing=false</font></font></p>
<p><font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch">db.username=lportal</font></font></p>
<p><font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch">db.password=dl88250</font></font></p>
<p><br><br>
</p>
<h3 class="western"><font face="DejaVu Sans">整合测试</font></h3>
<p><font face="DejaVu Sans">启动</font><font face="Courier 10 Pitch">Liferay</font><font face="DejaVu Sans">与</font><font face="Courier 10 Pitch">CAS</font><font face="DejaVu Sans">后，登录</font><font face="Courier 10 Pitch">Liferay(</font><font face="DejaVu Sans">使用非</font><font face="Courier 10 Pitch">Portlet)</font><font face="DejaVu Sans">时将自动跳转到</font><font face="Courier 10 Pitch">CAS</font><font face="DejaVu Sans">验证页面，输入用户名</font><font face="Courier 10 Pitch">(your
screen name)</font><font face="DejaVu Sans">与密码后，如果登录成功，将自动跳转到你在</font><font face="Courier 10 Pitch">Liferay</font><font face="DejaVu Sans">的</font><font face="Courier 10 Pitch">Home</font><font face="DejaVu Sans">里。</font></p>
<p><br><br>
</p>
<h2 class="western"><font face="DejaVu Sans">总结</font></h2>
<p><font face="DejaVu Sans">本文以</font><font face="Courier 10 Pitch">CAS</font><font face="DejaVu Sans">与</font><font face="Courier 10 Pitch">Liferay</font><font face="DejaVu Sans">的整合为例，介绍了定制</font><font face="Courier 10 Pitch">CAS</font><font face="DejaVu Sans">登录验证的整个开发与配置过程，也强调了一些需要注意的地方。使用</font><font face="Courier 10 Pitch">CAS</font><font face="DejaVu Sans">实现</font><font face="Courier 10 Pitch">SSO(Single
Sign On)</font><font face="DejaVu Sans">将在下一次的文章中介绍，将以</font><font face="Courier 10 Pitch">CAS</font><font face="DejaVu Sans">整合</font><font face="Courier 10 Pitch">Liferay+Scarab</font><font face="DejaVu Sans">为例给大家介绍，请大家多多给予关注哦
</font><font face="Courier 10 Pitch">: )</font></p>