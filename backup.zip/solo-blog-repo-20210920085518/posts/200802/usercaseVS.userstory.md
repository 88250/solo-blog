title: user case VS. user story
date: '2008-02-05 07:22:00'
updated: '2008-02-05 07:22:00'
tags: [Agile Develeopment]
permalink: /articles/2008/02/04/1202138520000.html
---
<p dragover="true">纯粹从字面上是不能分辨的,先说说两者的相同点:</p>
<p dragover="true">1)<strong>都是用来捕获需求的</strong></p>
<p dragover="true">2)<strong>都是以用户的视角来看待问题的</strong></p>
<p dragover="true">那么两者的不同点呢? </p>
<p>1)<strong><font color="#f70909">表现形式相差很大</font></strong></p>
<p>User Case是UML中的一项技术,它是有一定的规则和限定的,你至少需要画个图来表示,因此你需要学习一些使用技巧;而User Story只是一句简短的描述,没有啥限制,轻易上手.</p>
<p>2)<strong><font color="#ff0000">粒度不同</font></strong></p>
<p>User Case一般比较大,而且还可能包含一些其它的User Case,凭此来估计工作量是不太准确的;而User Story比较小,一般根据优先级分别放入迭代中来执行,这样根据计算User Story估计工作量就能比较准确.</p>
<p>3)<font color="#ff0000"><strong>交流所需的时间不同</strong></font></p>
<p>因为第一点,用户一般不太可能自己就能画出User Case,需要由需求捕获人员或分析师等来配合,最后这些人布置给开发人员,交流的时间比较多;而User Story只需要由用户提出,然后大家一起讨论,工程师容易充分融入团队并且达成共识,节省时间.</p>
<p>总之,我认为User Case是UML中的一项技术,还是面向开发人员的,与用户始终会相隔一层.而User Story是一项实践,用户直接就能参与,配合XP的其它实践,事半功倍.</p>
&nbsp;