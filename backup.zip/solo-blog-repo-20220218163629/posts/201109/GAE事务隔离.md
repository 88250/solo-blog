title: GAE 事务隔离
date: '2011-09-04 06:22:15'
updated: '2011-09-04 06:22:15'
tags: [CAP, Database, GAE]
permalink: /transaction_isolation.html
---
<h2>一致性</h2>
<p>GAE 上的事务隔离是快照隔离。在事务开启后，可以把事务中操作的实体组看作是该实体组在数据存储中的一个带有版本的快照。</p>
<p>事务中的所有操作都将只针该快照进行，并且事务中的查询操作只能获取到事务开启时快照中的实体。这一点前面<a href="http://88250.b3log.org/gae-transaction.html">已经提到</a>过 ;-)</p>
<p>快照隔离的最终目的就是乐观并发控制，保证一致性。</p>
<h2>可用性</h2>
<p>GAE 一直在限制事务内只能操作同一个实体组是有原因的。同一实体组将被存储在同一 Google 分布式存储单元中，如果事务中</p>
<p>同时操作多个实体组，失败的可能性会增加很多。所以为了保证可用性，才做出了这个限制。</p>
<p>不过这个限制即将为可选的，SDK 1.5.3 里面已经加入了<a href="http://code.google.com/appengine/docs/java/javadoc/com/google/appengine/api/datastore/TransactionOptions.html" target="_blank">事务配置</a>，可以让事务操作多个实体组。不过目前经测试，1.5.3 里面还不可用。</p>
<h3>参考</h3>
<ul>
<li><a href="http://code.google.com/appengine/docs/java/datastore/transactions.html" target="_blank">Google App Engine Transactions</a></li>
<li><a href="http://code.google.com/appengine/articles/transaction_isolation.html" target="_blank">Transaction Isolation in App Engine</a></li>
</ul>