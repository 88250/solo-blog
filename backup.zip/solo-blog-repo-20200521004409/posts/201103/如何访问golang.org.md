title: 如何访问 golang.org
date: '2011-03-09 21:36:47'
updated: '2014-08-11 17:13:25'
tags: [golang, Google, GAE, GFW]
permalink: /how-to-visit-the-go-programming-language.html
---
<p><img src="http://golang.org/doc/logo.png" alt="" width="464" height="55" /></p>
<p>在学习 Go 语音的童鞋可能会发现其官方网站 <a href="http://golang.org/" target="_blank">http://golang.org</a> 不能直接访问。</p>
<p>Go 官网使用了 64.233.183.141 这个 IP，该 IP 已被和谐。因为这个 IP 同时是 GAE 应用 IP....</p>
<p>所以，修改 hosts 访问 Go 官网吧：</p>
<blockquote>
<p>203.208.39.104 golang.org</p>
</blockquote>
<p>&nbsp;</p>
<p>P.S. 当然，GAE 应用也可以使用这个 IP，例如 GAE/Java B3log 社区：</p>
<blockquote>
<p>203.208.39.104 b3log-symphony.appspot.com</p>
</blockquote>