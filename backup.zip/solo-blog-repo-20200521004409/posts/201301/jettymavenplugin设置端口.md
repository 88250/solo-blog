title: jetty-maven-plugin 设置端口
date: '2013-01-31 01:05:33'
updated: '2013-02-01 19:10:26'
tags: [Maven, Jetty]
permalink: /jetty-maven-plugin-port
---
<p>jetty-maven-plugin&nbsp;有两种方式设置服务端口（默认：8080）：</p>
<ol>
<li>通过命令行，在启动jetty的时候设置：mvn jetty:run -Djetty.port=10001</li>
<li>在 pom 中的 jetty-maven-plugin 中进行设置：</li>
</ol>
<pre class="brush: xml">            &lt;plugin&gt;
                &lt;groupId&gt;org.mortbay.jetty&lt;/groupId&gt;
                &lt;artifactId&gt;maven-jetty-plugin&lt;/artifactId&gt;
                &lt;version&gt;6.1.22&lt;/version&gt;
                &lt;configuration&gt;
                    &lt;connectors&gt;
                        &lt;connector implementation="org.mortbay.jetty.nio.SelectChannelConnector"&gt;
                            &lt;port&gt;10001&lt;/port&gt;
                        &lt;/connector&gt;
                    &lt;/connectors&gt;  
                    
                    &lt;stopKey&gt;stop1&lt;/stopKey&gt;
                    &lt;stopPort&gt;5599&lt;/stopPort&gt;
                    &lt;webAppConfig&gt;
                        &lt;contextPath&gt;/test1_srv&lt;/contextPath&gt;
                    &lt;/webAppConfig&gt;
                    &lt;scanIntervalSeconds&gt;5&lt;/scanIntervalSeconds&gt;
                &lt;/configuration&gt;
            &lt;/plugin&gt;</pre>