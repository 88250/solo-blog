title: Don't say goodbye
date: '2008-04-30 12:28:00'
updated: '2008-04-30 12:28:00'
tags: [Music, Life in Programming]
permalink: /articles/2008/04/29/1209500880000.html
---
<br>柯有伦- don't say goodbye<br><br>看着你哭的时候特别奇怪<br>想给的安慰总是说不出来<br>为何这爱总是拼凑不起来<br>现在的你为何笑的那么愉快<br><br>因为你我可以永远在这等待<br>因为你我不会再悲哀<br><br>don't say goodbye 我还不想离开<br>don't say goodbye 能不能从头再来<br>don't say goodbye 这一切开始的太快<br>让我静静一个在这发呆<br><br>don't say goodbye 我还不想离开<br>don't say goodbye 能不能从头再来<br>don't say goodbye 请不要忘记我的爱<br>让我静静一个在这发呆不想离开<br><br>看着你哭的时候特别奇怪<br>想给的安慰总是说不出来<br>为何这爱总是拼凑不起来<br>现在的你为何笑的那么愉快<br><br>因为你我可以永远在这等待<br>因为你我不会再悲哀<br>say goodbye say goobye<br><br>don't say goodbye 我还不想离开<br>don't say goodbye 能不能从头再来<br>don't say goodbye 这一切开始的太快<br>让我静静一个在这发呆<br><br>don't say goodbye 我还不想离开<br>don't say goodbye 能不能从头再来<br>don't say goodbye 请不要忘记我的爱<br>让我静静一个在这发呆不想离开