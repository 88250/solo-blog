title: 基于 Pushlets 的消息推送设计
date: '2012-05-16 21:28:53'
updated: '2012-05-16 21:45:37'
tags: [Pushlets, HTML5, WebSocket]
permalink: /server-push-based-on-pushlets
---
<h1>基于 Pushlets 的消息推送设计</h1>
<p>Pushlets 是通过长连接方式实现&ldquo;推&rdquo;消息的。推送模式分为：Poll（轮询）、Pull（拉）。本文围绕 Pull 模式进行设计。</p>
<h2>原理</h2>
<p>客户端发起请求，服务端接收到请求后根据 <a href="http://pushlets.com/doc/protocol.html" title="Pushlets 协议" target="_blank">Pushlets 协议</a>进行处理。推数据通过 HTTP 响应返回。</p>
<p>客户端在接收到响应后根据 Pushlets 协议进行处理，重新发起请求。Pull 模式时序：</p>
<p><img title="Pushlets Pull" src="https://public.sn2.livefilestore.com/y1ptpxVei6mgGxLAv79zOuIx46cVw3jQx5EgPX1MirgoMA5wt7KFkIyA20YE2GuLTBXy_IQi1CjBSkYs4GnJU5JKA/pushlets_pull.png?psid=1" alt="Pushlets Pull" width="288" height="510" /></p>
<ol>
<li>join：join 请求，服务器端建立 Pushlet 会话</li>
<li>join-ack：join 应答，返回会话 id</li>
<li>listen：订阅并监听主题</li>
<li>listen-ack：监听应答，返回会话 id，订阅 id</li>
<li>subscribe（可选）：订阅主题</li>
<li>subscribe-ack（可选）：订阅主题应答，返回会话 id，订阅</li>
<li>refresh：长连接请求，实参会话 id</li>
<li>refresh-ack：长连接响应，包括下一次 refresh 请求间隔<br />hb：心跳响应<br />data：推数据</li>
<li>leave：清空订阅</li>
<li>leave-ack：清空订阅应答</li>
</ol>
<h2>服务器端</h2>
<p>服务器端主要负责维护会话，根据请求处理应答。使用内存队列维护每个会话的主题事件。</p>
<p>事件产生后通过分发器（Dispatcher）将事件发布到指定订阅者的事件队列里。Pull 模式使用阻塞队列，读超时（没有事件）后返回 hb 与 refresh 指令的应答。</p>
<h3>事件发布</h3>
<ul>
<li>广播：将事件发布给所有订阅者</li>
<li>多播：将事件发布给匹配的订阅者</li>
<li>单播：将事件发给某个订阅者</li>
</ul>
<h3>关键参数</h3>
<p>订阅者的事件队列配置：</p>
<ul>
<li>queue.size=24<br />队列大小为 24。如果队列满了新发布到该队列的事件将被丢弃。</li>
<li>queue.read.timeout.millis=20000<br />队列读超时 20 秒。读超时后返回 hb 与 refresh 指令的应答。该项配置即请求线程最长 hold 时间。</li>
<li>queue.write.timeout.millis=20<br />队列写超时 20 毫秒。如果队列是满的，等待 20 毫秒后如果还满，则销毁该订阅者。</li>
</ul>
<p>刷新时长配置：</p>
<ul>
<li>pull.refresh.timeout.millis=45000<br />服务器端刷新超时 45 秒。如果服务器端某订阅者超过 45 秒没有收到客户端的 listen 或 refresh 请求，则销毁该订阅者。该超时判断发生在发布事件时。</li>
<li>pull.refresh.wait.min.millis=2000<br />pull.refresh.wait.max.millis=6000<br />refresh 指令中指定客户端下次请求的等待时间区间，值取该区间内的随机值。</li>
</ul>
<h2>客户端</h2>
<p>Pushlets 支持多种客户端，例如浏览器客户端、Java 客户端。浏览器客户端又分为 iframe 和 AJAX 两种。</p>
<p>初始化客户端后，客户端发起监听、订阅请求，并根据服务器返回指令发送 refresh 请求。当有 data 应答时，回调客户端 onData(event) 函数实现消息处理。</p>
<h2>技术设计</h2>
<p>对 Pushlets 做接口封装以屏蔽其特性细节，也便于以后兼容其他服务器消息推送技术（例如 WebSocket）做好铺垫。</p>
<p>封装的服务器推机制定义为 Channel 服务，提供服务器到浏览器客户端的消息推送。</p>
<h3>服务器端</h3>
<p>通过 Channel API 在 JS 客户端与服务器端建立长连接，使服务器端可以实时地发送消息给客户端。</p>
<p><img title="Channel 类图" src="https://public.sn2.livefilestore.com/y1pZFZKlLqBHhM8SWRJGY6-1KDloobUVsp6EexI5XRDH-gXpPK4JiWHJHfOgyiHbbnQwiy2nBNg2DAPt-EgZqZUvg/channel_class.png?psid=1" alt="Channel 类图" width="494" height="415" /></p>
<h3>JS 客户端</h3>
<p>oaweb.Channel() 类：</p>
<ul>
<li>init()<br />初始化服务器调用 URL、客户端状态。</li>
<li>open()<br />发送 join 请求，服务端创建会话。</li>
<li>subscribe(listeners : {topic,&nbsp;onmessage,&nbsp;onerror})<br />发送 subscribe 请求，服务端创建订阅者，添加订阅主题。</li>
<li>unsubscribe(topic)<br />发送 unsubscribe 请求，服务端移除订阅。</li>
<li>close()<br />发送 leave 请求，服务端销毁会话。</li>
</ul>
<h3>时序</h3>
<p><img title="Channel 时序图" src="https://public.sn2.livefilestore.com/y1p5e65HlecGSpWAaqLF01v27kXVa5l_mk8E38aZszmxjzn2hs5OvpVtK_SNgW82eZJVwjjmrcAbtHkrjZYMaCTjw/channel_seq.png?psid=1" alt="Channel 时序图" width="676" height="415" /></p>
<h3>集群</h3>
<p>均衡器通过源地址保持策略保证同一 IP 的请求均会分发到固定服务节点。</p>
<p>当服务节点进行业务逻辑处理后，发送消息到消息服务系统；</p>
<p>服务节点订阅消息主题，当监听到新消息时调用 Channel 服务发布消息到具体的推送实现组件（Pushlets）。</p>
<p><img title="Channel 集群" src="https://public.sn2.livefilestore.com/y1pFcfOSzdHxwV99UxthxH2wTXgwS8-GkQttbtzHJS1PO7cD-FCoRMvrkjnwzz9QAzAFy0apLGuGJaMRzFq7_1ZXQ/channel_cluster.png?psid=1" alt="Channel 集群" width="580" height="274" /></p>
<h2>参考</h2>
<ul>
<li><a href="http://88250.b3log.org/web-message-push" title="消息推送技术" target="_blank">消息推送技术</a></li>
<li><a href="https://developers.google.com/appengine/docs/java/channel/" title="GAE Channel Service" target="_blank">Google App Engine Channel API</a></li>
<li><a href="http://www.w3.org/TR/websockets/" title="WebSocket API" target="_blank">HTML5 WebSocket API</a></li>
</ul>