title: NetBeans中文社区文档/教程翻译项目
date: '2008-02-01 16:06:00'
updated: '2008-02-01 16:06:00'
tags: [NetBeans, Life in Programming]
permalink: /articles/2008/02/01/1201824360000.html
---
前几天参与了NetBeans中文社区，恰好碰上社区在组织NetBeans6的文档/教程翻译项目。<br />报名参加了，翻译了一篇 <a href="http://www.netbeans.org/kb/60/web/quickstart-webapps_zh_CN.html">Web 应用开发简介</a> <br />欢迎大家去指正。<br />学习开源思想一年多了，总算为开源事业做了一点小小的贡献:-)，要翻译的文档/教程还有很多，希望大家积极参与。只要有时间，我还要继续翻译，帮助他人，也提升了自己。<br /><br />项目详情，以及如何加入，请访问， <a target="_blank" href="http://zh-cn.netbeans.org/community/">http://zh-cn.netbeans.org<wbr></wbr>/community/</a>