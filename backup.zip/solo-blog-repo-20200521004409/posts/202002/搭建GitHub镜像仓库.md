title: 搭建 GitHub 镜像仓库
date: '2020-02-07 00:01:02'
updated: '2020-02-07 10:55:01'
tags: [GitHub, Git, 同步, 镜像]
permalink: /articles/2020/02/07/1581004860744.html
---
### 需求背景

国内访问 GitHub 仓库实在太慢，项目主要提交者也就我和 V，外加以后打算自己建立仓库，所以决定在新项目上试试。

将 GitHub 仓库作为镜像仓库，主库设在自建的服务器上。这样既能获得 GitHub 协作特性（Issues、PR、Actions、Release 等），开发时又能享受高速提交和拉取。

### 服务端

1. 创建 Git 用户，配置 git-shell 等，然后配置 SSH 密钥，密钥分为两类：

   * 客户端提交服务端用，修改 ~/.ssh/authorized_keys
   * 服务端自动推送 GitHub，修改 ~/.ssh/id_rsa.pub。GitHub 上需要配置账号 SSH 或者仓库 Deploy Keys
2. 切换到 Git 用户，并在 ~ 下创建仓库

   ```shell
   mkdir sample.git && cd sample.git && git clone --bare git@github.com:youraccount/sample.git
   ```
3. 在 hooks 目录下创建名为 `post-receive` 的脚本：

   ```shell
   #!/bin/sh

   git push --mirror git@github.com:youraccount/sample.git >/dev/null 2>&1 &
   ```

   设置脚本执行权限：

   ```shell
   chmod +x post-receive
   ```

### 客户端

克隆服务器上的仓库或者将现有仓库的远程地址改为服务端仓库：

```shell
git remote set-url origin git@yourserver:sample.git
```

这样以后推送本地仓库就会推送到服务端仓库，然后服务端仓库触发 post-receive 钩子，覆盖 GitHub 上的镜像仓库。

### 注意事项

* `git push --mirror` 是个“危险”的操作，它会完全覆盖 GitHub 上的远程仓库，包括分支、标签，所以推送前一定要确认清楚。可以在 GitHub 上建立一个测试仓库来先测试一下，一切正常的话再改成最终的镜像仓库
* 上面的 `post-receive` 脚本通过后台执行 push 实现“异步”推送镜像仓库，并且输出都被忽略了，所以无论是否成功脚本都不会返回报错。建议在测试阶段改成同步执行，这样客户端可以看到输出结果。后期改成后台执行以后，也许会因为某些原因（比如网络问题）导致推送失败，可以考虑加个系统定时任务周期执行
* GitHub 镜像仓库如果有 PR 合并，需要单独处理
