title: 还是，Stairway To Haven
date: '2009-01-23 19:02:00'
updated: '2009-01-23 19:02:00'
tags: [Music, Life in Programming]
permalink: /articles/2009/01/23/1232679720000.html
---
<p><br />
<br />
There\'s a lady who\'s sure <br />
All that glitters is gold <br />
And she\'s buying a stairway to heaven. <br />
When she gets there she knows <br />
If the stores are all closed <br />
With a word she can get what she came for. <br />
Ooh, ooh, and she\'s buying a stairway to heaven. <br />
<br />
There\'s a sign on the wall <br />
But she wants to be sure <br />
\'Cause you know sometimes words have two meanings. <br />
In a tree by the brook <br />
There\'s a songbird who sings, <br />
Sometimes all of our thoughts are misgiven. <br />
Ooh, it makes me wonder, <br />
Ooh, it makes me wonder. <br />
<br />
There\'s a feeling I get <br />
When I look to the west, <br />
And my spirit is crying for leaving. <br />
In my thoughts I have seen <br />
Rings of smoke through the trees, <br />
And the voices of those who stand looking. <br />
Ooh, it makes me wonder, <br />
Ooh, it really makes me wonder. <br />
<br />
And it\'s whispered that soon <br />
If we all call the tune <br />
Then the piper will lead us to reason. <br />
And a new day will dawn <br />
For those who stand long <br />
And the forests will echo with laughter. <br />
<br />
If there\'s a bustle in your hedgerow <br />
Don\'t be alarmed now, <br />
It\'s just a spring clean for the May queen. <br />
Yes, there are two paths you can go by <br />
But in the long run <br />
There\'s still time to change the road you\'re on. <br />
And it makes me wonder. <br />
<br />
Your head is humming and it won\'t go <br />
In case you don\'t know, <br />
The piper\'s calling you to join him, <br />
Dear lady, can you hear the wind blow, <br />
And did you know <br />
Your stairway lies on the whispering wind. <br />
<br />
And as we wind on down the road <br />
Our shadows taller than our soul. <br />
There walks a lady we all know <br />
Who shines white light and wants to show <br />
How ev\'rything still turns to gold. <br />
And if you listen very hard <br />
The tune will come to you at last. <br />
When all are one and one is all <br />
To be a rock and not to roll. <br />
<br />
And she\'s buying a stairway to heaven. <br />
<br />
绿豆译本：天梯（虽然歌词本来是不可译的） <br />
绿豆 发表于：2002.03.23 03:25修改于：2002.03.23 12:38 <br />
<br />
<br />
天梯 <br />
<br />
（纪念陈文丽女士，1971，4-1989，6，1） <br />
<br />
有一位女士她确信闪光的都是金子 <br />
于是她开始购买一架去天堂的梯子。 <br />
她知道当她到达那里，即使所有商店都关门大吉 <br />
只需要一个字眼她就能获得自己的所需。 <br />
噢，噢，于是她开始购买一架去天堂的梯子。 <br />
<br />
墙上分明有告示但她却想打听确实 <br />
因为你知道，有时候词语有双关的意思。 <br />
在溪边的某棵树上，有只鸟儿正在鸣唱， <br />
有时我们所有的想法都值得重新思量 <br />
噢，这使我迷惑， <br />
噢，这使我迷惑。 <br />
<br />
当我眺望西方我找到一种感觉， <br />
我的心灵哭喊着想要离去。 <br />
我已看到了烟圈，从我思想的树林里冒起， <br />
伴随着那些眺望者发出的呼喊。 <br />
噢，这使我迷惑， <br />
噢，这真的使我迷惑。 <br />
<br />
如果我们也有掌调的机会，消息就会被迅速地悄声传开 <br />
于是风笛手将引导我们走向理性。 <br />
新的一天会为那些长久等待的人们来临 <br />
森林也答以带笑的回音。 <br />
<br />
如果你的灌木篱笆中一片吵嚷，现在已不必惊慌， <br />
那只是一次为五月皇后而做的春季扫除。 <br />
是的，有两条路你可以选择，但在长途奔跑中 <br />
你仍会有更换道路的时间。 <br />
这就使我迷惑 <br />
<br />
你脑袋嗡嗡作响它不想继续，因为你也方向不明， <br />
风笛手正在呼唤着你的入伙， <br />
亲爱的女士，你能听到起风的声音么，你是否知道 <br />
你的梯子正在沙沙响起的风中躺着。 <br />
<br />
当我们沿着道路循味而来 <br />
我们的影子比灵魂更高。 <br />
那儿有一位女士我们都熟知 <br />
她身披白光是为了要向我们展示 <br />
万事万物该怎样仍旧变成金子。 <br />
如果你竭力去听 <br />
那个曲调最终会为你而降临。 <br />
当万物为一，一为万物 <br />
去变成一块石头但不要滚动 <br />
<br />
于是她开始购买一架去天堂的梯子。 <br />
<br />
乐队介绍[转] <br />
<br />
从上个世纪六十年代走来的重金属音乐，时至今日，已经以它的"狂噪&rdquo;吸引了无数疯狂的歌迷，在音乐的圣殿里，他似乎不仅仅给人听觉上的震撼，他其实是一部
机器，一部轻易能够摧残建筑的机器，然而断壁残垣，满目沧痍并不是他们的目的，他们更擅长是在废墟上树立一种超脱的精神。 <br />
<br />
第一支金属乐队当属Led Zeppelin，尽管乐队在多年之后，曾经加入过一些民间音乐的成功，不管他们承认与否，它仍是世界公认的重金属先躯及代言人。 <br />
<br />
吉他手Jimmy Page、歌手Robert Plant、贝斯手兼键盘手John Paul Jones以及鼓手John
Bonban在乐队组成之前就是非常好的乐手及歌手了。乐队的前身为"庭院鸟乐队&rdquo;，1968年10月正式更名为"Led
Zeppelin&rdquo;，乐队于1969年发行的专辑《LED ZEPPELIN
II》被誉为重金属摇滚乐的奠基之作。这张精练了众多摇滚风格，创作狂噪扎人的唱片，定义了重金属是如此一种风格。同年11月，此专辑高居全美排行榜首
138周之久，从而奠定了世界最伟大的摇滚乐队之一的位置。 <br />
<br />
1970年10月，《LED ZEPPELIN III》专辑发行，仍然反响极好，高居英美排行榜首。同时，乐队的巡回演出，更是为乐队赢得了数以百万记的歌迷。 <br />
<br />
1971年《LED ZEPPELIN
IV》专辑推出，其中一首《天堂的阶梯》倍受青睐。静溢清晰的民谣箱琴渐入主唱忧郁的倾诉，即而，在飞速宣泄的吉他Solo声中，爆裂的金属乐淹没了整个
乐曲，使人们的听觉和感觉在短短的几分钟内有了一个极大的反差。这首重金属的传世之作，在此后的许多年中，一直被视为金属迷的钟爱。 <br />
<br />
此后，Led Zeppelin过了几年安稳的生活，收入颇丰；《圣殿》、《烙印》、《礼物》专辑的发行仍然高居榜首。1976年，乐队的音乐电影《歌声依旧》使他们更加光彩夺目，同时被载入"曼迪逊广场花园演出乐队史册&rdquo;。 <br />
<br />
1980年，乐队在西柏林举行了最后一场演出，同年9月，Bonban因酒精中毒死于自己房间内。12月，Led Zeppelin乐队宣布解散。 <br />
<br />
他们是摇滚乐的国歌```````` Stairway to heaven（天堂之梯） <br />
<br />
P.S.:Led Zeppelin摇滚界鼻祖级的乐队.Stairway to heaven,走过它,得到什么,又失去什么,我们在追求什么?也许注定在洗尽铅华的时候,才真正地明了。</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>
<object width="400" height="340">
<param name="movie" value="http://www.tudou.com/v/GGaMkABzd2k" />
<param name="allowScriptAccess" value="always" />
<param name="wmode" value="transparent" /><embed type="application/x-shockwave-flash" width="400" height="340" src="http://www.tudou.com/v/GGaMkABzd2k" allowfullscreen="true" wmode="transparent" allowscriptaccess="always"></embed>
</object>
</p>
<p>转自：http://hi.baidu.com/guangyu88931/blog/item/6e150c2ede1030514fc2268a.html</p>