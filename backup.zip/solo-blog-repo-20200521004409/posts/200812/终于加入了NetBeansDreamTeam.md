title: 终于加入了 NetBeans Dream Team！
date: '2008-12-17 04:11:00'
updated: '2008-12-17 04:11:00'
tags: [NetBeans, Life in Programming]
permalink: /articles/2008/12/16/1229429460000.html
---
从提交加入请求到现在差不多半年了，终于通过了审核，好高兴：-)<br><br>NetBeans Dream Team(NetBeans 梦之队) 是一个社区驱动的团队，成员主要是 NetBeans 的资深用户与贡献者。团队成员主要参与 NetBeans 开发讨论，提供新的、有趣的信息以提高 NetBeans 的影响。<br><br>团队Wiki：<a href="http://wiki.netbeans.org/NetBeansDreamTeam">http://wiki.netbeans.org/NetBeansDreamTeam</a><br><img alt="" src="http://album.hi.csdn.net/app_uploads/DL88250/20081216/121428078.p.jpg?d=20081216121505484" align=""><br>