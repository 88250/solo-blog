title: MySQL 迁移 utf8 到 utf8mb4
date: '2018-03-15 22:09:01'
updated: '2018-03-16 07:35:42'
tags: [MySQL, 字符集, UTF8, Emoji]
permalink: /articles/2018/03/15/1521094110639.html
---
## MySQL 版本和驱动

* MySQL 至少是 5.5.3+
* mysql-connector-java 至少是 5.1.13，修改连接串参数 `characterEncoding=UTF-8`

## 历史数据迁移

生成表字符迁移 SQL：

```sql
SELECT
	CONCAT(
		'ALTER TABLE `',
		TABLE_NAME,
		'` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;'
	) AS mySQL
FROM
	INFORMATION_SCHEMA. TABLES
WHERE
	TABLE_SCHEMA = 'your_schema'
```	

生成后执行一把，这样表和列的字符集就改完了。我这里通过修改表的字符集就自动修改列的了，最好自己确认下列是否已经改对。

修改库字符集：

```sql
ALTER DATABASE `your_schema` CHARACTER
SET = utf8mb4 COLLATE = utf8mb4_general_ci;
```

上面示例代码中的 `COLLATE`（排序规则）请按需修改。

## 关于连接串参数 characterEncoding

有的时候可能会觉得是写错了，应该用 `characterEncoding=utf8`。其实 `UTF-8` 是允许客户端发送多种字符集（三字节 utf8 /四字节 utf8mb4）的配置。

如果要使用 utf8mb4 有两种方案：

1. 在连接串中指定 `characterEncoding=UTF-8`，MySQL 服务端不用做任何修改
2. 修改 MySQL 服务端配置后重启，连接串中移除 `characterEncoding=utf8`
```ini
[mysql]
default-character-set = utf8mb4
[mysqld]
character-set-server = utf8mb4
collation-server = utf8mb4_general_ci
```

具体细节请参考[这里](https://dev.mysql.com/doc/connector-j/5.1/en/connector-j-reference-charsets.html)和[这里](https://stackoverflow.com/a/35156926/1043233)。
