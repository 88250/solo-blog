title: 初探 HTML 5 之 WebSocket
date: '2010-01-09 17:24:00'
updated: '2010-01-09 17:24:00'
tags: [Network Engineering, DHTML]
permalink: /articles/2010/01/09/1263000240000.html
---
<p><br />
<img style="width: 88px; height: 114px; float: left; margin-left: 1em; margin-right: 0pt;" src="http://docs.google.com/File?id=ddrm6c35_1197cdn5jrft_b" alt="" />
&nbsp;&nbsp;&nbsp;&nbsp; <a id="ngk4" title="HTML 5" href="http://www.w3.org/TR/html5/" title="HTML 5">HTML 5</a>
 中的 <a id="lsvc" title="WebSockets" href="http://dev.w3.org/html5/websockets/" title="WebSockets">WebSockets</a>
 不是太招人注意（至少不像本地存贮、画图板、JavaScript 线程与多媒体播放那样被炒得沸沸扬扬）。<a href="http://dev.w3.org/html5/websockets/">WebSocket API</a>
 所带来的优势不能马上就呈现在最终用户眼前。事实上，在过去差不多 10 年的时间里，已经发明了很多技术来解决浏览器与服务器间的异步双向通信（双工）问题：AJAX、<a href="http://www.igvita.com/2009/10/21/nginx-comet-low-latency-server-push/">Comet &amp; HTTP Streaming</a>
，BOSH，<br />
<a href="http://www.igvita.com/2009/08/18/smart-clients-reversehttp-websockets/">ReverseHTTP</a>
，<a href="http://www.igvita.com/2009/06/29/http-pubsub-webhooks-pubsubhubbub/">WebHooks &amp; PubSubHubbub</a>
 ，以及 Flash sockets 等等&hellip;&hellip; 但是，已有的这些技术都是在弥补过去的 Web 浏览器的先天缺陷：不是为双向通信而设计。HTML 5 中 WebSockets 的出现将从根本上支持全双工通信<strong>。WebSockets 是为浏览器设计的 TCP。</strong>
<br />
&nbsp;&nbsp;&nbsp;&nbsp; 按照 HTML 5 规范主要制定者 Ian Hickson（Google）的计划，HTML 5 估计要到 2012 年才能基本定稿，2022 年才能得到广泛支持。虽然如此，作为技术狂热者的你<a id="xp05" title="准备" href="http://ishtml5readyyet.com/" title="准备">准备</a>
好了吗？<br />
&nbsp;&nbsp;&nbsp;&nbsp; <br />
示例：<a id="t5j3" title="HTML 5 WebSocket 示例" href="http://blog.csdn.net/DL88250/archive/2010/01/01/5118301.aspx" title="HTML 5 WebSocket 示例">HTML 5 WebSocket 示例</a>
<br />
参考：<a id="tlcz" title="Ruby &amp; WebSockets: TCP for the Browser" href="http://www.igvita.com/2009/12/22/ruby-websockets-tcp-for-the-browser/" title="Ruby &amp; WebSockets: TCP for the Browser">Ruby &amp; WebSockets: TCP for the Browser</a>
</p>