title: 准备转向 VPS
date: '2013-12-31 18:55:46'
updated: '2013-12-31 18:55:46'
tags: [VPS, BAE]
permalink: /articles/2013/12/31/1388458545375.html
---
BAE 终于要求备案后才能绑定域名了，早想到会有这么一天的，但没想到的是这一天来得这么突然。

b3log.org 下面的几个服务要做迁移了，包括社区服务器（Rhythm）、社区论坛（Symphony）、首页（Index），还有我和 V 的个人博客。

VPS 提供商今天确定下来，明天刚好元旦放假，争取今晚把环境准备好，明天迁移完毕。
<br/><br/><p style='font-size: 12px;'><i>该文章同步自 <a href='http://symphony.b3log.org/article/1388458545375' target='_blank'>B3log 社区</a></i></p>