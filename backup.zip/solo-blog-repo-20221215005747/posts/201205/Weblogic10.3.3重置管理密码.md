title: Weblogic 10.3.3 重置管理密码
date: '2012-05-17 00:03:37'
updated: '2012-05-17 00:03:37'
tags: [Weblogic]
permalink: /articles/2012/05/16/1337155417330.html
---
<p>1. cd到你的域目录下的security，如C:\bea\wls103\user_projects\domains\my_domain\security</p>
<p>2. rm DefaultAuthenticatorInit.ldift</p>
<p>3. 运行java -cp &lt;weblogic_home\wlserver_10.3\server\lib\weblogic.jar weblogic.security.utils.AdminAccount adminuser adminpassword .</p>
<p>&nbsp;&nbsp; 这步会创建一个新的DefaultAuthenticatorInit.ldift文件</p>
<p>4. cd到&lt;domain_home&gt;/servers/&lt;AdminServer&gt;/data/ldap</p>
<p>5. rm DefaultAuthenticatormyrealmInit.initialized</p>
<p>6. 重启 Server，用新帐号登录 Admin Console，然后你就可以重置原帐号的密码了。</p>
<p>&nbsp;</p>
<p>参考：<a href="http://pridesnow.iteye.com/blog/1453653">http://pridesnow.iteye.com/blog/1453653</a></p>