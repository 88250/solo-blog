title: Liferay 5.1.1 安装与整合CAS
date: '2008-08-21 08:39:00'
updated: '2008-08-21 08:39:00'
tags: [Network Engineering, Open Source, Portal &amp; Portlet, J2EE/JavaEE, CAS &amp;
    SAML &amp; SSO]
permalink: /articles/2008/08/20/1219250340000.html
---
<meta http-equiv="CONTENT-TYPE" content="text/html; charset=utf-8">
	<title></title>
	<meta name="GENERATOR" content="OpenOffice.org 2.4  (Linux)">
	<style type="text/css">
	<!--
		@page { size: 8.5in 11in; margin: 0.79in }
		P { margin-bottom: 0.08in }
		H2 { margin-bottom: 0.08in }
		H2.western { font-family: "Nimbus Sans L", sans-serif; font-size: 14pt; font-style: italic }
		H2.cjk { font-size: 14pt; font-style: italic }
		H2.ctl { font-size: 14pt; font-style: italic }
		H3 { margin-bottom: 0.08in }
		H3.western { font-family: "Nimbus Sans L", sans-serif }
		H4 { margin-bottom: 0.08in }
		H4.western { font-family: "Nimbus Sans L", sans-serif; font-size: 11pt; font-style: italic }
		H4.cjk { font-size: 11pt; font-style: italic }
		H4.ctl { font-size: 11pt; font-style: italic }
		H5 { margin-bottom: 0.08in }
		H5.western { font-family: "Nimbus Sans L", sans-serif; font-size: 10pt; font-style: italic }
		H5.cjk { font-size: 10pt; font-style: italic }
		H5.ctl { font-size: 10pt; font-style: italic }
	-->
	</style>

<p style="margin-top: 0.17in; page-break-after: avoid;" align="center"><font face="Nimbus Sans L, sans-serif"><font style="font-size: 20pt;" size="5">Liferay
5.1.1 </font></font><font face="DejaVu Sans"><font style="font-size: 20pt;" size="5">安装与整合</font></font><font face="Nimbus Sans L, sans-serif"><font style="font-size: 20pt;" size="5">CAS</font></font></p>
<p align="center"><br><br>
</p>
<p><font face="Microsoft YaHei">转载请保留作者信息：</font></p>
<p><font face="DejaVu Sans"><font face="Microsoft YaHei">作者：</font></font><font face="Microsoft YaHei">88250</font></p>
<p><font face="Microsoft YaHei">Blog</font><font face="DejaVu Sans"><font face="Microsoft YaHei">：</font></font><a href="http://blog.csdn.net/DL88250"><font color="#2300dc"><font face="Microsoft YaHei">http:/blog.csdn.net/DL88250</font></font></a></p>
<p><font face="Microsoft YaHei">MSN &amp; Gmail &amp;
QQ</font><font face="DejaVu Sans"><font face="Microsoft YaHei">：</font></font><font face="Microsoft YaHei">DL88250@gmail.com</font></p>
<div id="Table of Contents1" dir="ltr" style="background: transparent none repeat scroll 0% 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;">
	<div id="Table of Contents1_Head" dir="ltr">
		<p style="margin-right: 0.4in; margin-top: 0.17in; page-break-after: avoid;">
		<font face="DejaVu Sans"><font style="font-size: 16pt;" size="4"><b>目录</b></font></font></p>
	</div>
	<p style="margin-left: 0.2in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">摘要</font></font><font size="4">	1</font></p>
	<p style="margin-left: 0.39in; margin-right: 0.4in; margin-bottom: 0in; page-break-before: auto;">
	<font face="DejaVu Sans"><font size="3">环境</font></font><b>	1</b></p>
	<p style="margin-left: 0.39in; margin-right: 0.4in; margin-bottom: 0in; page-break-before: auto;">
	<font face="DejaVu Sans"><font size="3">下载</font></font><b>Liferay
	5.1.1	2</b></p>
	<p style="margin-left: 0.39in; margin-right: 0.4in; margin-bottom: 0in; page-break-before: auto;">
	<font face="DejaVu Sans"><font size="3">配置数据库</font></font><b>	2</b></p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">配置数据源</font></font>	2</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">生成数据库</font></font>	2</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">创建数据库用户</font></font>	2</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">添加数据库连接驱动</font></font>	2</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">测试登录</font></font>	3</p>
	<p style="margin-left: 0.39in; margin-right: 0.4in; margin-bottom: 0in; page-break-before: auto;">
	<font face="DejaVu Sans"><font size="3">整合</font></font><b>CAS	3</b></p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">配置</font></font>CAS
	Server	3</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">启用</font></font>Tomcat
	SSL	3</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">配置</font></font>CAS
	Client	3</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">使用</font></font>JDK<font face="DejaVu Sans"><font size="3">工具</font></font>keytool<font face="DejaVu Sans"><font size="3">生成</font></font>SSL<font face="DejaVu Sans"><font size="3">证书</font></font>	3</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">测试</font></font>SSL<font face="DejaVu Sans"><font size="3">连接</font></font>	4</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">配置</font></font>CAS	4</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	CAS<font face="DejaVu Sans"><font size="3">登录验证</font></font>	5</p>
	<p style="margin-left: 0.79in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">定制</font></font>CAS<font face="DejaVu Sans"><font size="3">登录验证</font></font>	5</p>
	<p style="margin-left: 0.2in; margin-right: 0.4in; margin-bottom: 0in;">
	<font face="DejaVu Sans"><font size="3">总结</font></font><font size="4">	5</font></p>
</div>
<p style="margin-bottom: 0in;"><br>
</p>
<h2 class="western"><font face="DejaVu Sans">摘要</font></h2>
<p style="margin-bottom: 0in;">Liferay<font face="DejaVu Sans">目前很强大的一个</font>Portal
Application &amp;
Framework<font face="DejaVu Sans">，它实现了很多规范，其设计、功能与用户体验不是其他门户系统可以相比的。最近，</font>Liferay<font face="DejaVu Sans">刚刚拿到了</font>2008<font face="DejaVu Sans">开源门户大奖，而且</font>Sun<font face="DejaVu Sans">公司加入也到了</font>Liferay<font face="DejaVu Sans">社区中，参与一些</font>Portlet<font face="DejaVu Sans">的开发。可以看出，其前景很好。不过，由于官方的文档还没有出，而且</font>Liferay
5.1.x<font face="DejaVu Sans">与</font>4.x<font face="DejaVu Sans">在配置上有很大差别，在此，我将我的安装与配置经验分享给大家：）</font></p>
<h3 class="western"><font face="DejaVu Sans">环境</font></h3>
<ul><li><p style="margin-bottom: 0in;">MySQL5.0.5</p>
	</li><li><p style="margin-bottom: 0in;">JRE 1.6.0.7</p>
	</li><li><p style="margin-bottom: 0in;">Liferay 5.1.1 Bundled with Tomcat</p>
	</li><li><p style="margin-bottom: 0in;">Ubuntu 8.04</p>
</li></ul>
<p style="margin-bottom: 0in;"><br>
</p>
<h3 class="western"><font face="DejaVu Sans">下载</font>Liferay
5.1.1</h3>
<ol><p style="margin-bottom: 0in;"><font face="DejaVu Sans">到官方下载主页：
	</font><a href="http://www.liferay.com/web/guest/downloads/portal">http://www.liferay.com/web/guest/downloads/portal</a>
	<font face="DejaVu Sans">下载 </font><a href="http://downloads.sourceforge.net/lportal/liferay-portal-tomcat-6.0-5.1.1.zip">Bundled
	with Tomcat 6.0 </a><font face="DejaVu Sans">并解压到你指定的位置</font>(<font face="DejaVu Sans">即安装目录
	</font>$LIFERAY_HOME)<font face="DejaVu Sans">。</font></p><p style="margin-bottom: 0in;"></p></ol>
<h3 class="western"><font face="DejaVu Sans">配置数据库</font></h3>
<h5 class="western"><font face="DejaVu Sans">配置数据源</font></h5>
<ol><p style="margin-bottom: 0in;"><font face="DejaVu Sans">编辑
	</font>$LIFERAY_HOME/conf/Catalina/localhost/ROOT.xml <font face="DejaVu Sans">注释掉
	</font>Hypersonic<font face="DejaVu Sans">段，反注释
	</font>MySQL<font face="DejaVu Sans">段，修改你的 </font>MySQL
	<font face="DejaVu Sans">配置（<font color="#ff0000">红色</font>部分可能需要修改，本文均如此），如下：</font></p></ol>
<p style="margin-bottom: 0in;"><font style="font-size: 9pt;" size="2">			<font face="Courier 10 Pitch">&lt;!--
Hypersonic --&gt; </font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">		&lt;!--
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">			&lt;Resource
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				name="jdbc/LiferayPool"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				auth="Container"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				type="javax.sql.DataSource"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				driverClassName="org.hsqldb.jdbcDriver"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				url="jdbc:hsqldb:lportal"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				username="sa"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				password=""
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				maxActive="20"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">			/&gt;
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">		--&gt;
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">			&lt;!--
MySQL --&gt; </font></font>
</p>
<p style="margin-bottom: 0in;"><br>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">			&lt;Resource
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				name="jdbc/LiferayPool"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				auth="Container"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				type="javax.sql.DataSource"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				driverClassName="com.mysql.jdbc.Driver"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				url="jdbc:mysql://<font color="#ff0000">localhost:3306</font>/lportal?					</font></font></p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	
    
useUnicode=true&amp;amp;characterEncoding=UTF-8&amp;amp;useFastDateParsing=false"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				username="<font color="#ff0000">lportal</font>"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				password="<font color="#ff0000">dl88250</font>"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">				maxActive="20"
</font></font>
</p>
<p style="margin-bottom: 0in;"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">			/&gt;</font></font></p>
<p style="margin-bottom: 0in;"><br>
</p>
<h5 class="western"><font face="DejaVu Sans">生成数据库</font></h5>
<ol start="0"><p style="margin-bottom: 0in;"><font face="DejaVu Sans">到
	</font><a href="http://www.liferay.com/web/guest/downloads/additional">http://www.liferay.com/web/guest/downloads/additional</a>
	<font face="DejaVu Sans">下载数据库生成脚本 </font><a href="http://downloads.sourceforge.net/lportal/liferay-portal-sql-5.1.1.zip">Liferay
	Portal 5.1.1 SQL Scripts</a>
	<font face="DejaVu Sans">解压后在目录</font>create<font face="DejaVu Sans">下找到</font>create-mysql.sql<font face="DejaVu Sans">，将该脚本导入</font>MySQL<font face="DejaVu Sans">，创建</font>Liferay<font face="DejaVu Sans">数据库（使用默认恢复，也就是恢复</font>sample
	data<font face="DejaVu Sans">那种）。</font></p></ol>
<h5 class="western"><font face="DejaVu Sans">创建数据库用户</font></h5>
<ol start="0"><p style="margin-bottom: 0in;"><font face="DejaVu Sans">创建用户
	</font>lportal<font face="DejaVu Sans">（在</font>2.a<font face="DejaVu Sans">配置中提到的），并将</font>schema
	lportal<font face="DejaVu Sans">的所有操作授权给该用户。</font></p></ol>
<h5 class="western"><font face="DejaVu Sans">添加数据库连接驱动</font></h5>
<ol start="0"><p style="margin-bottom: 0in;"><font face="DejaVu Sans">下载 </font>MySQL
	connector jar,
	<a href="http://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.6.tar.gz/from/pick#mirrors">http://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.6.tar.gz/from/pick#mirrors</a>
	<font face="DejaVu Sans">并将该</font>jar<font face="DejaVu Sans">放到
	</font>$LIFERAY_HOME/lib <font face="DejaVu Sans">下。</font></p></ol>
<h5 class="western"><font face="DejaVu Sans">测试登录</font></h5>
<ol start="0"><p style="margin-bottom: 0in;"><font face="DejaVu Sans">测试一下，使用</font>test@liferay.com<font face="DejaVu Sans">，密码</font>test<font face="DejaVu Sans">登录</font>Liferay
	Portal<font face="DejaVu Sans">。</font></p></ol>
<ol start="0"><p style="margin-bottom: 0in;"></p></ol>
<h3 class="western"><font face="DejaVu Sans">整合</font>CAS</h3>
<p><font face="DejaVu Sans">理论上，</font>CAS
Server<font face="DejaVu Sans">应该部署在单独的验证服务器上，不过，由于环境所限，就将</font>CAS
Server<font face="DejaVu Sans">部署在</font>Liferay<font face="DejaVu Sans">的</font>Tomcat<font face="DejaVu Sans">下了。</font></p>
<h5 class="western"><font face="DejaVu Sans">配置</font>CAS Server</h5>
<ol><p><font face="DejaVu Sans">点<a href="http://www.liferay.com/web/guest/downloads/official_plugins/-/software_catalog/products/1180633?_98_redirect=/web/guest/downloads/official_plugins/-/software_catalog/products?_98_tabs1TabsScroll=&amp;_98_keywords=cas&amp;_98_type=">这里</a>下载，将这个</font>war<font face="DejaVu Sans">拷贝到
	</font>$HOME<font face="DejaVu Sans">下</font>liferay/deploy<font face="DejaVu Sans">（这个目录启动</font>Liferay
	Portal<font face="DejaVu Sans">后将自动生成，是</font>liferay
	plugins<font face="DejaVu Sans">的热部署目录），这样</font>Liferay<font face="DejaVu Sans">将自动部署</font>cas-server<font face="DejaVu Sans">。在
	</font>$LIFERAY_HOME/webapps/ <font face="DejaVu Sans">下看到</font>cas-web<font face="DejaVu Sans">，说明部署成功。</font></p></ol>
<h5 class="western"><font face="DejaVu Sans">启用</font>Tomcat SSL</h5>
<ol start="0"><p><font face="DejaVu Sans">编辑
	</font>$LIFERAY_HOME/conf/server.xml<font face="DejaVu Sans">，反注释</font>SSL<font face="DejaVu Sans">配置段，如下：</font></p></ol>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	&lt;!--
Define a SSL HTTP/1.1 Connector on port 8443 </font></font>
</p>
<p>       <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	
 This connector uses the JSSE configuration, when using APR, the </font></font>
</p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	
        connector should be using the OpenSSL style configuration </font></font>
</p>
<p>       <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	
 described in the APR documentation --&gt; </font></font>
</p>
<p><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	</font></font></p>
<p>    <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	&lt;Connector
port="8443" protocol="HTTP/1.1" SSLEnabled="true"
</font></font>
</p>
<p>       <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">	
       maxThreads="150" scheme="https"
secure="true" </font></font>
</p>
<ol start="0"><p>             <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">		
	clientAuth="false" sslProtocol="TLS" /&gt; </font></font>
	</p></ol>
<h5 class="western"><font face="DejaVu Sans">配置</font>CAS Client</h5>
<ol start="0"><p><font face="DejaVu Sans">点<a href="http://www.ja-sig.org/downloads/cas-clients/cas-client-2.0.11.zip">这里</a>下载</font>CAS<font face="DejaVu Sans">客户端（这个客户端用的是耶鲁大学的实现），解压后找到</font>casclient.jar<font face="DejaVu Sans">并放到
	</font>$LIFERAY_HOME/webapps/ROOT/WEB-INFO/lib/ <font face="DejaVu Sans">下。（貌似已经有这个</font>jar<font face="DejaVu Sans">了</font>-<font face="DejaVu Sans">　</font>-!<font face="DejaVu Sans">）</font></p></ol>
<h5 class="western"><font face="DejaVu Sans">使用</font>JDK<font face="DejaVu Sans">工具</font>keytool<font face="DejaVu Sans">生成</font>SSL<font face="DejaVu Sans">证书</font></h5>
<ol start="0"><p><font face="DejaVu Sans">在任何目录（我在</font>HOME<font face="DejaVu Sans">）下使用命令：</font></p><pre> <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">keytool -genkey -alias tomcat -keypass changeit -keyalg RSA</font></font>

<font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2">将生成</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">.keystore</font></font><font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2">在</font></font><font face="Courier 10 Pitch"><font style="font-size: 10pt;" size="2">$HOME</font></font><font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2">下。</font></font>
<font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2"><b>注意：</b><span style="">在输入</span></font></font><font style="font-size: 10pt;" size="2"><font face="Courier 10 Pitch"><span style="">What is your first and last name? </span></font></font><font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2"><span style="">时请使用你的</span></font></font><font style="font-size: 10pt;" size="2"><font face="Courier 10 Pitch"><span style="">hostname</span></font></font><font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2"><span style="">（参考</span></font></font><font style="font-size: 10pt;" size="2"><font face="Courier 10 Pitch"><span style="">/etc/hosts</span></font></font><font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2"><span style="">文件），不要用</span></font></font><font style="font-size: 10pt;" size="2"><font face="Courier 10 Pitch"><span style="">IP</span></font></font><font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2"><span style="">。</span></font></font>
<font face="DejaVu Sans, sans-serif"><font style="font-size: 10pt;" size="2">整个过程如下：</font></font></pre></ol>
<pre style=""><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">daniel@daniel-desktop:~$ keytool -genkey -alias tomcat -keypass changeit -keyalg RSA </font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">Enter keystore password:  </font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">Re-enter new password: </font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">What is your first and last name? </font></font>
  <font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch"><span style="">[Unknown]:  </span></font><font color="#ff0000"><font face="Courier 10 Pitch"><span style="">daniel-desktop</span></font></font><font face="Courier 10 Pitch"><span style=""> </span></font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">What is the name of your organizational unit? </font></font>
  <font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch"><span style="">[Unknown]:  </span></font><font color="#ff0000"><font face="Courier 10 Pitch"><span style="">SEE </span></font></font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">What is the name of your organization? </font></font>
  <font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch"><span style="">[Unknown]:  </span></font><font color="#ff0000"><font face="Courier 10 Pitch"><span style="">Jinfonet</span></font></font><font face="Courier 10 Pitch"><span style=""> </span></font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">What is the name of your City or Locality? </font></font>
  <font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch"><span style="">[Unknown]:  </span></font><font color="#ff0000"><font face="Courier 10 Pitch"><span style="">Kunming </span></font></font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">What is the name of your State or Province? </font></font>
  <font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch"><span style="">[Unknown]:  </span></font><font color="#ff0000"><font face="Courier 10 Pitch"><span style="">Yunnan</span></font></font><font face="Courier 10 Pitch"><span style=""> </span></font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">What is the two-letter country code for this unit? </font></font>
  <font style="font-size: 9pt;" size="2"><font face="Courier 10 Pitch"><span style="">[Unknown]:  </span></font><font color="#ff0000"><font face="Courier 10 Pitch"><span style="">CN</span></font></font><font face="Courier 10 Pitch"><span style=""> </span></font></font>
<font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">Is CN=daniel-desktop, OU=SEE, O=Jinfonet, L=Kunming, ST=Yunnan, C=CN correct? </font></font>
  <font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2">[no]:  yes </font></font>
</pre><p>
	<font face="DejaVu Sans">从</font>keystore<font face="DejaVu Sans">中导出证书并将此证书导入到</font>JRE<font face="DejaVu Sans">中：</font></p>
<pre><font face="Courier 10 Pitch"><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2"><span style="">daniel@daniel-desktop:~$</span></font></font><font style="font-size: 9pt;" size="2"> keytool -export -alias tomcat -keypass changeit -file </font><font color="#ff0000"><font style="font-size: 9pt;" size="2">server.cert </font></font><font face="Courier 10 Pitch"><font style="font-size: 9pt;" size="2"><span style=""><br>daniel@daniel-desktop:~$</span></font></font> keytool -import -alias tomcat -file <font color="#ff0000">server.cert</font> -keypass changeit -keystore $JAVA_HOME/jre/lib/security/cacerts</font></pre><p>
<br><br>
</p>
<h5 class="western"><font face="DejaVu Sans">测试</font>SSL<font face="DejaVu Sans">连接</font></h5>
<ol start="0"><p><font face="DejaVu Sans">访问</font>https://<font color="#ff0000">daniel-desktop</font>:8443
	<font face="DejaVu Sans">（由于证书不是权威机构颁发，所以添加一下</font>exception<font face="DejaVu Sans">），这时页面将被自动跳转到</font>https://<font color="#ff0000">daniel-desktop</font>:8443/web/guest/home<font face="DejaVu Sans">，也就是我们</font>Liferay
	Portal<font face="DejaVu Sans">的首页。只是用的协议是</font>https<font face="DejaVu Sans">而已。这样，说明了</font>SSL<font face="DejaVu Sans">启用成功！</font></p></ol>
<h5 class="western"><font face="DejaVu Sans">配置</font>CAS</h5>
<ol start="0"><p><font face="DejaVu Sans">使用</font>test@liferay.com<font face="DejaVu Sans">帐号登录</font>Portal<font face="DejaVu Sans">，并使用</font>Enterprise
	Admin Portlet<font face="DejaVu Sans">设置</font>CAS<font face="DejaVu Sans">：</font></p><p>Enterprise Admin <font face="Times New Roman, serif">→</font>
	Settings <font face="Times New Roman, serif">→</font>
	Authentication <font face="Times New Roman, serif">→</font>
	CAS<font face="DejaVu Sans">，启用</font>CAS<font face="DejaVu Sans">，如下：</font></p><p><font face="DejaVu Sans">记得点</font>Save<font face="DejaVu Sans">。。。。</font></p><p><font face="DejaVu Sans">注销当前帐户（</font><a href="mailto:test@liferay.com">test@liferay.com</a><font face="DejaVu Sans">），可以看到</font>logout
	successful<font face="DejaVu Sans">的提示。再次使用
	</font><a href="http://daniel-desktop:8080/">http://</a><font color="#ff0000"><a href="http://daniel-desktop:8080/">daniel-</a><a href="http://daniel-desktop:8080/">desktop</a></font><a href="http://daniel-desktop:8080/">:8080</a>
	<font face="DejaVu Sans">访问并登录时将跳转到</font>CAS<font face="DejaVu Sans">验证页面，说明了</font>CAS<font face="DejaVu Sans">配置成功。</font></p></ol>
<h5 class="western">CAS<font face="DejaVu Sans">登录验证</font></h5>
<ol start="0"><p><font face="DejaVu Sans">在</font>CAS<font face="DejaVu Sans">的验证页面，使用</font>test<font face="DejaVu Sans">作为帐号，</font>test<font face="DejaVu Sans">作为密码（只要帐号</font>==<font face="DejaVu Sans">密码就可以了），测试一下能不能通过</font>CAS<font face="DejaVu Sans">的验证。结果应该是可以通过，但是跳转也没无任何显示。因为我们并没有真正通过我们的</font>Portal
	user<font face="DejaVu Sans">的帐号验证。</font></p><p><font face="DejaVu Sans">关于</font>CAS<font face="DejaVu Sans">与</font>Liferay
	<font face="DejaVu Sans">的整合细节请参考<a href="http://blog.csdn.net/DL88250/archive/2008/08/19/2794943.aspx">这里</a></font></p><p><font face="DejaVu Sans">关于</font>CAS<font face="DejaVu Sans">与</font>Tomcat<font face="DejaVu Sans">下的</font>SSO<font face="DejaVu Sans">请参考<a href="http://blog.csdn.net/DL88250/archive/2008/08/20/2799522.aspx">这里</a></font></p></ol>
<h5 class="western"><font face="DejaVu Sans">定制</font>CAS<font face="DejaVu Sans">登录验证</font></h5>
<p><strike>[<font face="DejaVu Sans">本部分没有完成，请大家关注本文作者</font>Blog<font face="DejaVu Sans">：
</font><a href="http://blog.csdn.net/DL88250">http://blog.csdn.net/DL88250</a>
<font face="DejaVu Sans">以获取最新参考</font>: )]</strike></p><p>参考这里：<a href="http://blog.csdn.net/DL88250/archive/2008/08/26/2831855.aspx">http://blog.csdn.net/DL88250/archive/2008/08/26/2831855.aspx</a><br></p>
<ol start="0"><p></p><p></p><p></p></ol>
<h2 class="western"><font face="DejaVu Sans">总结</font></h2>
<p><font face="DejaVu Sans">经过这一番“折腾”，我们的</font>Portal<font face="DejaVu Sans">终于可以用了。本次，我们学会了</font>Liferay
Portal<font face="DejaVu Sans">的基本配置，还有整合</font>CAS<font face="DejaVu Sans">。在此之后，还有很多需要改进的地方。例如界面定制、用户权限管理、扩展</font>Portlet
plugins/environment<font face="DejaVu Sans">应用等。在以后的文章中我将把我对</font>Liferay<font face="DejaVu Sans">的使用、配置、开发经验分享给大家，请大家积极给予关注哦
</font>: )</p>