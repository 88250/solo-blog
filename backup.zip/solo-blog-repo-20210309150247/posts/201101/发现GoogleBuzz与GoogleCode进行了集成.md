title: 发现 Google Buzz 与 Google Code 进行了集成
date: '2011-01-14 18:03:32'
updated: '2011-11-27 03:13:36'
tags: [Buzz, Google]
permalink: /code-buzz.html
---
<p>提交 <a href="http://code.google.com/p/b3log-solo" target="_blank">B3log Solo</a>（运行在 GAE/J 上的博客程序） 代码后发现 Google Code 版本控制系统会将提交日志同步发布到 Google Buzz 中：</p>
<p><img src="https://sn2files.storage.live.com/y1p3DyKuuuunZCfSkihutEVSimc3pv4yBDiHZZgwWnAbsFzD2pZ8-a6JCdYuYlGlBaeUl7BgDvR8rk/code-buzz.png?psid=1" alt="code-buzz.png" width="412" height="182" /></p>
<p>但在 Buzz connected sites 里并没有看到与 Google Code 关联：</p>
<p><img src="https://sn2files.storage.live.com/y1pvt6554Xi9aQMK5FpJvotX-B6TvyfIbI9IizHobAhvpmgxTfojLT0YL5UqtLUmyzR5t4w7SRdI5o/buzz-connected.png?psid=1" alt="buzz-connected.png" width="487" height="280" /></p>
<p>&nbsp;</p>
<p>现在一提交代码就 Buzz，还是比较无奈的....</p>
<p>----</p>
<p>Updates:</p>
<p>Nov 26, 2011 - 把图片移到了 SkyDrive</p>