title: Web 应用性能优化——HTTP 请求数
date: '2011-03-23 20:59:18'
updated: '2011-03-23 20:59:18'
tags: [Optimization, HTTP, Web]
permalink: /web-http-request-performance-optimization.html
---
<h1>Web 应用性能&mdash;&mdash;HTTP 请求数</h1>
<h2>摘要</h2>
<p>从页面 HTTP 请求数以及 HTTP 缓存两方面来分析 Web 应用性能，并给出相应优化建议。</p>
<h2>HTTP 请求数</h2>
<p>浏览器在请求服务器后如果返回 HTML，则在浏览器端可能会涉及到如下一些并发 HTTP 请求：</p>
<ul>
<li>CSS/JS/IMG（via GET），请求数记作 S</li>
<li>脚本函数请求（via AJAX GET/POST/etc.），请求数记作 D</li>
<li>IFrame（via GET, S&rsquo;&amp; D&rsquo;），请求数记作 I</li>
</ul>
<p>由此可得出一个用户在无浏览器缓存时访问某页面的 HTTP 并发数：</p>
<p><em>C = S + D + I</em></p>
<h3>优化策略</h3>
<p>为了有效降低并发 HTTP 请求数 C，必须降低 S、D 与 I。可以考虑从以下几个方面进行优化：</p>
<ul>
<li>CSS Sprite，图片压缩（降低 S）</li>
<li>CSS/JS合并，压缩（降低 S）</li>
<li>离线存储（降低 D）</li>
<li>避免使用IFrame，AJAX 加载（降低 I，降低 S、D）</li>
</ul>
<h2>HTTP 缓存</h2>
<p>HTTP 缓存的目的在于减少服务器处理损耗，降低带宽占用，从而提高浏览器端用户体验，提升服务器性能。</p>
<p>在 HTTP/1.1 协议中，最常用的缓存控制方法是通过设置 Cache-Control、Expires、Last-Modified、ETag 头作为响应内容缓存控制策略。</p>
<p>其基本原理是服务器在处理请求时通过非常高效、低耗的计算（时间，HASH）可以得知请求的内容是否发生变化，若未变化则告知浏览器 304（Not Modified），浏览器从本地缓存取资源；否则返回请求资源。</p>
<h3>优化策略</h3>
<p>响应头 Cache-Control、Expires、Last-Modified、ETag 必须进行有效设置：</p>
<ul>
<li>CSS/JS/IMG/etc.<br />将这些静态资源设置缓存控制，例如至少为一天。</li>
<li>静态/动态资源分离<br />将静态资源部署到独立的 HTTP 服务器中，这样可以有效缓解应用服务器压力。</li>
</ul>
<h2>结论</h2>
<p>通过降低页面 HTTP 请求数，优化 HTTP 缓存可以有效降低前端服务器负载。将静态/动态资源分离能进一步优化服务整体性能，但需要改进前端服务器（负载均衡代理服务器）代理模式。</p>