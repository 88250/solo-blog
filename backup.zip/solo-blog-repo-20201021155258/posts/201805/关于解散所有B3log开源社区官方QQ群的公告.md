title: 关于解散所有 B3log 开源社区官方 QQ 群的公告
date: '2018-05-17 16:46:07'
updated: '2018-05-17 16:46:07'
tags: [B3log, 系统公告, Q群]
permalink: /articles/2018/05/17/1526517679116.html
---
所有 B3log 开源官方 Q 群将于 2018 年 5 月 18 日（周五）中午解散。解散的群包括：

1. B3log 开源①：2K 人群
2. B3log 开源②：2K 人群
3. B3log 开源③：300 人群
4. B3log 币圈：400 人群
5. B3log BND：1K 人群
6. B3log Game：100 人群
（如有需要，解散前大家可互加好友）

从建立第一个 Q 群到现在已经 8 年有余，但最终我还是不得不做出这个艰难的决定，主要是因为：

1. B3log 开源社区的产品在 GitHub 上通过 issue 讨论更为专业和方便
2. Q 群信息太过吵杂，对于有价值的讨论也无法给自己和后人留下参考
3. 管理 Q 群耗费了我们大量的精力，现阶段我们将把精力集中在 B3log 项目的推进上

最终 B3log 开源社区将只保留如下的线上联络渠道：

* 黑客派： https://hacpai.com
* GitHub： https://github.com/b3log
* Twitter：https://twitter.com/b3logos
* Telegram ：https://t.me/b3log
* 微信公众号：b3logos
* 微博：https://weibo.com/2778228501

谢谢大家一直以来的关注和支持，江湖再见！
