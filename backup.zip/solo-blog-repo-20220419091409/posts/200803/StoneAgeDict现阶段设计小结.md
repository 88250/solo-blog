title: StoneAgeDict现阶段设计小结
date: '2008-03-10 12:15:00'
updated: '2008-03-10 12:15:00'
tags: [StoneAgeDict]
permalink: /articles/2008/03/09/1205093700000.html
---
今天和zy结队编程了一天，讨论了很多问题。主要是围绕词库的开放式、实时的基本特性讨论的。<br /> <br /> 下面是对这两个特性的基本描述：<br />
<h2>What？</h2>
<h3>1. 开放性</h3>
<p>注册用户可以在查询出来的词汇中提交自己的词汇解释。这个解释将被递交到词库审核组，由审核组的工作人员审核这个提交。</p>
<p>例如，用户Daniel查询了beyond这个词汇，但是对这个词有着自己的理解，他可以提交这个理解给审核组。<br /> </p>
<h3>2. 实时性</h3>
当一个新的词汇定义被审核组审核通过后，这个定义将被加入到词库中。<br /> <br /> 例如，用户Daniel提交了beyond的一个定义，审核组通过了这个提交，则把这个新的定义追加到词库中的beyond词下。<br /> <br />
<h2>Why？</h2>
考虑了词库的权威性，要完全做到开放式很困难，其最困难的地方就是词库的维护。<br />
<h3>1. 由用户自己维护自己词库的话容易导致词库内无用的单词过多，甚至是词库的无效</h3>
<h3>2. 由专门的审核人员审核，工作量大</h3>
权衡利弊，我们选择了由专门的审核人员审核的做法。<br /> <br />
<h2>How？</h2>
<p>词库分为两种：</p>
<h3>1. 查询词库</h3>
<p>由用户提交的查询请求都集中在这个词库中进行查询，如果词库中不存在用户要查找的词汇，则说明词汇未找到。这个词库内的单词是<font size="2" style="font-weight: bold;">不能重复</font>的。<br /> </p>
<h3>2. 待审核词库</h3>
由用户提交的<font size="3" style="font-weight: bold;">新词</font>或者是对<font size="3" style="font-weight: bold;">已有词汇定义的新增<span style="font-weight: bold;"></span></font>都放入这个词库，等待审核人员的审核。如果审核通过，则将该词加入<font size="2" style="font-weight: bold;">查询词库：</font><font size="3" style="font-weight: bold;">新词</font>直接新建一个词汇记录；对于<font size="3" style="font-weight: bold;">已有词汇定义的新增</font>附加到该词汇的定义后。<br /><br />
<h3>3. 词库的存储</h3>
无论是<font size="2" style="font-weight: bold;">查询词库</font>还是<font size="2" style="font-weight: bold;">待审核词库</font>都采用数据库存储。经过测试，一个43W词汇的词库，检索一个单词可以在3－4s内完成。如果再建立缓存服务的话，效率可以保证。<br /><br />
<h2>XML?!</h2>
目前，XML格式的词汇文件作为核心交换文件格式。例如从<font size="2" style="font-weight: bold;">查询词库</font>中返回的词汇记录，采用XML格式直接传输到Web界面，由Web服务器解析后显示；从<span style="font-weight: bold;">其他词汇网站／服务</span>提供的单词转换成XML格式，并保存进入<font size="2" style="font-weight: bold;">待审核词库</font>。
<h2>&nbsp;</h2>
<h2>实现</h2>
<h3> 1.OSGi Framework</h3>
整个应用以OSGi作为底层框架，以<span style="font-weight: bold;">面向服务的组件模型</span>构建。这样可以做到很好的模块化，把耦合降到最低限度，为<span style="font-weight: bold;">将来的扩展</span>打下坚实的基础。<br /><br />
<h3>2. 基本查询词库构建</h3>
基本的<font size="2" style="font-weight: bold;">查询词库</font>由<a href="http://stardict.sourceforge.net/Dictionaries.php"><span style="color: rgb(0, 0, 255);">StarDict词库</span></a>转换而来，测试转换了一个43W词汇的英汉词库，耗时5小时。<br /><br />
<h3>3. 查询缓存</h3>
由于词汇量很大，做缓存是<font size="2" style="font-weight: bold;">必须</font>的。不过现阶段还没有做，还处于研究阶段。<br />
<h2>Another Idea....</h2>
在确定以上方案后，还有一个方案可以选择：<br />1. 每个用户都有自己的词库，词库中的每个词汇都有一个<span style="font-weight: bold;">得分</span><br />2. 查询词汇时从所有用户词库中查询<br />3. 按词汇<span style="font-weight: bold;">得分</span>大小降序显示各个用户的词汇解释<br />4. 用户可以对词汇进行<span style="font-weight: bold;">评分</span><br /> 5. 用户可以提交对某个词汇的修改，修改由该词汇的拥有者审核<br /><br />这个方案是建立在<font size="2" style="font-weight: bold;">词汇评级</font>以及<font size="2" style="font-weight: bold;">词汇审核开放</font>的基础上的，有一定的可行性。<br /><br /><br />
<p><br /> </p>
&nbsp;