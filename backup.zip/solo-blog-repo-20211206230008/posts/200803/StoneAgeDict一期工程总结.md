title: StoneAgeDict一期工程总结
date: '2008-03-12 03:59:00'
updated: '2008-03-12 03:59:00'
tags: [Life in Programming, StoneAgeDict]
permalink: /articles/2008/03/11/1205236740000.html
---
<br />
<h1>StoneAgeDict</h1>
<h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &mdash;&mdash;Online, Real-time Dictionary Service<br /></h1>
<h2>一期工程概述</h2>
从2月1日至今， StongeAgeDict项目经历了三次迭代，顺利完成了一期工程。
<h3>1. 明确了需求</h3>
<ul>
    <li>用户无需注册便可以查询、提交词汇定义或解释、例句等</li>
    <li>词汇审核人员可以审核用户提交的词汇更新</li>
</ul>
<h3>2. 确定了架构、技术</h3>
<ul>
    <li>采用OSGi作为底层框架</li>
    <li>AJAX的Web界面</li>
</ul>
<h3>3. 实现了查询、审核词汇</h3>
<ul>
    <li>查询词库：用户进行词汇查询的<font size="3" style="font-weight: bold;">共同、通用</font>词库</li>
    <li>待审核词库：用户提交的词汇更新词库</li>
</ul>
<h3>4. 查询词库数据导入</h3>
<ul>
    <li>一部43W词汇的英汉辞典查询库</li>
</ul>
详细一点的设计可以参考<a target="_blank" href="http://blog.csdn.net/DL88250/archive/2008/03/09/2160182.aspx">StoneAgeDict现阶段设计小结</a>。
<h2>二期工程展望</h2>
二期工程主要分为两大<font size="2" style="font-weight: bold;">研究</font>与<font size="2" style="font-weight: bold;">实现</font>方向：<br /><br />
<h3>1. 词汇查询性能调优</h3>
<ul>
    <li>数据库服务器参数调优</li>
    <li>应用程序、查询缓存调优</li>
</ul>
<h3>2. <span style="color: rgb(255, 0, 0);">降低词汇审核人员工作量，提高审核工作质量</span></h3>
这个是二期工程的研究重点和难点，可以从以下两方面入手：<br />
<ul>
    <li>自动过滤用户提交的<font size="2" style="font-weight: bold;">无用</font>词汇更新（类似垃圾邮件过滤，可以采用<a href="http://blog.csdn.net/DL88250/archive/2008/02/20/2108164.aspx" style="color: rgb(0, 0, 255);"><span style="font-weight: bold;">贝叶斯</span>分类模型</a>）</li>
    <li>自动过滤用户提交的<font size="2" style="font-weight: bold;">重复</font>词汇定义（过滤与已有词库定义重复的词库更新部分）<span style="font-weight: bold;"></span></li>
</ul>
以上提到的两个方面属于自然语言处理、数据挖掘范畴，可以作为<font size="3" style="font-weight: bold;">研究课题</font>开展。
<h3>3. 丰富查询库</h3>
<ul>
    <li>增大同语言的词汇量储备</li>
    <li>增加多种语言词汇支持</li>
</ul>
<h3 style="color: rgb(255, 0, 0);"><span style="color: rgb(0, 0, 0);">4.</span> 用户自己的词库</h3>
在某些场景下，用户的确需要自己的词库。例如：X教授拥有自己的整理的词库，对他的学生讲学的时候就很方便。要满足类似的用户需求，只需要在查询时根据用户名在<font size="2" style="font-weight: bold;">查询词库</font>中抽取出对于用户更新的部分即可。也就是说，用户可以定制自己的<span style="color: rgb(51, 153, 102);">过滤器</span>以抽取出不同的词汇定义，即可<span style="color: rgb(51, 153, 102); font-weight: bold;">满足用户词库共享</span>。
<h2>一些认识</h2>
<ol>
    <li>有时，诱导用户去简化他的需求可以让用户、开发团队受益良多，win-win才是我们所期待的</li>
    <li>复杂的应用总是构建在简单的应用上的，这样才能保证系统整体的稳定和开发过程的敏捷</li>
    <li>无论是基本的Water-full、Prototype、Iteration过程还是RUP、Agile等实际使用的过程模型、方法论，项目管理一定要做好，不能没有，也不能过度。只从<font size="2" style="font-weight: bold;">过度</font>这一点来看，与软件设计的过度设计有很多想通之处。软件工程问题上升到哲学范畴看的话，核心问题就是权衡、矛盾处理<br /></li>
</ol>