title: java.net Beta 上线
date: '2010-11-11 17:29:58'
updated: '2011-11-27 03:11:51'
tags: [Open Source, Java]
permalink: /articles/2010/11/11/1289438998967.html
---
<p>今年2 月份的时候得知 <a href="http://88250.b3log.org/articles/2010/02/08/1265669760000.html">Kenai.com 将与 java.net 合并</a>，半年多了，终于 <a href="http://java.net">beta</a> 了。</p>
<p><img src="https://sn2files.storage.live.com/y1ps5JGf9-dEibjlbwTIX_B96w9wepeK8K-OaRnGUfmhh4famECuXrUgWvDGJzFxV3tXc3MswtmZco/java.netbeta.png?psid=1" alt="Java.net" width="595" height="477" /></p>
<p>目前 <a href="http://kenai.com">kenai.com</a> 依然可以访问，等上面的项目迁移得差不多就会关闭。</p>
<p>----</p>
<p>Updates:</p>
<p>Nov 26, 2011 - 把图片移到了 SkyDrive</p>