title: Maven 与 Checkstyle
date: '2010-07-23 04:01:00'
updated: '2010-07-23 04:01:00'
tags: [Maven 2]
permalink: /articles/2010/07/22/1279800060000.html
---
<h1>Maven 与 Checkstyle</h1>
<p>&nbsp;</p>
<p style="font-family: Verdana;">转载请保留作者信息：</p>
<p style="font-family: Verdana;"> 作者：<a title="88250's Blog" href="http://blog.csdn.net/DL88250" title="88250's Blog">88250</a>
</p>
<p> 日期：2010 年 7 月 20 日</p>
<div id="WritelyTableOfContents" class="writely-toc"><ol class="writely-toc-none">
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#Maven_Checkstyle_0987043387516" target="_self">Maven 与 Checkstyle</a>
<ol class="writely-toc-none writely-toc-subheading" style="margin-left: 0pt;">
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#_4396637981723581_2325407965230495" target="_self">概要</a>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#_6785744132603053_06086303323340736" target="_self">前提准备</a>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#POM_9772293049901971_27593982411854845" target="_self">示例 POM</a>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#_4788367842861646_9776195132491419" target="_self">编码规则配置</a>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#_6531549452737226_30352110086141826" target="_self">违反列举</a>
<ol class="writely-toc-none writely-toc-subheading" style="margin-left: 0pt;">
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#Javadoc_Tag_6582852843062815_9043563124577536" target="_self">Javadoc Tag</a>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#Naming_9314109512255424_8210571984684654" target="_self">Naming</a>
</li>
</ol>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#_5051937535862945_664048170753673" target="_self">结论</a>
</li>
<li><a href="http://docs.google.com/View?id=ddrm6c35_1240fzf53rg8#_03852396374535194" target="_self">进一步阅读</a>
</li>
</ol>
</li>
</ol>
</div>
<p>&nbsp;</p>
<h2><a id="_4396637981723581_2325407965230495" name="_4396637981723581_2325407965230495"></a>
概要</h2>
<p>&nbsp;&nbsp;&nbsp;&nbsp; Checkstyle 是一个帮助 Java 开发人员在编写代码时能够遵循编码规范的工具。它可以自动检查 Java 代码风格，节省人工。本文以一项目示例描述了基于 <a id="h-57" title="Maven" href="http://maven.apache.org/" title="Maven">Maven</a>
 的项目使用 Checkstyle 的配置。</p>
<h2><a id="_6785744132603053_06086303323340736" name="_6785744132603053_06086303323340736"></a>
前提准备</h2>
<ul>
<li><a id="hhnn" title="Maven2" href="http://maven.apache.org/" title="Maven2">Maven2</a>
 基础知识
</li>
<li>安装 <a id="lk0k" title="Maven2" href="http://maven.apache.org/" title="Maven2">Maven2</a>
、<a id="nsxh" title="NetBeans" href="http://www.netbeans.org/" title="NetBeans">NetBeans</a>
（任意支持 Maven2 IDE 亦可）。</li>
<li>示例项目：<a id="x_97" title="http://latke.googlecode.com/" href="http://latke.googlecode.com/" title="http://latke.googlecode.com/">http://latke.googlecode.com/</a>
</li>
</ul>
<h2><a id="POM_9772293049901971_27593982411854845" name="POM_9772293049901971_27593982411854845"></a>
示例 POM</h2>
<p><span style="font-family: verdana;">&nbsp;&nbsp;&nbsp;&nbsp; 在示例项目（假定根目录为 /latke）的 pom.xml 中找到如下代码：</span>
<br />
<br />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;plugin&gt;</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;groupId&gt;org.apache.maven.plugins&lt;/groupId&gt;</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;artifactId&gt;maven-checkstyle-plugin&lt;/artifactId&gt;</span>
<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="font-family: courier new;">&lt;version&gt;${maven-checkstyle-plugin.version}&lt;/version&gt;</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;configuration&gt;</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>&lt;configLocation&gt;</strong>
</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ${basedir}/etc/beyondtrack_checks.xml</strong>
</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/configLocation&gt;</strong>
</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ....</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/configuration&gt;</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ....</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/plugin&gt;</span>
<br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp; 其中粗体标明了 Checkstyle 所使用的编码规则配置文件。该项目使用 maven-checkstyle-plugin 版本为 2.5。</p>
<h2><a id="_4788367842861646_9776195132491419" name="_4788367842861646_9776195132491419"></a>
编码规则配置</h2>
<p>&nbsp;&nbsp;&nbsp;&nbsp;
 使用文本编辑器打开项目根目录（/latke）下的 etc 目录下的 beyondtrack_checks.xml。该规则配置在 Sun 
编码规范的基础上进行了一定的修改，放宽了某些限制，例如忽略了包文档检查；同时也加强了某些限制，例如使用 final 关键字修饰本地变量。<br />
&nbsp;&nbsp;&nbsp;&nbsp; 具体细节请参阅<a id="ipo2" title="此文件" href="http://code.google.com/p/latke/source/browse/trunk/latke/etc/beyondtrack_checks.xml" title="此文件">此文件</a>
。</p>
<h2><a id="_6531549452737226_30352110086141826" name="_6531549452737226_30352110086141826"></a>
违反列举</h2>
<h4><a id="Javadoc_Tag_6582852843062815_9043563124577536" name="Javadoc_Tag_6582852843062815_9043563124577536"></a>
Javadoc Tag</h4>
<p>&nbsp;&nbsp;&nbsp;&nbsp; 在规则文件中查找：<br />
<br />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;module name=&quot;JavadocType&quot;&gt;</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;property name=&quot;authorFormat&quot; value=&quot;\S&quot;/&gt;</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;property name=&quot;versionFormat&quot; <br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; value=&quot;\d\.\d\.\d\.\d, [A-Z]+[a-z]{2,2} \d{1,2}, \d\d\d\d&quot;/&gt;</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/module&gt;<br />
<br />
&nbsp;&nbsp;&nbsp; <span style="font-family: verdana;">该模块定义了对 Java 类与接口 Javadoc 注释的检查规则。假设该项目中某一 Java 类源码如下：</span>
<br />
</span>
</p>
<div style="margin-left: 40px;"><span style="font-family: courier new;"><br />
/**</span>
<br />
<span style="font-family: courier new;">&nbsp;* This class defines all message model relevant keys.</span>
<br />
<span style="font-family: courier new;">&nbsp;*</span>
<br />
<span style="font-family: courier new;">&nbsp;* @author &lt;a href=&quot;mailto:DL88250@gmail.com&quot;&gt;Liang Ding&lt;/a&gt;</span>
<br />
<span style="font-family: courier new;">&nbsp;* @version <strong>1.0.0</strong>
, Jun 24, 2010</span>
<br />
<span style="font-family: courier new;">&nbsp;*/</span>
<br />
<span style="font-family: courier new;">public abstract class AbstractI18nModel {}<br />
<br />
</span>
</div>
<p>&nbsp;&nbsp;&nbsp;&nbsp; 其中粗体标明了该类的版本，但由于规则文件强制定义了版本格式（<span style="font-family: courier new;">\d\.\d\.\d\.\d</span>
）为 4 位，所以在构建该项目时将输出（行号、列号以实际为准，下同）：<br />
<br />
<span style="font-family: courier new;">AbstractI18nModel.java:xx: Type Javadoc tag @version must match pattern '\d\.\d\.\d\.\d, [A-Z]+[a-z]{2,2} \d{1,2}, \d\d\d\d'.</span>
</p>
<h4><a id="Naming_9314109512255424_8210571984684654" name="Naming_9314109512255424_8210571984684654"></a>
Naming</h4>
<p>&nbsp;&nbsp;&nbsp;&nbsp; 在规则文件中查找：</p>
<div style="margin-left: 40px;">&nbsp;&nbsp; <span style="font-family: courier new;">&lt;module name=&quot;ConstantName&quot; /&gt;</span>
<br />
</div>
<p><br />
&nbsp;&nbsp;&nbsp;&nbsp; 该模块定义了对常量命名的检查，这里使用了默认规则格式：<span class="default"><span style="font-family: courier new;">^[A-Z][A-Z0-9]*(_[A-Z0-9]+)*$</span>
。当某一字段被 static final 修饰时，该字段就是一个常量字段，Checkstyle 将检查是否满足如上命名格式。<br />
&nbsp;&nbsp;&nbsp;&nbsp; 假设该项目中某一 Java 类源码如下：<br />
<br />
</span>
</p>
<div style="margin-left: 40px;"><span class="default"><span style="font-family: courier new;">public final class Keys {</span>
</span>
<br style="font-family: Courier New;" />
<br style="font-family: Courier New;" />
<span class="default"><span style="font-family: courier new;">&nbsp;&nbsp;&nbsp; private static Locale defaultLocale;</span>
</span>
<br style="font-family: Courier New;" />
<span class="default"><span style="font-family: courier new;">&nbsp;&nbsp;&nbsp; /**</span>
</span>
<br style="font-family: Courier New;" />
<span class="default"><span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp; * Key of action status code.</span>
</span>
<br style="font-family: Courier New;" />
<span class="default"><span style="font-family: courier new;">&nbsp;&nbsp;&nbsp;&nbsp; */</span>
</span>
<br style="font-family: Courier New;" />
<span class="default"><span style="font-family: courier new;">&nbsp;&nbsp;&nbsp; public static final String STATUS_<strong>c</strong>
ODE = &quot;sc&quot;;</span>
</span>
<br style="font-family: Courier New;" />
<span style="font-family: courier new;">}</span>
<br />
</div>
<p><br />
&nbsp;&nbsp;&nbsp;&nbsp; 该类字段 STATUS_cODE 包含了一小写字母，将违反常量命名规则，所以在构建该项目时将输出：<br />
<br />
<span style="font-family: courier new;">Keys.java:xx:xx: Name 'STATUS_cODE' must match pattern '^[A-Z][A-Z0-9]*(_[A-Z0-9]+)*$'.</span></p>
<h2><a id="_5051937535862945_664048170753673" name="_5051937535862945_664048170753673"></a>
结论</h2>
<p>&nbsp;&nbsp;&nbsp;&nbsp; Checkstyle 可以对团队编程时 Java 代码的风格进行统一，有助于代码质量提高。通过自定义其检查规则配置可以让团队在特定项目的 Java 代码风格上保持某种程度的一致。</p>
<h2><a id="_03852396374535194" name="_03852396374535194"></a>
<span style="font-size: small;">进一步阅读</span>
</h2>
<ul>
<li><a id="c9.o" title="Maven Checkstyle Plugin" href="http://maven.apache.org/plugins/maven-checkstyle-plugin/" title="Maven Checkstyle Plugin">Maven Checkstyle Plugin</a>
</li>
<li><a id="g3tt" title="Checkstyle" href="http://checkstyle.sourceforge.net/" title="Checkstyle">Checkstyle</a>
</li>
</ul>