title: VC++ 2005下Debug / Release的问题
date: '2006-12-30 14:36:00'
updated: '2006-12-30 14:36:00'
tags: [C/C++]
permalink: /articles/2006/12/29/1167431760000.html
---
<p>郁闷了，今天在VC+= 2005下做一下C++的管理系统的时候发现Release居然出现的莫名其妙的问题。</p>
<p>是这样的，在Release下编译一个异常处理模块，我申明了一个std::string test(&quot;&quot;)，单步跟踪发现这个string里居然是&quot;?B|开头&quot;！</p>
<p>换到Debug下，一切正常了。。。。</p>
<p>不知道这是为什么，郁闷了。。。。</p>
<p>&nbsp;</p>