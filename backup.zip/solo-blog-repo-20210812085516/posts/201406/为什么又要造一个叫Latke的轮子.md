title: 为什么又要造一个叫 Latke 的轮子
date: '2014-06-27 21:38:46'
updated: '2021-04-17 18:30:16'
tags: [JSON, ORM, Java, B3logLatke]
permalink: /why-latke-exists
---
<p>本文最新版本已经迁移到<a href="https://ld246.com/article/1403847528022" target="_blank">这里</a>。</p>
